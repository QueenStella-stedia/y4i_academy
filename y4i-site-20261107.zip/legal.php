<?php
require_once __DIR__ . '/inc_public.php';
$co = company_info();
public_head(
    'Mentions légales, confidentialité et conditions',
    'Mentions légales, politique de confidentialité, conditions générales et règles du fonds de garantie de Y4I Academy.',
    'legal.php'
);
?>
<section class="page-hero"><div class="wrap">
  <p class="breadcrumb" style="color:#B9CBE3"><a style="color:#fff" href="<?= h(abs_url('index.php')) ?>">Accueil</a> › Informations légales</p>
  <span class="kicker"><i></i> Transparence</span>
  <h1>Informations légales & conditions</h1>
  <p>Modèles à compléter avec vos informations réelles avant la mise en ligne. Les champs marqués « à compléter » doivent être remplacés.</p>
</div></section>

<main class="page-main"><div class="wrap page-grid">
  <article class="legal-body">
    <h2 id="mentions">1. Mentions légales</h2>
    <p><b>Dénomination :</b> <?= h($co['name']) ?><br>
       <b>Nom légal / raison sociale :</b> <?= h($co['legal_name']) ?><br>
       <b>Immatriculation :</b> <?= h($co['registration']) ?><br>
       <b>Siège :</b> <?= h($co['address']) ?><br>
       <b>Responsable de publication :</b> <?= h($co['manager']) ?><br>
       <b>Horaires :</b> <?= h($co['hours']) ?><br>
       <b>Téléphone :</b> +237 622 142 496 · <b>WhatsApp :</b> +237 696 500 949<br>
       <b>E-mail :</b> <?= h((string)cfg()['email']) ?></p>
    <p class="hint">Hébergeur : nom, adresse et contact à compléter. Ce site est édité par <?= h($co['name']) ?>.</p>

    <h2 id="confidentialite">2. Politique de confidentialité</h2>
    <h3>Données collectées</h3>
    <p>Nom, téléphone, e-mail, quartier, type de compte, formation souhaitée, description de prestation, références et, pour les prestataires, les pièces de vérification (pièce d'identité et diplôme/certificat). <b>Aucun casier judiciaire n'est demandé.</b></p>
    <h3>Finalités</h3>
    <p>Gestion des comptes et des demandes, organisation des interventions, vérification des prestataires, paiement du fonds de garantie, suivi de position pendant une prestation, statistiques anonymes et communication avec vous.</p>
    <h3>Base légale</h3>
    <p>Exécution de la relation contractuelle, consentement pour les communications et intérêt légitime pour la sécurité des services.</p>
    <h3>Conservation</h3>
    <p>Les données sont conservées pendant la durée de la relation, puis archivées ou supprimées selon les obligations légales. Les documents de vérification sont conservés le temps nécessaire à la vérification et à la sécurité.</p>
    <h3>Destinataires</h3>
    <p>L'administration de <?= h($co['name']) ?> et, lorsque nécessaire, les prestataires concernés par une intervention. Les données ne sont pas revendues.</p>
    <h3>Sécurité</h3>
    <p>Les documents de vérification sont stockés hors accès public. Les paiements sont traités par les opérateurs Mobile Money ; aucun code secret n'est demandé ni stocké sur le site.</p>
    <h3>Vos droits</h3>
    <p>Vous pouvez demander l'accès, la rectification ou la suppression de vos données en écrivant à <?= h((string)cfg()['email']) ?>. Vous pouvez aussi vous opposer aux communications non essentielles.</p>
    <h3>Cookies et mesure d'audience</h3>
    <p>Le site n'utilise des outils de mesure d'audience (Google Analytics ou Matomo) qu'après votre consentement. Vous pouvez refuser sans perdre l'accès au site.</p>

    <h2 id="cgu">3. Conditions générales d'utilisation et de vente</h2>
    <h3>Comptes</h3>
    <p>La création d'un compte est gratuite. Les informations fournies doivent être exactes. Un compte prestataire peut être vérifié par l'administration ; la vérification ne garantit pas l'obtention de missions.</p>
    <h3>Formations</h3>
    <p>Les parcours, durées, prérequis et tarifs sont indiqués à titre informatif et confirmés avec l'administration. Les places sont limitées. Les modalités de paiement et de report sont précisées au moment de l'inscription.</p>
    <h3>Services à domicile</h3>
    <p>Les prestations font l'objet d'un devis ou d'un accord préalable. Les soins médicaux et la kinésithérapie sont réalisés par des professionnels qualifiés, selon l'orientation médicale lorsque nécessaire. Le site ne remplace pas un avis médical.</p>
    <h3>Obligations des prestataires</h3>
    <p>Les prestataires s'engagent à fournir des informations exactes, à respecter la dignité et la vie privée des personnes accompagnées, à se présenter aux interventions convenues et à maintenir un comportement professionnel.</p>
    <h3>Responsabilité</h3>
    <p><?= h($co['name']) ?> coordonne la mise en relation et le suivi. Sa responsabilité ne peut être engagée pour un manquement imputable à un prestataire ou à un événement extérieur, dans les limites permises par la loi.</p>
    <h3>Réclamations</h3>
    <p>Toute réclamation peut être adressée à <?= h((string)cfg()['email']) ?> ou au +237 622 142 496. Nous répondons dans les meilleurs délais.</p>
    <h3>Droit applicable</h3>
    <p>Les présentes conditions sont soumises au droit camerounais. Les tribunaux compétents de Yaoundé sont saisis en cas de litige, après tentative de règlement amiable.</p>

    <h2 id="garantie">4. Fonds de garantie et remboursement</h2>
    <ul>
      <li>Le fonds de garantie est <b>obligatoire pour les prestataires</b>, avec un minimum de <?= number_format(max(1000, (int)setting('min_guarantee', 5000)), 0, ',', ' ') ?> FCFA.</li>
      <li>Il est réglé par Mobile Money (Orange Money ou MTN MoMo). Le code secret se saisit uniquement sur le téléphone.</li>
      <li>La somme est bloquée pendant l'activité du prestataire. Elle n'est pas un frais de dossier et ne rémunère pas une prestation.</li>
      <li>Elle est restituée après clôture du compte, déduction faite des sommes éventuellement dues ou des dommages établis.</li>
      <li>Le remboursement est effectué sur le numéro Mobile Money utilisé, après validation par l'administration.</li>
      <li>En cas de paiement échoué, aucun montant n'est débité. En cas d'incident technique, écrivez à <?= h((string)cfg()['email']) ?> avec la référence de transaction.</li>
    </ul>
    <p class="hint">Ces règles sont un modèle : faites-les valider par un conseil juridique avant la mise en production.</p>
  </article>

  <aside>
    <div class="side-card">
      <h3><i class="fas fa-building"></i> Coordonnées</h3>
      <p><b><?= h($co['name']) ?></b><br><?= h($co['address']) ?><br><?= h($co['hours']) ?><br><a href="tel:+237622142496">+237 622 142 496</a><br><a href="mailto:<?= h((string)cfg()['email']) ?>"><?= h((string)cfg()['email']) ?></a></p>
      <a class="btn btn-ghost small" href="<?= h($co['maps']) ?>" target="_blank" rel="noopener">Voir sur la carte</a>
    </div>
    <div class="side-card" style="margin-top:1rem">
      <h3><i class="fas fa-list"></i> Sommaire</h3>
      <p><a href="#mentions">Mentions légales</a><br><a href="#confidentialite">Confidentialité</a><br><a href="#cgu">CGU / CGV</a><br><a href="#garantie">Fonds de garantie</a></p>
    </div>
    <div class="side-card" style="margin-top:1rem">
      <h3><i class="fas fa-circle-info"></i> À compléter</h3>
      <p>Nom légal, RCCM, NIU, responsable de publication, adresse e-mail professionnelle et hébergeur. Ces informations sont des exemples à remplacer.</p>
    </div>
  </aside>
</div></main>
<?php public_footer(); ?>

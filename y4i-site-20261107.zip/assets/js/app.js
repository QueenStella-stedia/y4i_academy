/* ==========================================================================
   Y4I Academy — contrôleur front-end
   Formations · carte/itinéraires · inscription · contact · administration
   ========================================================================== */
'use strict';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const fcfa = n => Math.round(Number(n) || 0).toLocaleString('fr-FR').replace(/\u202f/g, ' ') + ' FCFA';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const Y4I = window.Y4I || { csrf: '', whatsapp: '', phone: '', places: [] };

let FORMATIONS = [];
let CONF = { tariffs: [], formations: [], min_guarantee: 5000, km_price: 300, base_fee: 1000, gateways: {}, map: {} };

/* --------------------------------------------------------------------------
   API : le jeton CSRF est envoyé sur toutes les écritures
   -------------------------------------------------------------------------- */
async function api(action, data = null, params = {}) {
  const qs = new URLSearchParams(Object.assign({ action }, params || {}));
  const opt = { credentials: 'same-origin', headers: { 'Accept': 'application/json' } };
  if (data !== null && data !== undefined) {
    opt.method = 'POST';
    opt.headers['X-CSRF-Token'] = Y4I.csrf || '';
    if (typeof FormData !== 'undefined' && data instanceof FormData) {
      opt.body = data; // le navigateur définit lui-même le Content-Type multipart
    } else {
      opt.headers['Content-Type'] = 'application/json';
      opt.body = JSON.stringify(data);
    }
  }
  let r;
  try { r = await fetch('api.php?' + qs.toString(), opt); }
  catch (e) { return { error: 'Connexion au serveur impossible. Vérifiez votre connexion puis réessayez.' }; }
  const raw = await r.text();
  let j;
  try { j = JSON.parse(raw); }
  catch (e) { j = { error: 'Le serveur a renvoyé une réponse inattendue. Rechargez la page.' }; }
  if (!r.ok) {
    if (!j.error) j.error = 'Erreur ' + r.status + '. Réessayez.';
    if (r.status === 401 && action !== 'admin_login' && action.startsWith('admin_')) lockAdminUI();
  }
  return j;
}

/* --------------------------------------------------------------------------
   Notifications discrètes
   -------------------------------------------------------------------------- */
function toast(message, type = '', ms = 4200) {
  const wrap = $('#toastWrap');
  if (!wrap) return;
  const el = document.createElement('div');
  el.className = 'toast ' + (type || '');
  el.setAttribute('role', 'status');
  el.textContent = message;
  wrap.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateY(8px)'; el.style.transition = '.25s'; }, Math.max(1200, ms - 300));
  setTimeout(() => el.remove(), ms);
}

/* --------------------------------------------------------------------------
   Navigation entre sections
   -------------------------------------------------------------------------- */
function navigateToSection(id) {
  const target = $(id);
  if (!target) return;
  if (id === '#admin') lockAdminUI();
  $$('.page-section').forEach(s => s.classList.remove('active'));
  target.classList.add('active');
  $$('.nav-link').forEach(l => l.classList.toggle('active', l.getAttribute('href') === id));
  const nav = $('#nav');
  if (nav) nav.classList.remove('open');
  const burger = $('#burger');
  if (burger) burger.setAttribute('aria-expanded', 'false');
  // Les éléments d'animation doivent redevenir visibles immédiatement dans la section affichée.
  $$('.reveal', target).forEach(el => el.classList.add('in'));
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (id === '#suivi') setTimeout(initMap, 180);
  if (id === '#contact') setTimeout(() => $('#cName') && $('#cName').focus({ preventScroll: true }), 320);
}
function selectService(key, sub = '') {
  navigateToSection('#contact');
  const need = $('#cNeed');
  let label = '';
  if (need) {
    const opt = [...need.options].find(o => o.value === key);
    if (opt) { need.value = key; label = opt.textContent.trim(); }
  }
  if (sub) {
    const msg = $('#cMsg');
    if (msg) {
      msg.value = 'Je souhaite : ' + (label || key) + ' — ' + sub + '.\n';
      msg.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }
  setTimeout(() => $('#cMsg') && $('#cMsg').focus(), 340);
}
function selectSubservice(key, sub) {
  selectService(key, sub);
  toast('Sous-service sélectionné : ' + sub + '. Complétez votre demande.', 'ok');
}

/* --------------------------------------------------------------------------
   Diaporama
   -------------------------------------------------------------------------- */
function initSlideshow() {
  const slides = $$('.slide'), dots = $('#dots');
  if (!slides.length || !dots) return;
  let i = 0, timer = null;
  slides.forEach((_, n) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.setAttribute('aria-label', 'Image ' + (n + 1));
    b.onclick = () => { go(n); restart(); };
    dots.appendChild(b);
  });
  const go = n => {
    slides[i].classList.remove('active-slide');
    i = (n + slides.length) % slides.length;
    slides[i].classList.add('active-slide');
    $$('button', dots).forEach((d, k) => d.classList.toggle('on', k === i));
  };
  const restart = () => { clearInterval(timer); timer = setInterval(() => go(i + 1), 5000); };
  go(0); restart();
}

/* --------------------------------------------------------------------------
   Tarifs, formations et configuration publique
   -------------------------------------------------------------------------- */
async function loadTariffs() {
  const d = await api('tariffs');
  if (!d || d.error) return;
  CONF = Object.assign(CONF, d);
  if (Array.isArray(d.formations) && d.formations.length) FORMATIONS = d.formations;

  (d.tariffs || []).forEach(t => {
    const el = $(`.service-card[data-key="${t.k}"] .service-price`);
    if (!el) return;
    el.innerHTML = Number(t.price) > 0
      ? `<i class="fas fa-tag"></i> Dès <span>${Number(t.price).toLocaleString('fr-FR')}</span> FCFA / ${esc(t.unit)}`
      : '<i class="fas fa-circle-info"></i> Tarif sur devis · selon les heures et les tâches';
  });

  const g = $('#regAmount');
  if (g) { g.min = CONF.min_guarantee; g.placeholder = 'Ex : ' + (CONF.min_guarantee * 3); if (Number(g.value) < CONF.min_guarantee) g.value = CONF.min_guarantee; }
  const minG = $('#minG');
  if (minG) minG.textContent = 'Minimum : ' + fcfa(CONF.min_guarantee);

  const req = $('#reqService');
  if (req) {
    req.innerHTML = (d.tariffs || []).filter(t => t.k !== 'formation').map(t =>
      `<option value="${esc(t.k)}">${esc(t.label)}${Number(t.price) > 0 ? ' — dès ' + fcfa(t.price) : ''}</option>`
    ).join('');
  }

  const campayLive = !!(d.gateways && d.gateways.campay);
  const campayMode = (d.modes && d.modes.campay) || 'sim';
  let hint = $('#gwHint');
  if (!hint) {
    hint = document.createElement('p');
    hint.className = 'hint'; hint.id = 'gwHint';
    const box = $('#prestataireFields');
    if (box) box.appendChild(hint);
  }
  if (hint) {
    hint.innerHTML = campayLive
      ? (campayMode === 'test'
        ? '<i class="fas fa-flask"></i> Campay est configuré en <b>mode test</b> : aucun argent réel ne sera débité. Pour encaisser réellement, utilisez l\'adresse de production dans config.php.'
        : '<i class="fas fa-circle-check"></i> Campay est configuré : le message de validation du code secret sera envoyé par l\'opérateur sur le numéro de votre puce.')
      : '<i class="fas fa-circle-info"></i> Campay n\'est pas encore configuré : le fonds de garantie reste simulé. Renseignez <b>username</b> et <b>password</b> dans la section <b>campay</b> de config.php pour encaisser réellement.';
  }
}

async function loadFormations(force = false) {
  if (FORMATIONS.length && !force) return FORMATIONS;
  const d = await api('formations');
  if (d && Array.isArray(d.formations)) FORMATIONS = d.formations;
  return FORMATIONS;
}

/* --------------------------------------------------------------------------
   Fiche formation (modale)
   -------------------------------------------------------------------------- */
let lastFocused = null;

function openFormation(code) {
  if (!code) return;
  const f = FORMATIONS.find(x => String(x.code).toUpperCase() === String(code).toUpperCase());
  if (!f) {
    loadFormations(true).then(list => {
      const found = list.find(x => String(x.code).toUpperCase() === String(code).toUpperCase());
      if (found) renderFormation(found); else toast('Fiche de formation indisponible. Rechargez la page.', 'ko');
    });
    return;
  }
  renderFormation(f);
}

function renderFormation(f) {
  const modal = $('#formationModal');
  const content = $('#formationModalContent');
  if (!modal || !content) return;
  lastFocused = document.activeElement;
  const modules = String(f.modules || '').split(';').map(x => x.trim()).filter(Boolean);
  const price = Number(f.price) > 0 ? fcfa(f.price) : (f.price_note || 'Nous consulter');
  const whatsapp = `https://wa.me/${encodeURIComponent(Y4I.whatsapp || '')}?text=${encodeURIComponent('Bonjour Y4I Academy, je souhaite des informations sur la formation ' + f.title + ' (' + f.code + ').')}`;

  content.innerHTML = `
    <div class="modal-hero">
      <img src="assets/img/photos/${esc(f.image || 'formation-hero.jpg')}" alt="${esc(f.title)}">
      <div class="modal-hero-txt">
        <span class="mc-code">${esc(f.code)}</span>
        <h3 id="formationModalTitle">${esc(f.title)}</h3>
      </div>
    </div>
    <div class="modal-body">
      <p>${esc(f.description || f.short || '')}</p>
      <div class="modal-meta">
        <div><small>Durée</small><b>${esc(f.duration || 'Nous consulter')}</b></div>
        <div><small>Certification</small><b>${esc(f.certification || 'Attestation Y4I Academy')}</b></div>
        <div><small>Tarif</small><b>${esc(price)}</b></div>
      </div>
      ${modules.length ? `<h4>Programme</h4><ul class="modal-list">${modules.map(m => `<li><i class="fas fa-check"></i>${esc(m)}</li>`).join('')}</ul>` : ''}
      <h4>Prérequis</h4>
      <p>${esc(f.prerequisites || 'Dossier de candidature et entretien de motivation.')}</p>
      ${f.specification ? `<h4>Ce que vous saurez faire</h4><p>${esc(f.specification)}</p>` : ''}
      <div class="modal-cta">
        <button type="button" class="btn btn-primary" onclick="prefillRegistration('${esc(f.code)}')"><i class="fas fa-pen-to-square"></i> S'inscrire à cette formation</button>
        <a class="btn btn-ghost" href="${whatsapp}" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i> Poser une question</a>
      </div>
    </div>`;
  modal.hidden = false;
  document.body.style.overflow = 'hidden';
  const close = $('.modal-close', modal);
  if (close) close.focus();
}

function closeFormation() {
  const modal = $('#formationModal');
  if (!modal) return;
  modal.hidden = true;
  document.body.style.overflow = '';
  if (lastFocused && lastFocused.focus) lastFocused.focus({ preventScroll: true });
}

function prefillRegistration(code) {
  closeFormation();
  navigateToSection('#inscription');
  const sel = $('#regFormation');
  if (sel) {
    const found = [...sel.options].find(o => o.value === code);
    if (found) { sel.value = code; sel.dispatchEvent(new Event('change', { bubbles: true })); }
    else { sel.focus(); toast('Choisissez la formation souhaitée dans la liste.', ''); return; }
  }
  setTimeout(() => {
    const spec = $('#regFormationSpec');
    if (spec) { spec.focus({ preventScroll: true }); spec.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
  }, 380);
}

/* --------------------------------------------------------------------------
   Carte de Yaoundé : recherche, géolocalisation, itinéraires, suivi
   -------------------------------------------------------------------------- */
const YAOUNDE = { center: [3.8667, 11.5167], zoom: 13, bounds: [[3.62, 11.26], [4.12, 11.82]] };
let map = null, A = null, B = null, mA = null, mB = null;
let routeLayers = [], routes = [], activeRoute = 0;
let followMarker = null, followTimer = null, pushWatch = null, followLayers = [];
let geoSeq = 0;

const mkIcon = c => L.divIcon({ className: '', html: `<div class="${c}"></div>`, iconSize: [26, 26], iconAnchor: [13, 26] });

function mapNotice(message, type = '') {
  const el = $('#mapNotice');
  if (!el) return;
  el.textContent = message;
  el.classList.remove('ok', 'ko');
  if (type) el.classList.add(type);
}

function initMap() {
  if (map) { map.invalidateSize(); return; }
  const el = $('#yaoundeRealMap');
  if (!el || typeof L === 'undefined') {
    mapNotice('La carte n\'a pas pu se charger. Vérifiez votre connexion puis rechargez la page.', 'ko');
    return;
  }
  map = L.map(el, { maxBounds: YAOUNDE.bounds, maxBoundsViscosity: 0.82, minZoom: 11 }).setView(YAOUNDE.center, YAOUNDE.zoom);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(map);
  L.control.scale({ imperial: false }).addTo(map);

  map.on('click', e => {
    if (!A) setPoint('A', e.latlng.lat, e.latlng.lng);
    else if (!B) setPoint('B', e.latlng.lat, e.latlng.lng);
    else setPoint('B', e.latlng.lat, e.latlng.lng);
  });

  const chips = $('#chips');
  if (chips) {
    ['Hôpital Central', 'Hôpital Général', 'CHU Yaoundé', 'Gare routière Mvan', 'Bastos', 'Odza', 'Mendong', 'Biyem-Assi', 'Mvog-Mbi', 'Melen'].forEach(name => {
      const b = document.createElement('button');
      b.type = 'button'; b.textContent = name;
      b.onclick = () => quickPlace(name);
      chips.appendChild(b);
    });
  }
  setupAutocomplete('from', 'A');
  setupAutocomplete('to', 'B');
}

async function quickPlace(name) {
  mapNotice('Recherche de « ' + name + ' »…');
  const r = await api('geocode', null, { q: name });
  if (Array.isArray(r) && r.length) {
    const which = A ? 'B' : 'A';
    setPoint(which, r[0].lat, r[0].lng, r[0].name || name);
    mapNotice('Lieu trouvé : ' + (r[0].label || name) + '.', 'ok');
  } else {
    mapNotice('Aucun résultat pour « ' + name + ' ». Essayez un autre quartier (Odza, Bastos, Melen…) ou cliquez directement sur la carte.', 'ko');
    toast('Lieu non trouvé. Vérifiez l\'orthographe ou cliquez sur la carte.', 'ko');
  }
}

function setPoint(which, lat, lng, label, opts = {}) {
  lat = Number(lat); lng = Number(lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
  const ll = [lat, lng];
  const input = $(which === 'A' ? '#fromInput' : '#toInput');
  const existing = which === 'A' ? mA : mB;

  if (existing) {
    existing.setLatLng(ll);
  } else {
    const marker = L.marker(ll, { icon: mkIcon(which === 'A' ? 'dot-a' : 'dot-b'), draggable: true, autoPan: true }).addTo(map);
    marker.on('dragend', () => {
      const p = marker.getLatLng();
      if (which === 'A') A = [p.lat, p.lng]; else B = [p.lat, p.lng];
      if (input) input.value = 'Position ajustée';
      reverseLabel(which);
      if (A && B) route();
    });
    if (which === 'A') mA = marker; else mB = marker;
  }
  if (which === 'A') A = ll; else B = ll;
  if (input) input.value = label || (lat.toFixed(5) + ', ' + lng.toFixed(5));
  if (!opts.noReverse) reverseLabel(which);
  if (A && B && opts.route !== false) route();
  else map.setView(ll, Math.max(map.getZoom(), 14));
}

async function reverseLabel(which) {
  const p = which === 'A' ? A : B;
  const input = $(which === 'A' ? '#fromInput' : '#toInput');
  if (!p || !input) return;
  const seq = ++geoSeq;
  const r = await api('reverse', null, { lat: p[0], lng: p[1] });
  if (seq !== geoSeq) return;
  if (r && r.label) input.value = r.label;
}

function setupAutocomplete(id, which) {
  const inp = $('#' + id + 'Input'), list = $('#' + id + 'List');
  if (!inp || !list) return;
  let timer = null, req = 0;

  inp.addEventListener('input', () => {
    clearTimeout(timer);
    const q = inp.value.trim();
    const my = ++req;
    if (q.length < 2) { list.innerHTML = ''; return; }
    timer = setTimeout(async () => {
      const r = await api('geocode', null, { q });
      if (my !== req) return;
      if (!Array.isArray(r) || !r.length) {
        list.innerHTML = '<li class="empty">Aucun lieu trouvé. Essayez « Odza », « Bastos », « Hôpital Central »… ou cliquez sur la carte.</li>';
        return;
      }
      list.innerHTML = r.map((x, i) => `<li data-i="${i}"><i class="fas fa-location-dot"></i> ${esc((x.label || x.name || '').split(',').slice(0, 3).join(','))}</li>`).join('');
      $$('li[data-i]', list).forEach(li => li.onclick = () => {
        const x = r[Number(li.dataset.i)];
        list.innerHTML = '';
        setPoint(which, x.lat, x.lng, (x.name || x.label || '').split(',')[0]);
        mapNotice('Lieu sélectionné : ' + (x.label || x.name) + '.', 'ok');
      });
    }, 260);
  });

  inp.addEventListener('keydown', e => {
    if (e.key === 'Escape') list.innerHTML = '';
    if (e.key === 'Enter') {
      const first = $('li[data-i]', list);
      if (first) { e.preventDefault(); first.click(); }
    }
  });

  document.addEventListener('click', e => { if (!e.target.closest('.ac')) list.innerHTML = ''; });
}

const FR_MOD = {
  left: 'à gauche', right: 'à droite', 'slight left': 'légèrement à gauche', 'slight right': 'légèrement à droite',
  'sharp left': 'franchement à gauche', 'sharp right': 'franchement à droite', straight: 'tout droit', uturn: 'faites demi-tour'
};
function frStep(s) {
  const m = s.maneuver || {}, n = s.name ? ' sur ' + s.name : '', d = FR_MOD[m.modifier] || '';
  switch (m.type) {
    case 'depart': return 'Partez' + n;
    case 'arrive': return 'Vous êtes arrivé' + (d ? ' (' + d + ')' : '');
    case 'turn': case 'end of road': return 'Tournez ' + d + n;
    case 'roundabout': case 'rotary': return 'Au rond-point, prenez la sortie ' + (m.exit || '') + n;
    case 'fork': return 'À l\'embranchement, gardez votre ' + ((m.modifier || '').includes('left') ? 'gauche' : 'droite') + n;
    case 'merge': return 'Insérez-vous ' + d + n;
    case 'continue': return 'Continuez ' + (d || 'tout droit') + n;
    default: return 'Continuez ' + (d || 'tout droit') + n;
  }
}
const fmtDist = m => Number(m) < 1000 ? Math.round(Number(m) || 0) + ' m' : (Number(m) / 1000).toFixed(1).replace('.', ',') + ' km';
const fmtTime = s => {
  const m = Math.max(1, Math.round((Number(s) || 0) / 60));
  return m < 60 ? m + ' min' : Math.floor(m / 60) + ' h ' + String(m % 60).padStart(2, '0');
};

async function route() {
  if (!A || !B) {
    mapNotice('Choisissez d\'abord un départ et une destination (recherche, clic sur la carte ou « Ma position »).', 'ko');
    toast('Indiquez le départ et la destination.', 'ko');
    return;
  }
  const profileEl = $('#routeMode');
  const profile = profileEl ? profileEl.value : 'driving';
  mapNotice('Calcul de l\'itinéraire…');
  const d = await api('route', null, {
    from_lat: A[0], from_lng: A[1], to_lat: B[0], to_lng: B[1], profile
  });
  if (!d || d.error || !Array.isArray(d.routes) || !d.routes.length) {
    mapNotice(d && d.error ? d.error : 'Itinéraire indisponible pour le moment. Vérifiez votre connexion et réessayez.', 'ko');
    toast('Itinéraire indisponible. Réessayez dans un instant.', 'ko');
    return;
  }
  routes = d.routes.slice(0, 3);
  activeRoute = 0;
  drawRoutes();
  if (d.fallback) {
    mapNotice('Itinéraire estimé en mode simplifié : le service de routage en ligne est momentanément indisponible. Distance et durée restent indicatives.', '');
  } else {
    mapNotice('Itinéraire calculé. Choisissez une option, puis envoyez votre demande.', 'ok');
  }
}

function drawRoutes() {
  if (!map || !routes.length) return;
  routeLayers.forEach(l => map.removeLayer(l));
  routeLayers = [];
  routes.forEach((r, i) => {
    if (i === activeRoute) return;
    const l = L.geoJSON(r.geometry, { style: { color: '#94A3B8', weight: 6, opacity: 0.8 } }).addTo(map);
    l.on('click', () => { activeRoute = i; drawRoutes(); });
    routeLayers.push(l);
  });
  const cur = L.geoJSON(routes[activeRoute].geometry, { style: { color: '#1A73E8', weight: 7, opacity: 0.95 } }).addTo(map);
  routeLayers.push(cur);
  try { map.fitBounds(cur.getBounds(), { padding: [46, 46] }); } catch (e) { /* géométrie vide */ }

  const tabs = $('#routeTabs');
  if (tabs) {
    tabs.innerHTML = routes.map((r, i) => `<button type="button" class="${i === activeRoute ? 'on' : ''}" data-i="${i}">${i === 0 ? 'Rapide' : 'Option ' + (i + 1)}<br>${fmtTime(r.duration)}</button>`).join('');
    $$('#routeTabs button').forEach(b => b.onclick = () => { activeRoute = Number(b.dataset.i); drawRoutes(); });
  }
  const r = routes[activeRoute];
  const eta = new Date(Date.now() + (Number(r.duration) || 0) * 1000);
  if ($('#estTime')) $('#estTime').textContent = fmtTime(r.duration);
  if ($('#estDist')) $('#estDist').textContent = fmtDist(r.distance);
  if ($('#estEta')) $('#estEta').textContent = eta.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  const box = $('#routeBox'); if (box) box.hidden = false;
  const steps = (r.legs && r.legs[0] && r.legs[0].steps) || [];
  if ($('#steps')) $('#steps').innerHTML = steps.map(s => `<li>${esc(frStep(s))} <span>(${fmtDist(s.distance)})</span></li>`).join('');
}

function locateMe() {
  if (!navigator.geolocation) {
    mapNotice('La géolocalisation n\'est pas disponible sur ce navigateur. Cliquez sur la carte ou recherchez votre quartier.', 'ko');
    toast('Géolocalisation non disponible sur ce navigateur.', 'ko');
    return;
  }
  mapNotice('Recherche de votre position…');
  navigator.geolocation.getCurrentPosition(
    p => {
      setPoint('A', p.coords.latitude, p.coords.longitude, 'Ma position');
      const inYaounde = p.coords.latitude > 3.5 && p.coords.latitude < 4.2 && p.coords.longitude > 11.2 && p.coords.longitude < 11.9;
      mapNotice(inYaounde ? 'Position trouvée. Choisissez maintenant la destination.' : 'Position trouvée, mais elle semble en dehors de Yaoundé. Vérifiez le point sur la carte.', inYaounde ? 'ok' : '');
      toast('Votre position a été placée sur la carte.', 'ok');
    },
    err => {
      const msg = err.code === 1
        ? 'Position refusée. Autorisez la localisation dans les réglages du navigateur, ou recherchez votre quartier.'
        : err.code === 3
          ? 'La recherche de position a expiré. Réessayez ou choisissez un quartier dans la liste.'
          : 'Position indisponible. Vérifiez le GPS / la connexion, ou cliquez sur la carte.';
      mapNotice(msg, 'ko');
      toast(msg, 'ko');
    },
    { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 }
  );
}

function clearRoute() {
  A = null; B = null;
  [mA, mB].forEach(m => { if (m && map) map.removeLayer(m); });
  mA = mB = null;
  routeLayers.forEach(l => { if (map) map.removeLayer(l); });
  routeLayers = []; routes = []; activeRoute = 0;
  if ($('#routeBox')) $('#routeBox').hidden = true;
  if ($('#fromInput')) $('#fromInput').value = '';
  if ($('#toInput')) $('#toInput').value = '';
  if ($('#steps')) $('#steps').innerHTML = '';
  mapNotice('Carte effacée. Cliquez pour placer le départ, puis la destination.');
}

function clearFollowLayers() {
  if (map) {
    followLayers.forEach(l => map.removeLayer(l));
    if (followMarker) map.removeLayer(followMarker);
  }
  followLayers = []; followMarker = null;
}

function stopFollow() {
  clearInterval(followTimer); followTimer = null;
  clearFollowLayers();
  const b = $('#btnStopFollow'); if (b) b.hidden = true;
  if ($('#followState')) $('#followState').textContent = '';
}

function startFollow(code) {
  code = String(code || '').trim().toUpperCase();
  const state = $('#followState');
  const stopBtn = $('#btnStopFollow');
  if (!code) { if (state) state.textContent = 'Saisissez le code de suivi.'; return; }
  clearInterval(followTimer);
  clearFollowLayers();
  if (stopBtn) stopBtn.hidden = false;
  let drawn = false;
  let lastPan = 0;
  const tick = async () => {
    const r = await api('track_get', null, { code });
    if (r.error) {
      if (state) state.textContent = r.error;
      clearInterval(followTimer); followTimer = null;
      if (stopBtn) stopBtn.hidden = true;
      return;
    }
    const req = r.request || {};
    if (!drawn && map && (req.from_lat || req.to_lat)) {
      const start = req.from_lat && req.from_lng ? [Number(req.from_lat), Number(req.from_lng)] : null;
      const end = req.to_lat && req.to_lng ? [Number(req.to_lat), Number(req.to_lng)] : null;
      if (start) followLayers.push(L.marker(start, { icon: mkIcon('dot-a') }).addTo(map).bindPopup('Départ'));
      if (end) followLayers.push(L.marker(end, { icon: mkIcon('dot-b') }).addTo(map).bindPopup('Destination'));
      if (start && end) followLayers.push(L.polyline([start, end], { color: '#1A73E8', weight: 4, dashArray: '7 9', opacity: 0.85 }).addTo(map));
      if (followLayers.length) { try { map.fitBounds(L.featureGroup(followLayers).getBounds(), { padding: [40, 40] }); } catch (e) { /* ignore */ } }
      drawn = true;
    }
    if (!r.position) { if (state) state.textContent = 'Demande trouvée. En attente de la position de l\'intervenant…'; return; }
    const p = [Number(r.position.lat), Number(r.position.lng)];
    const age = Math.max(0, Math.round(Date.now() / 1000 - Number(r.position.ts || 0)));
    if (state) state.textContent = `Intervenant localisé (mise à jour il y a ${age} s). Suivi actif.`;
    if (followMarker) followMarker.setLatLng(p);
    else if (map) followMarker = L.marker(p, { icon: mkIcon('dot-p') }).addTo(map).bindPopup('Intervenant');
    if (map && Date.now() - lastPan > 12000) { map.panTo(p); lastPan = Date.now(); }
  };
  tick();
  followTimer = setInterval(tick, 5000);
}

function copyText(text, okMessage) {
  const done = () => toast(okMessage || 'Lien copié.', 'ok');
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(text).then(done).catch(() => toast('Copiez le lien manuellement.', ''));
    return;
  }
  const ta = document.createElement('textarea');
  ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta); ta.select();
  try { document.execCommand('copy'); done(); } catch (e) { toast('Copiez le lien manuellement.', ''); }
  ta.remove();
}

function bindMap() {
  const locate = $('#btnLocate'); if (locate) locate.onclick = locateMe;
  const routeBtn = $('#btnRoute'); if (routeBtn) routeBtn.onclick = route;
  const recenter = $('#btnRecenter');
  if (recenter) recenter.onclick = () => { if (!map) initMap(); if (map) map.setView(YAOUNDE_SAFE(), YAOUNDE.zoom); mapNotice('Carte recentrée sur Yaoundé.'); };
  const swap = $('#btnSwap');
  if (swap) swap.onclick = () => {
    if (!A || !B) { toast('Placez d\'abord un départ et une destination.', 'ko'); return; }
    const oldA = A, oldB = B, fa = $('#fromInput') ? $('#fromInput').value : '', fb = $('#toInput') ? $('#toInput').value : '';
    A = null; B = null;
    setPoint('A', oldB[0], oldB[1], fb, { route: false, noReverse: true });
    setPoint('B', oldA[0], oldA[1], fa, { route: false, noReverse: true });
    route();
  };
  const clear = $('#btnClear'); if (clear) clear.onclick = clearRoute;
  const mode = $('#routeMode'); if (mode) mode.addEventListener('change', route);

  const request = $('#btnRequest');
  if (request) request.onclick = async () => {
    const r = routes[activeRoute];
    const out = $('#reqResult');
    const name = $('#reqName') ? $('#reqName').value.trim() : '';
    const phone = $('#reqPhone') ? $('#reqPhone').value.trim() : '';
    if (!A || !B || !r) { if (out) out.innerHTML = '<p class="err">Calculez d\'abord un itinéraire entre un départ et une destination.</p>'; return; }
    if (!name || !phone) { if (out) out.innerHTML = '<p class="err">Indiquez votre nom et votre téléphone.</p>'; return; }
    const sel = $('#reqService');
    const res = await api('request_create', {
      name, phone,
      service: sel && sel.selectedOptions[0] ? sel.selectedOptions[0].text : 'Service',
      details: $('#reqDetails') ? $('#reqDetails').value : '',
      from_lat: A[0], from_lng: A[1], to_lat: B[0], to_lng: B[1],
      distance_m: Math.round(Number(r.distance) || 0), duration_s: Math.round(Number(r.duration) || 0)
    });
    if (res.error) { if (out) out.innerHTML = `<p class="err">${esc(res.error)}</p>`; return; }
    const share = res.share_url || (location.origin + location.pathname + '?suivi=' + encodeURIComponent(res.code) + '#suivi');
    if (out) {
      out.innerHTML = `<div class="okmsg">Demande envoyée. Code de suivi client : <b>${esc(res.code)}</b><br>Clé intervenant : <b>${esc(res.pkey)}</b></div>
        <p class="hint">Partagez ce lien avec le client concerné : il pourra suivre la position en direct.</p>
        <input readonly id="shareUrlInput" value="${esc(share)}">
        <div class="row"><button type="button" class="btn btn-ghost small" id="btnCopyShare"><i class="fas fa-link"></i> Copier le lien client</button><button type="button" class="btn btn-primary small" id="btnOpenFollow"><i class="fas fa-location-crosshairs"></i> Suivre maintenant</button></div>`;
    }
    if ($('#followCode')) $('#followCode').value = res.code;
    if ($('#pushKey')) $('#pushKey').value = res.pkey;
    const copy = $('#btnCopyShare'); if (copy) copy.onclick = () => copyText(share, 'Lien client copié.');
    const open = $('#btnOpenFollow'); if (open) open.onclick = () => startFollow(res.code);
    toast('Demande envoyée. Votre code de suivi est ' + res.code + '.', 'ok');
  };

  const follow = $('#btnFollow');
  if (follow) follow.onclick = () => startFollow($('#followCode') ? $('#followCode').value : '');

  const stopBtn = $('#btnStopFollow'); if (stopBtn) stopBtn.onclick = stopFollow;

  const push = $('#btnPush');
  if (push) push.onclick = () => {
    const btn = push;
    if (pushWatch !== null) {
      navigator.geolocation.clearWatch(pushWatch); pushWatch = null;
      btn.textContent = 'Partager ma position';
      toast('Partage de position arrêté.', '');
      return;
    }
    const code = ($('#followCode') ? $('#followCode').value : '').trim().toUpperCase();
    const pkey = ($('#pushKey') ? $('#pushKey').value : '').trim();
    if (!code || !pkey) { toast('Saisissez le code de la demande et la clé intervenant.', 'ko'); return; }
    if (!navigator.geolocation) { toast('La géolocalisation n\'est pas disponible sur ce téléphone.', 'ko'); return; }
    let last = 0;
    pushWatch = navigator.geolocation.watchPosition(p => {
      if (Date.now() - last < 4000) return;
      last = Date.now();
      api('track_push', { code, pkey, lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy }).then(r => {
        if (r.error) { if ($('#followState')) $('#followState').textContent = r.error; }
        else if ($('#followState')) $('#followState').textContent = 'Position partagée en direct. Gardez la page ouverte.';
      });
    }, () => toast('Impossible d\'obtenir la position pour le partage.', 'ko'), { enableHighAccuracy: true, maximumAge: 5000 });
    btn.textContent = 'Arrêter le partage';
    toast('Partage de position démarré.', 'ok');
  };
}

function YAOUNDE_SAFE() { return CONF && CONF.map && Array.isArray(CONF.map.center) ? CONF.map.center : YAOUNDE.center; }

/* --------------------------------------------------------------------------
   Inscription + fonds de garantie
   -------------------------------------------------------------------------- */
let payTimer = null, payMode = 'sim';

function bindRegister() {
  const form = $('#registerForm');
  if (!form) return;
  const type = $('#regType');
  const formSel = $('#regFormation');
  const codeInput = $('#regFormationCode');
  const spec = $('#regFormationSpec');
  let lastSpec = '';

  const toggleType = () => {
    const provider = type && type.value === 'prestataire';
    const pf = $('#prestataireFields'), cf = $('#clientFields'), submit = $('#regSubmit');
    if (pf) pf.hidden = !provider;
    if (cf) cf.hidden = provider;
    ['#regPhone', '#regAmount', '#regServiceDescription'].forEach(s => {
      const el = $(s); if (el) el.required = provider;
    });
    $('#regPaymentMethod') && ($('#regPaymentMethod').required = false);
    if (submit) submit.textContent = provider ? 'Payer le fonds de garantie' : 'Créer mon compte';
    const amount = $('#regAmount');
    if (amount && provider && Number(amount.value) < CONF.min_guarantee) amount.value = CONF.min_guarantee;
  };

  if (type) type.addEventListener('change', toggleType);
  toggleType();

  if (formSel) formSel.addEventListener('change', () => {
    const code = formSel.value;
    const f = FORMATIONS.find(x => x.code === code);
    if (codeInput) codeInput.value = code;
    if (spec) {
      const auto = !spec.value.trim() || spec.value === lastSpec;
      if (!code) { if (auto) spec.value = ''; lastSpec = ''; }
      else if (code === 'AUTRE') { if (auto) spec.value = ''; lastSpec = ''; }
      else if (f && auto) { spec.value = f.specification || ''; lastSpec = spec.value; }
    }
  });

  form.addEventListener('submit', async e => {
    e.preventDefault();
    if (form.dataset.busy === '1') return;
    const provider = type && type.value === 'prestataire';
    const name = ($('#regName') ? $('#regName').value : '').trim();
    const contact = ($('#regContact') ? $('#regContact').value : '').trim();
    const email = ($('#regEmail') ? $('#regEmail').value : '').trim();
    const location = ($('#regLocation') ? $('#regLocation').value : '').trim();
    const zone = ($('#regZone') ? $('#regZone').value : '').trim();
    const formationCode = formSel ? formSel.value : '';
    const formationSpec = spec ? spec.value.trim() : '';
    const description = ($('#regServiceDescription') ? $('#regServiceDescription').value : '').trim();
    const experience = $('#regExperience') ? $('#regExperience').value : '';
    const notes = ($('#regMessage') ? $('#regMessage').value : '').trim();
    const amount = $('#regAmount') ? Number($('#regAmount').value) : 0;
    const phone = $('#regPhone') ? $('#regPhone').value.trim() : '';
    const terms = $('#regTerms');

    const fail = (msg, focus) => { toast(msg, 'ko'); showError(msg, true); if (focus && focus.focus) focus.focus({ preventScroll: false }); };

    if (!name) return fail('Indiquez votre nom complet.', $('#regName'));
    if (!contact) return fail('Indiquez votre téléphone / WhatsApp.', $('#regContact'));
    if (!/^\+?[0-9\s().-]{7,20}$/.test(contact)) return fail('Le numéro de contact est invalide.', $('#regContact'));
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail('L\'adresse e-mail est invalide.', $('#regEmail'));
    if (!location) return fail('Indiquez votre quartier.', $('#regLocation'));
    // La formation est facultative : on ne bloque plus l'inscription si elle n'est pas choisie.
    if (provider && formationCode === 'AUTRE') return fail('Choisissez une formation de la liste, ou « Aucune formation », pour un compte prestataire.', formSel);
    if (formationCode === 'AUTRE' && formationSpec.length < 10) return fail('Précisez votre autre demande (10 caractères minimum) ou choisissez une formation.', spec);
    if (formationCode && formationCode !== 'AUTRE' && formationSpec && formationSpec.length < 10) return fail('Vos précisions sur la formation doivent contenir au moins 10 caractères (ou rester vides).', spec);
    if (provider && description.length < 20) return fail('Décrivez votre prestation (20 caractères minimum).', $('#regServiceDescription'));
    if (provider && !phone) return fail('Indiquez le numéro Mobile Money à débiter.', $('#regPhone'));
    if (provider && !/^\+?[0-9\s().-]{7,20}$/.test(phone)) return fail('Le numéro Mobile Money est invalide.', $('#regPhone'));
    if (provider && (!Number.isFinite(amount) || amount < CONF.min_guarantee)) return fail('Le fonds de garantie minimum est de ' + fcfa(CONF.min_guarantee) + '.', $('#regAmount'));
    if (!terms || !terms.checked) return fail('Vous devez accepter l\'utilisation de vos informations.', terms);

    form.dataset.busy = '1';
    const submit = $('#regSubmit');
    if (submit) { submit.disabled = true; submit.dataset.label = submit.textContent; submit.textContent = 'Envoi en cours…'; }
    $('#registrationError') && ($('#registrationError').hidden = true);

    const payload = new FormData();
    payload.append('website', $('#regWebsite') ? $('#regWebsite').value : '');
    payload.append('name', name);
    payload.append('contact', contact);
    payload.append('email', email);
    payload.append('location', location);
    payload.append('zone', zone);
    payload.append('type', provider ? 'prestataire' : 'client');
    payload.append('formation_code', formationCode);
    payload.append('formation_spec', formationSpec);
    payload.append('service_description', description);
    payload.append('experience', experience);
    payload.append('notes', notes);
    payload.append('references', $('#regReferences') ? $('#regReferences').value.trim() : '');
    payload.append('phone', provider ? phone : '');
    payload.append('amount', provider ? amount : 0);
    payload.append('payment_method', $('#regPaymentMethod') ? $('#regPaymentMethod').value : '');
    payload.append('gateway', $('#regGateway') ? $('#regGateway').value : 'campay');
    ['id_doc', 'diploma_doc'].forEach(k => {
      const inp = document.getElementById(k === 'id_doc' ? 'regIdDoc' : 'regDiplomaDoc');
      if (inp && inp.files && inp.files[0]) {
        if (inp.files[0].size > 4 * 1024 * 1024) { payload.append(k + '_too_big', '1'); return; }
        payload.append(k, inp.files[0]);
      }
    });
    if (payload.get('id_doc_too_big') || payload.get('diploma_doc_too_big')) {
      form.dataset.busy = '0';
      if (submit) { submit.disabled = false; submit.textContent = submit.dataset.label || (provider ? 'Payer le fonds de garantie' : 'Créer mon compte'); }
      return fail('Chaque document doit faire moins de 4 Mo.', $('#regIdDoc'));
    }
    const res = await api('register', payload);
    form.dataset.busy = '0';
    if (submit) { submit.disabled = false; submit.textContent = submit.dataset.label || (provider ? 'Payer le fonds de garantie' : 'Créer mon compte'); }

    if (res.error) { showError(res.error, true); toast(res.error, 'ko'); return; }
    form.hidden = true;

    if (!provider) {
      showSuccess('Votre compte client a bien été créé' + (res.formation_code ? ' pour la formation ' + res.formation_code : '') + '. Nous vous recontactons rapidement.');
      toast('Compte créé avec succès.', 'ok');
      return;
    }

    if (res.pay_url) {
      const box = $('#payBox');
      if (box) box.hidden = false;
      if ($('#payTitle')) $('#payTitle').textContent = 'Redirection vers Orange Money…';
      if ($('#payText')) $('#payText').textContent = 'Vous allez saisir votre code secret sur la page sécurisée de votre opérateur.';
      setTimeout(() => { location.href = res.pay_url; }, 1300);
      return;
    }

    const box = $('#payBox');
    if (box) box.hidden = false;
    payMode = res.mode || 'sim';
    if ($('#payTitle')) {
      $('#payTitle').textContent = payMode === 'sim' ? 'Simulation de paiement' : payMode === 'test' ? 'Paiement en mode test' : 'Vérifiez votre téléphone';
    }
    if ($('#payText')) {
      $('#payText').innerHTML = payMode === 'sim'
        ? 'Aucune passerelle n\'est configurée : le paiement du fonds de garantie est simulé et sera validé automatiquement.'
        : payMode === 'test'
          ? 'Environnement de <b>test</b> de l\'opérateur : aucun message n\'est envoyé et aucun argent réel n\'est débité.'
          : `Un message de ${esc(res.operator || 'votre opérateur')} vient d'arriver sur le téléphone au <b>${esc(phone)}</b> (le numéro de votre puce). Saisissez votre <b>code secret</b> directement sur ce téléphone pour confirmer. Ne saisissez jamais ce code sur le site.` + (res.ussd_code ? `<br>Rien reçu ? Composez <b>${esc(res.ussd_code)}</b>.` : '');
    }
    if (res.payment_id && res.payment_token) pollPayment(res.payment_id, res.payment_token);
    else showError('Le paiement n\'a pas pu être initialisé. Réessayez.', true);
  });

  const retry = $('#btnRetryRegistration');
  if (retry) retry.onclick = () => { $('#registrationError').hidden = true; form.hidden = false; if (formSel) formSel.focus(); };
  const again = $('#btnNewRegistration');
  if (again) again.onclick = () => resetRegistration();
}

function resetRegistration() {
  clearInterval(payTimer); payTimer = null;
  const form = $('#registerForm');
  if (form) { form.reset(); form.hidden = false; delete form.dataset.busy; }
  ['#registrationSuccess', '#registrationError', '#payBox'].forEach(s => { const el = $(s); if (el) el.hidden = true; });
  const code = $('#regFormationCode'); if (code) code.value = '';
  const spec = $('#regFormationSpec'); if (spec) spec.value = '';
  const amount = $('#regAmount'); if (amount) amount.value = CONF.min_guarantee;
  const type = $('#regType'); if (type) type.dispatchEvent(new Event('change', { bubbles: true }));
  if ($('#payMeta')) $('#payMeta').textContent = '';
  if ($('#successReceipt')) $('#successReceipt').innerHTML = '';
  const submit = $('#regSubmit');
  if (submit) { submit.disabled = false; submit.textContent = 'Créer mon compte'; }
  window.scrollTo({ top: $('#inscription') ? $('#inscription').offsetTop : 0, behavior: 'smooth' });
}

function pollPayment(id, token) {
  clearInterval(payTimer);
  let n = 0;
  const tick = async () => {
    n++;
    if ($('#payMeta')) $('#payMeta').textContent = 'Vérification en cours… ' + (n * 3) + ' s';
    const r = await api('pay_status', null, { id, token });
    if (r.error) { if (n > 3) { clearInterval(payTimer); $('#payBox') && ($('#payBox').hidden = true); showError(r.error, true); } return; }
    if (r.status === 'SUCCESS') {
      clearInterval(payTimer); payTimer = null;
      $('#payBox') && ($('#payBox').hidden = true);
      const form = $('#registerForm'); if (form) form.hidden = true;
      setReceiptLink(id, token);
      showSuccess('Paiement confirmé. Votre fonds de garantie est bloqué en sécurité et votre compte prestataire est actif.' + (payMode !== 'live' ? ' (Mode ' + (payMode === 'sim' ? 'simulation' : 'test') + ' : aucun argent réel n\'a été débité.)' : ''));
      toast('Paiement confirmé, compte activé.', 'ok');
    } else if (r.status === 'FAILED') {
      clearInterval(payTimer); payTimer = null;
      $('#payBox') && ($('#payBox').hidden = true);
      showError('Le paiement a été refusé ou annulé (solde insuffisant, code erroné ou délai dépassé).', true);
      toast('Paiement refusé ou annulé.', 'ko');
    } else if (n >= 60) {
      clearInterval(payTimer); payTimer = null;
      $('#payBox') && ($('#payBox').hidden = true);
      showError('Délai dépassé : aucune confirmation reçue. Vérifiez votre téléphone puis réessayez.', true);
    }
  };
  tick();
  payTimer = setInterval(tick, 3000);
}

function showSuccess(text) {
  const el = $('#registrationSuccess'); if (!el) return;
  if ($('#successDetails')) $('#successDetails').textContent = text;
  el.hidden = false;
  const err = $('#registrationError'); if (err) err.hidden = true;
  el.scrollIntoView({ behavior: 'smooth', block: 'center' });
}
function setReceiptLink(paymentId, token) {
  const box = $('#successReceipt');
  if (!box) return;
  if (!paymentId || !token) { box.innerHTML = ''; return; }
  const url = 'receipt.php?id=' + encodeURIComponent(paymentId) + '&token=' + encodeURIComponent(token);
  box.innerHTML = '<a class="btn btn-primary" style="margin-top:1rem" href="' + url + '" target="_blank" rel="noopener"><i class="fas fa-receipt"></i> Télécharger mon reçu</a>';
}
function showError(text, retry = false) {
  const el = $('#registrationError'); if (!el) return;
  if ($('#errorDetails')) $('#errorDetails').textContent = text;
  el.hidden = false;
  const ok = $('#registrationSuccess'); if (ok) ok.hidden = true;
  const btn = $('#btnRetryRegistration'); if (btn) btn.hidden = !retry;
  if (!retry) setTimeout(() => { el.hidden = true; }, 6000);
}

/* --------------------------------------------------------------------------
   Contact : enregistrement en base + WhatsApp
   -------------------------------------------------------------------------- */
function bindContact() {
  const form = $('#contactForm');
  if (!form) return;
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const name = ($('#cName') ? $('#cName').value : '').trim();
    const phone = ($('#cPhone') ? $('#cPhone').value : '').trim();
    const email = ($('#cEmail') ? $('#cEmail').value : '').trim();
    const needSel = $('#cNeed');
    const need = needSel && needSel.selectedOptions[0] ? needSel.selectedOptions[0].text : 'Information';
    const message = ($('#cMsg') ? $('#cMsg').value : '').trim();
    const result = $('#contactResult');
    if (!name || !phone || message.length < 5) {
      if (result) result.textContent = 'Indiquez votre nom, un téléphone valide et précisez votre besoin.';
      toast('Complétez votre nom, votre téléphone et votre message.', 'ko');
      return;
    }
    const win = window.open('', '_blank');
    if (win) { try { win.document.write('<p style="font-family:sans-serif;padding:2rem">Ouverture de WhatsApp…</p>'); } catch (err) { /* ignore */ } }
    const btn = $('#cSubmit'); if (btn) { btn.disabled = true; btn.dataset.label = btn.innerHTML; btn.textContent = 'Envoi…'; }
    const val = needSel ? needSel.value : '';
    const res = await api('contact', {
      name, phone, email,
      need,
      formation_code: /^[A-Z]{2,4}$/.test(val) ? val : '',
      message,
      website: $('#cWebsite') ? $('#cWebsite').value : ''
    });
    if (btn) { btn.disabled = false; btn.innerHTML = btn.dataset.label || '<i class="fab fa-whatsapp"></i> Envoyer ma demande'; }
    if (res.error) {
      if (win) win.close();
      if (result) result.textContent = res.error;
      toast(res.error, 'ko');
      return;
    }
    if (result) result.textContent = 'Message enregistré. WhatsApp s\'ouvre avec votre demande préremplie.';
    const url = res.whatsapp || ('https://wa.me/' + Y4I.whatsapp + '?text=' + encodeURIComponent('Bonjour Y4I Academy, je suis ' + name + ' (' + phone + '). ' + message));
    if (win) win.location.href = url; else window.open(url, '_blank', 'noopener');
    toast('Message enregistré. Merci !', 'ok');
    form.reset();
  });
}

/* --------------------------------------------------------------------------
   Rappel express
   -------------------------------------------------------------------------- */
function bindCallback() {
  const form = $('#callbackForm');
  if (!form) return;
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const name = ($('#cbName') ? $('#cbName').value : '').trim();
    const phone = ($('#cbPhone') ? $('#cbPhone').value : '').trim();
    const need = $('#cbNeed') ? $('#cbNeed').value : 'Rappel';
    const result = $('#callbackResult');
    if (!name || !/^\+?[0-9\s().-]{7,20}$/.test(phone)) {
      if (result) result.textContent = 'Indiquez votre nom et un numéro valide.';
      toast('Indiquez votre nom et un numéro valide.', 'ko');
      return;
    }
    const btn = form.querySelector('button[type="submit"]');
    if (btn) { btn.disabled = true; btn.dataset.label = btn.innerHTML; btn.textContent = 'Envoi…'; }
    const res = await api('callback_create', { name, phone, need, website: $('#cbWebsite') ? $('#cbWebsite').value : '' });
    if (btn) { btn.disabled = false; btn.innerHTML = btn.dataset.label || '<i class="fas fa-phone"></i> Rappelez-moi'; }
    if (res.error) { if (result) result.textContent = res.error; toast(res.error, 'ko'); return; }
    if (result) result.textContent = 'Demande enregistrée. Nous vous rappelons rapidement.';
    toast('Demande de rappel envoyée. Merci !', 'ok');
    form.reset();
  });
}

/* --------------------------------------------------------------------------
   Administration
   -------------------------------------------------------------------------- */
function lockAdminUI() {
  const dash = $('#adminDashboard'), login = $('#adminLogin');
  if (dash) dash.hidden = true;
  if (login) login.hidden = false;
  const p = $('#adminPasswordInput'); if (p) p.value = '';
  stopAdminTracking();
}

async function loadAdmin() {
  const d = await api('admin_data');
  if (!d || d.error || !Array.isArray(d.accounts)) { lockAdminUI(); if (d && d.error) toast(d.error, 'ko'); return; }
  const dash = $('#adminDashboard'), login = $('#adminLogin');
  if (dash) dash.hidden = false;
  if (login) login.hidden = true;

  const s = d.stats || {};
  if ($('#adminStats')) {
    $('#adminStats').innerHTML = [
      ['Comptes', s.accounts, 'clients + prestataires'],
      ['Clients', s.clients, 'demandeurs / apprenants'],
      ['Prestataires', s.providers, s.active_providers + ' actif(s)'],
      ['Garanties bloquées', fcfa(s.guarantee_total), s.pending_payments + ' en attente'],
      ['Remboursé', fcfa(s.guarantee_refunded), 'fonds restitués'],
      ['Demandes', s.requests, 'de service'],
      ['Messages', s.messages_new, 'nouveaux'],
      ['Formations', s.formations, 'parcours actifs'],
      ['À vérifier', s.pending_verifications, 'prestataires']
    ].map(([label, value, sub]) => `<div class="stat-card"><small>${esc(label)}</small><b>${typeof value === 'number' ? value : esc(value)}</b><span>${esc(sub)}</span></div>`).join('');
  }

  if ($('#formationsAdminBody')) {
    $('#formationsAdminBody').innerHTML = (d.formations || []).map(f => `<tr data-id="${f.id}">
      <td><b>${esc(f.code)}</b></td>
      <td><input data-k="title" value="${esc(f.title)}" maxlength="140"></td>
      <td><input data-k="duration" value="${esc(f.duration)}" maxlength="100"></td>
      <td><input data-k="price" type="number" min="0" step="1" value="${Number(f.price) || 0}"></td>
      <td><input data-k="active" type="checkbox" ${Number(f.active) ? 'checked' : ''}></td>
    </tr>`).join('') || '<tr><td colspan="5">Aucune formation.</td></tr>';
  }

  if ($('#tariffInputs')) {
    $('#tariffInputs').innerHTML = (d.tariffs || []).map(t => `<div class="field"><label>${esc(t.label)} (FCFA)</label><input type="number" min="0" step="1" data-k="${esc(t.k)}" value="${Number(t.price) || 0}"></div>`).join('');
  }
  if ($('#adminMinGuarantee')) $('#adminMinGuarantee').value = d.min_guarantee;

  if ($('#gatewayStatus')) {
    const G = { campay: 'Campay — Orange Money & MTN MoMo', mtn: 'MTN MoMo (API directe)', orange: 'Orange Money Web Pay' };
    $('#gatewayStatus').innerHTML = Object.keys(G).map(k => {
      const ready = !!(d.gateways && d.gateways[k]);
      const mode = (d.modes && d.modes[k]) || 'sim';
      const label = !ready ? 'Non configuré · simulation' : (mode === 'test' ? 'Configuré · mode test' : 'Configuré · production');
      return `<div class="gw-row"><span><b>${esc(G[k])}</b><small>${esc(label)}</small></span><span class="tag ${!ready ? 't-wait' : (mode === 'test' ? 't-wait' : 't-ok')}">${!ready ? 'Simulation' : (mode === 'test' ? 'Test' : 'Réel')}</span></div>`;
    }).join('') + '<p class="hint">Pour encaisser réellement : renseignez <b>campay.username</b> et <b>campay.password</b> dans <code>config.php</code>, avec la base de production.</p>';
  }

  const cls = st => st === 'Actif' ? 't-ok' : (st === 'Bloqué' || st === 'Paiement échoué') ? 't-ko' : 't-wait';
  const pst = { SUCCESS: ['t-ok', 'bloqué'], REFUNDED: ['t-wait', 'remboursé'], PENDING: ['t-wait', 'en attente'], FAILED: ['t-ko', 'échoué'] };
  if ($('#accountsTableBody')) {
    $('#accountsTableBody').innerHTML = (d.accounts || []).map(a => {
      const pay = pst[a.pay_status] || null;
      return `<tr>
        <td><b>${esc(a.name)}</b></td>
        <td>${esc(a.contact)}</td>
        <td>${esc(a.location)}</td>
        <td>${esc(a.type)}</td>
        <td>${a.formation_code ? `<b>${esc(a.formation_code)}</b><br><small>${esc(a.formation_label || '')}</small>` : '—'}</td>
        <td style="max-width:220px">${a.service_description ? `<span title="${esc(a.service_description)}">${esc(a.service_description.length > 90 ? a.service_description.slice(0, 90) + '…' : a.service_description)}</span>` : '—'}</td>
        <td>${a.type === 'Prestataire' && a.amount ? fcfa(a.amount) + (pay ? ' · ' + esc(pay[1]) : '') : '—'}</td>
        <td><span class="tag ${cls(a.status)}">${esc(a.status)}</span></td>
        <td>
          <button class="mini" style="background:${a.status === 'Actif' ? '#C8102E' : '#10B981'}" data-t="${a.id}">${a.status === 'Actif' ? 'Bloquer' : 'Activer'}</button>
          ${a.pay_status === 'SUCCESS' ? `<button class="mini" style="background:#0033A0" data-r="${a.id}">Rembourser</button>` : ''}
          <button class="mini" style="background:#64748B" data-d="${a.id}" data-n="${esc(a.name)}">Supprimer</button>
        </td></tr>`;
    }).join('') || '<tr><td colspan="9">Aucun compte.</td></tr>';
    $$('#accountsTableBody [data-t]').forEach(b => b.onclick = async () => { await api('admin_toggle', { id: b.dataset.t }); loadAdmin(); });
    $$('#accountsTableBody [data-r]').forEach(b => b.onclick = async () => {
      if (!confirm('Rembourser ce fonds de garantie ?')) return;
      const r = await api('admin_refund', { id: b.dataset.r });
      toast(r.error || r.note || 'Fonds remboursé.', r.error ? 'ko' : 'ok');
      loadAdmin();
    });
    $$('#accountsTableBody [data-d]').forEach(b => b.onclick = async () => {
      if (!confirm(`Supprimer définitivement le compte « ${b.dataset.n} » ?\nL'historique des transactions et du journal est conservé.`)) return;
      const r = await api('admin_delete', { id: b.dataset.d });
      if (r.error) toast(r.error, 'ko'); else toast('Compte supprimé.', 'ok');
      loadAdmin();
    });
  }

  if ($('#verifyBody')) {
    const provs = (d.accounts || []).filter(a => a.type === 'Prestataire');
    const VCLS = { 'Vérifié': 't-ok', 'Refusé': 't-ko', 'En attente': 't-wait', 'Documents partiels': 't-wait', 'Documents à fournir': 't-wait' };
    $('#verifyBody').innerHTML = provs.map(a => {
      const doc = (k, label) => a[k] ? `<a class="mini" style="background:#0033A0;text-decoration:none;display:inline-block;margin:2px" href="api.php?action=admin_doc&id=${a.id}&doc=${k}" target="_blank" rel="noopener">${label}</a>` : `<span class="hint">${label} : non fourni</span>`;
      return `<tr>
        <td><b>${esc(a.name)}</b><br><small>${esc(a.contact)}</small></td>
        <td>${doc('id_doc', 'Pièce d’identité')}<br>${doc('diploma_doc', 'Diplôme / certificat')}</td>
        <td style="max-width:220px;white-space:normal">${esc(a.refs || '—')}</td>
        <td><span class="tag ${VCLS[a.verify_status] || 't-wait'}">${esc(a.verify_status || 'Non vérifié')}</span>${a.verified_at ? '<br><small>' + esc(a.verified_at) + '</small>' : ''}</td>
        <td><input data-vnote="${a.id}" value="${esc(a.verify_note || '')}" placeholder="Note interne" maxlength="240" style="min-width:160px"></td>
        <td>
          <button class="mini" style="background:#10B981" data-vid="${a.id}" data-vst="Vérifié">Vérifié</button>
          <button class="mini" style="background:#C8102E" data-vid="${a.id}" data-vst="Refusé">Refusé</button>
          <button class="mini" style="background:#64748B" data-vid="${a.id}" data-vst="En attente">En attente</button>
        </td></tr>`;
    }).join('') || '<tr><td colspan="6">Aucun prestataire inscrit.</td></tr>';
    $$('#verifyBody [data-vid]').forEach(b => b.onclick = async () => {
      const noteEl = $(`#verifyBody [data-vnote="${b.dataset.vid}"]`);
      const r = await api('admin_verify', { id: b.dataset.vid, status: b.dataset.vst, note: noteEl ? noteEl.value : '' });
      toast(r.error || `Vérification enregistrée : ${b.dataset.vst}.`, r.error ? 'ko' : 'ok');
      if (!r.error) loadAdmin();
    });
  }

  if ($('#testimonialsBody')) {
    $('#testimonialsBody').innerHTML = (d.testimonials || []).map(t => `<tr>
      <td>${esc(t.created_at || '')}</td><td><b>${esc(t.name)}</b></td><td>${esc(t.role || '—')}</td>
      <td style="max-width:300px;white-space:normal">${esc(t.message)}</td>
      <td>${'★'.repeat(Math.max(1, Math.min(5, Number(t.rating) || 5)))}</td>
      <td><span class="tag ${Number(t.published) ? 't-ok' : 't-wait'}">${Number(t.published) ? 'Oui' : 'Non'}</span></td>
      <td>
        <button class="mini" style="background:#0033A0" data-tedit="${t.id}">Modifier</button>
        <button class="mini" style="background:#64748B" data-tpub="${t.id}" data-tp="${Number(t.published) ? 0 : 1}">${Number(t.published) ? 'Dépublier' : 'Publier'}</button>
        <button class="mini" style="background:#C8102E" data-tdel="${t.id}">Supprimer</button>
      </td></tr>`).join('') || '<tr><td colspan="7">Aucun témoignage.</td></tr>';
    const all = d.testimonials || [];
    $$('#testimonialsBody [data-tedit]').forEach(b => b.onclick = () => {
      const t = all.find(x => String(x.id) === String(b.dataset.tedit));
      if (!t) return;
      $('#tmId').value = t.id; $('#tmName').value = t.name; $('#tmRole').value = t.role || '';
      $('#tmMessage').value = t.message; $('#tmRating').value = t.rating; $('#tmPublished').value = Number(t.published) ? '1' : '0';
      $('#tmName').focus();
    });
    $$('#testimonialsBody [data-tpub]').forEach(b => b.onclick = async () => {
      const t = all.find(x => String(x.id) === String(b.dataset.tpub));
      if (!t) return;
      const r = await api('admin_testimonial_save', { id: t.id, name: t.name, role: t.role, message: t.message, rating: t.rating, published: Number(b.dataset.tp) });
      if (r.error) return toast(r.error, 'ko');
      loadAdmin();
    });
    $$('#testimonialsBody [data-tdel]').forEach(b => b.onclick = async () => {
      if (!confirm('Supprimer ce témoignage ?')) return;
      const r = await api('admin_testimonial_delete', { id: b.dataset.tdel });
      if (r.error) return toast(r.error, 'ko');
      toast('Témoignage supprimé.', 'ok'); loadAdmin();
    });
  }

  if ($('#messagesBody')) {    const MS = { Nouveau: ['t-wait', 'Nouveau'], Lu: ['t-ok', 'Lu'], 'Archivé': ['t-wait', 'Archivé'] };
    $('#messagesBody').innerHTML = (d.messages || []).map(m => {
      const st = MS[m.status] || ['t-wait', m.status];
      return `<tr>
        <td>${esc(new Date((m.created_at || '').replace(' ', 'T')).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }))}</td>
        <td><b>${esc(m.name)}</b><br><small>${esc(m.phone || '')}</small></td>
        <td>${esc(m.email || '—')}</td>
        <td>${esc(m.need || '—')}${m.formation_code ? '<br><small>' + esc(m.formation_code) + '</small>' : ''}</td>
        <td style="max-width:320px;white-space:normal">${esc(m.message).replace(/\n/g, '<br>')}</td>
        <td><span class="tag ${st[0]}">${esc(st[1])}</span></td>
        <td>
          ${m.status !== 'Lu' ? `<button class="mini" style="background:#0033A0" data-mid="${m.id}" data-ms="Lu">Marquer lu</button>` : ''}
          ${m.status !== 'Archivé' ? `<button class="mini" style="background:#64748B" data-mid="${m.id}" data-ms="Archivé">Archiver</button>` : ''}
        </td></tr>`;
    }).join('') || '<tr><td colspan="7">Aucun message.</td></tr>';
    $$('#messagesBody [data-mid]').forEach(b => b.onclick = async () => {
      await api('admin_message_status', { id: b.dataset.mid, status: b.dataset.ms });
      loadAdmin();
    });
  }

  const dt = ts => ts ? new Date(Number(ts) * 1000).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'medium' }) : '—';
  const PST = { SUCCESS: ['t-ok', 'Confirmé · bloqué'], PENDING: ['t-wait', 'En attente'], FAILED: ['t-ko', 'Échoué'], REFUNDED: ['t-wait', 'Remboursé'], REFUSE: ['t-ko', 'Refusé'] };
  const pill = st => st ? `<span class="tag ${(PST[st] || ['t-wait'])[0]}">${esc((PST[st] || [0, st])[1])}</span>` : '';

  if ($('#paymentsBody')) {
    $('#paymentsBody').innerHTML = (d.payments || []).map(p => `<tr><td>${dt(p.ts)}</td><td><b>${esc(p.name)}</b></td><td>${fcfa(p.amount)}</td><td>${esc(p.gateway === 'sim' ? 'simulation' : p.gateway)}</td><td>${esc(p.phone || '')}</td><td>${esc(p.reference)}</td><td>${pill(p.status)}</td></tr>`).join('') || '<tr><td colspan="7">Aucune transaction.</td></tr>';
  }

  const EV = {
    compte_cree: 'Compte créé', compte_supprime: 'Compte SUPPRIMÉ', compte_bloque: 'Compte bloqué', compte_active: 'Compte activé',
    paiement_initie: 'Paiement initié', paiement_confirme: 'Paiement confirmé', paiement_echoue: 'Paiement échoué',
    remboursement: 'Remboursement', tarifs_modifies: 'Tarifs modifiés', formations_modifiees: 'Formations modifiées',
    demande_creee: 'Demande de service', message_recu: 'Message reçu', admin_connexion: 'Connexion admin',
    admin_echec_connexion: 'Échec connexion admin', journal_exporte: 'Journal exporté', comptes_exportes: 'Comptes exportés',
    mot_de_passe_change: 'Mot de passe admin changé'
  };
  if ($('#logBody')) {
    $('#logBody').innerHTML = (d.log || []).map(r => `<tr><td>${dt(r.ts)}</td><td><b>${esc(EV[r.event] || r.event)}</b></td><td>${esc(r.account_name || '')}</td><td>${r.amount ? fcfa(r.amount) : ''}</td><td>${esc([r.gateway === 'sim' ? 'simulation' : r.gateway, r.reference].filter(Boolean).join(' · '))}</td><td>${pill(r.status)}</td><td>${esc(r.ip || '')}</td><td style="white-space:normal;max-width:320px">${esc(r.details || '')}</td></tr>`).join('') || '<tr><td colspan="8">Aucun événement.</td></tr>';
  }
  if ($('#requestsBody')) {
    $('#requestsBody').innerHTML = (d.requests || []).map(r => `<tr><td><b>${esc(r.code)}</b></td><td>${esc(r.name)}<br><small>${esc(r.phone)}</small></td><td>${esc(r.service)}</td><td>${r.distance_m ? fmtDist(r.distance_m) + ' · ' + fmtTime(r.duration_s) : '—'}</td><td>${esc(r.created_at)}</td></tr>`).join('') || '<tr><td colspan="5">Aucune demande pour l\'instant.</td></tr>';
  }
  await loadAdminTracking();
}

/* --------------------------------------------------------------------------
   Suivi admin : carte + tableau rafraîchis automatiquement
   -------------------------------------------------------------------------- */
let adminMap = null, adminTrackTimer = null, adminTrackMarkers = [];

function stopAdminTracking() {
  clearInterval(adminTrackTimer); adminTrackTimer = null;
  adminTrackMarkers.forEach(m => { if (adminMap) adminMap.removeLayer(m); });
  adminTrackMarkers = [];
}

async function loadAdminTracking() {
  const dash = $('#adminDashboard');
  if (!dash || dash.hidden) return;
  const d = await api('admin_tracking');
  if (!d || d.error || !Array.isArray(d.tracking)) return;
  const rows = d.tracking;

  if ($('#trackingBody')) {
    $('#trackingBody').innerHTML = rows.map(r => {
      const age = r.ts ? Math.max(0, Math.round((d.server_ts || Date.now() / 1000) - Number(r.ts))) : null;
      const pos = r.lat && r.lng ? `${Number(r.lat).toFixed(5)}, ${Number(r.lng).toFixed(5)}` : '—';
      const fresh = age !== null && age < 120;
      return `<tr><td><b>${esc(r.code)}</b></td><td>${esc(r.name)}<br><small>${esc(r.phone)}</small></td><td>${esc(r.service)}</td><td>${esc(pos)}</td><td>${age === null ? '—' : (age < 60 ? 'il y a ' + age + ' s' : 'il y a ' + Math.round(age / 60) + ' min')}</td><td><span class="tag ${fresh ? 't-ok' : 't-wait'}">${fresh ? 'En direct' : 'Ancienne'}</span></td></tr>`;
    }).join('') || '<tr><td colspan="6">Aucune position partagée pour le moment.</td></tr>';
  }
  if ($('#trackingEmpty')) $('#trackingEmpty').hidden = rows.length > 0;

  const el = $('#adminTrackMap');
  if (!el || typeof L === 'undefined') return;
  if (!adminMap) {
    adminMap = L.map(el, { maxBounds: YAOUNDE.bounds, maxBoundsViscosity: 0.82, minZoom: 11 }).setView(YAOUNDE.center, 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(adminMap);
  }
  adminMap.invalidateSize();
  adminTrackMarkers.forEach(m => adminMap.removeLayer(m));
  adminTrackMarkers = [];
  const bounds = [];
  rows.forEach(r => {
    if (!r.lat || !r.lng) return;
    const p = [Number(r.lat), Number(r.lng)];
    bounds.push(p);
    const age = r.ts ? Math.max(0, Math.round((d.server_ts || Date.now() / 1000) - Number(r.ts))) : null;
    const m = L.marker(p, { icon: mkIcon('dot-p') }).addTo(adminMap)
      .bindPopup(`<b>${esc(r.code)}</b><br>${esc(r.name)} · ${esc(r.service)}<br>${age === null ? '' : 'Position il y a ' + age + ' s'}`);
    if (r.to_lat && r.to_lng) {
      const line = L.polyline([p, [Number(r.to_lat), Number(r.to_lng)]], { color: '#1A73E8', weight: 3, dashArray: '6 8', opacity: 0.7 }).addTo(adminMap);
      adminTrackMarkers.push(line);
    }
    adminTrackMarkers.push(m);
  });
  if (bounds.length === 1) adminMap.setView(bounds[0], 15);
  else if (bounds.length > 1) { try { adminMap.fitBounds(bounds, { padding: [40, 40] }); } catch (e) { /* ignore */ } }

  clearInterval(adminTrackTimer);
  adminTrackTimer = setInterval(() => {
    const dash2 = $('#adminDashboard');
    if (dash2 && !dash2.hidden) loadAdminTracking();
    else stopAdminTracking();
  }, 15000);
}

function bindAdmin() {
  const login = $('#btnAdminLogin');
  if (login) login.onclick = async () => {
    const pass = $('#adminPasswordInput') ? $('#adminPasswordInput').value : '';
    const err = $('#adminLoginError');
    if (err) err.hidden = true;
    login.disabled = true;
    const r = await api('admin_login', { password: pass });
    login.disabled = false;
    if (r.error) {
      if (err) { err.textContent = r.error; err.hidden = false; }
      toast(r.error, 'ko');
      return;
    }
    await loadAdmin();
  };
  const passInput = $('#adminPasswordInput');
  if (passInput) passInput.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); login && login.click(); } });

  const lock = $('#btnLockAdmin');
  if (lock) lock.onclick = async () => { await api('admin_logout', {}); lockAdminUI(); navigateToSection('#accueil'); toast('Session admin verrouillée.', 'ok'); };

  const save = $('#btnSaveTariffs');
  if (save) save.onclick = async () => {
    const tariffs = {};
    $$('#tariffInputs input').forEach(i => tariffs[i.dataset.k] = i.value);
    const r = await api('admin_tariffs', {
      tariffs,
      min_guarantee: $('#adminMinGuarantee') ? $('#adminMinGuarantee').value : CONF.min_guarantee
    });
    if (r.error) { toast(r.error, 'ko'); return; }
    await loadTariffs();
    const s = $('#tariffSaveStatus'); if (s) { s.hidden = false; setTimeout(() => s.hidden = true, 3200); }
    toast('Tarifs mis à jour.', 'ok');
  };

  const saveF = $('#btnSaveFormations');
  if (saveF) saveF.onclick = async () => {
    const formations = {};
    $$('#formationsAdminBody tr[data-id]').forEach(tr => {
      const id = tr.dataset.id;
      const get = k => tr.querySelector(`[data-k="${k}"]`);
      formations[id] = {
        title: get('title') ? get('title').value : '',
        duration: get('duration') ? get('duration').value : '',
        price: get('price') ? get('price').value : 0,
        active: get('active') && get('active').checked ? 1 : 0
      };
    });
    const r = await api('admin_formations_save', { formations });
    if (r.error) { toast(r.error, 'ko'); return; }
    await loadFormations(true);
    const s = $('#formationsSaveStatus'); if (s) { s.hidden = false; setTimeout(() => s.hidden = true, 3200); }
    toast('Formations mises à jour. Rechargez la page pour actualiser les fiches publiques.', 'ok');
  };

  const change = $('#btnChangePassword');
  if (change) change.onclick = async () => {    const current = $('#adminCurrentPassword') ? $('#adminCurrentPassword').value : '';
    const next = $('#adminNewPassword') ? $('#adminNewPassword').value : '';
    const confirm = $('#adminConfirmPassword') ? $('#adminConfirmPassword').value : '';
    if (next.length < 10) return toast('Le nouveau mot de passe doit contenir au moins 10 caractères.', 'ko');
    if (!/[A-Za-z]/.test(next) || !/\d/.test(next)) return toast('Utilisez au moins une lettre et un chiffre.', 'ko');
    if (next !== confirm) return toast('Les deux nouveaux mots de passe ne correspondent pas.', 'ko');
    const r = await api('admin_change_password', { current, new: next });
    if (r.error) return toast(r.error, 'ko');
    ['#adminCurrentPassword', '#adminNewPassword', '#adminConfirmPassword'].forEach(s => { const el = $(s); if (el) el.value = ''; });
    const s = $('#passwordStatus'); if (s) { s.hidden = false; setTimeout(() => s.hidden = true, 4000); }
    toast('Mot de passe administrateur modifié.', 'ok');
  };

  const saveT = $('#btnSaveTestimonial');
  if (saveT) saveT.onclick = async () => {
    const payload = {
      id: Number(($('#tmId') || {}).value || 0),
      name: ($('#tmName') ? $('#tmName').value : '').trim(),
      role: ($('#tmRole') ? $('#tmRole').value : '').trim(),
      message: ($('#tmMessage') ? $('#tmMessage').value : '').trim(),
      rating: Number(($('#tmRating') || {}).value || 5),
      published: ($('#tmPublished') && $('#tmPublished').value === '0') ? 0 : 1
    };
    if (!payload.name || payload.message.length < 10) return toast('Indiquez un nom et un témoignage de 10 caractères minimum.', 'ko');
    const r = await api('admin_testimonial_save', payload);
    if (r.error) return toast(r.error, 'ko');
    toast('Témoignage enregistré. Il apparaît sur l’accueil s’il est publié.', 'ok');
    if ($('#tmId')) $('#tmId').value = '0';
    ['#tmName', '#tmRole', '#tmMessage'].forEach(s => { const el = $(s); if (el) el.value = ''; });
    loadAdmin();
  };
  const resetT = $('#btnResetTestimonial');
  if (resetT) resetT.onclick = () => {
    if ($('#tmId')) $('#tmId').value = '0';
    ['#tmName', '#tmRole', '#tmMessage'].forEach(s => { const el = $(s); if (el) el.value = ''; });
    if ($('#tmName')) $('#tmName').focus();
  };
}

/* --------------------------------------------------------------------------
   Mesure d'audience (chargée uniquement après consentement)
   -------------------------------------------------------------------------- */
function initAnalytics() {
  const cfg = Y4I.analytics || {};
  const provider = cfg.provider || '';
  if (!provider || !cfg.id) return;
  const banner = $('#cookieBanner');
  const apply = choice => {
    try { localStorage.setItem('y4i_consent', choice); } catch (e) {}
    if (banner) banner.hidden = true;
    if (choice === 'yes') loadAnalytics(provider, cfg);
  };
  const accept = $('#cookieAccept'), refuse = $('#cookieRefuse');
  if (accept) accept.onclick = () => apply('yes');
  if (refuse) refuse.onclick = () => apply('no');
  let saved = null;
  try { saved = localStorage.getItem('y4i_consent'); } catch (e) {}
  if (saved === 'yes') loadAnalytics(provider, cfg);
  else if (!saved && banner) banner.hidden = false;
}
function loadAnalytics(provider, cfg) {
  if (window.__y4iAnalytics) return;
  window.__y4iAnalytics = true;
  if (provider === 'ga4') {
    const s = document.createElement('script');
    s.async = true;
    s.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(cfg.id);
    document.head.appendChild(s);
    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    window.gtag('js', new Date());
    window.gtag('config', cfg.id, { anonymize_ip: true });
  } else if (provider === 'matomo' && cfg.host) {
    window._paq = window._paq || [];
    window._paq.push(['trackPageView'], ['enableLinkTracking'], ['setDoNotTrack', true]);
    const u = String(cfg.host).replace(/\/+$/, '') + '/';
    window._paq.push(['setTrackerUrl', u + 'matomo.php'], ['setSiteId', String(cfg.id)]);
    const s = document.createElement('script');
    s.async = true;
    s.src = u + 'matomo.js';
    document.head.appendChild(s);
  }
}

/* --------------------------------------------------------------------------
   Démarrage
   -------------------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', () => {
  document.documentElement.classList.add('js');

  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(entries => entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
    }), { threshold: 0.12 });
    $$('.reveal').forEach(el => io.observe(el));
  } else $$('.reveal').forEach(el => el.classList.add('in'));

  initSlideshow();
  bindMap();
  bindRegister();
  bindContact();
  bindCallback();
  bindAdmin();
  initAnalytics();
  loadTariffs();
  loadFormations();

  const burger = $('#burger'), nav = $('#nav');
  if (burger && nav) burger.onclick = () => {
    const open = nav.classList.toggle('open');
    burger.setAttribute('aria-expanded', open ? 'true' : 'false');
  };

  $$('a[href^="#"]').forEach(a => a.addEventListener('click', e => {
    const id = a.getAttribute('href');
    if (id && id.length > 1 && $(id)) { e.preventDefault(); history.replaceState(null, '', id); navigateToSection(id); }
  }));

  const modal = $('#formationModal');
  if (modal) {
    modal.addEventListener('keydown', e => { if (e.key === 'Escape') closeFormation(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && !modal.hidden) closeFormation(); });
  }

  if (location.hash.length > 1 && $(location.hash)) navigateToSection(location.hash);

  const sp = new URLSearchParams(location.search);
  const preFormation = (sp.get('formation') || '').trim();
  const preService = (sp.get('service') || '').trim();
  if (preFormation) {
    navigateToSection('#inscription');
    let tries = 0;
    const applyFormation = () => {
      const sel = $('#regFormation');
      const found = FORMATIONS.find(x => x.code === preFormation || x.slug === preFormation);
      if (sel && (found || preFormation.toUpperCase() === 'AUTRE')) {
        sel.value = found ? found.code : 'AUTRE';
        sel.dispatchEvent(new Event('change', { bubbles: true }));
        return;
      }
      if (sel && tries < 16) { tries++; setTimeout(applyFormation, 250); }
    };
    applyFormation();
  }
  if (preService && $(`#registerForm`) ) {
    if (preService !== 'formation') setTimeout(() => selectService(preService), 300);
  }
  const followCode = (sp.get('suivi') || '').trim().toUpperCase();
  if (followCode) {
    navigateToSection('#suivi');
    if ($('#followCode')) $('#followCode').value = followCode;
    const box = $('#followBox'); if (box) box.open = true;
    setTimeout(() => startFollow(followCode), 500);
  }

  const q = sp.get('paiement');
  if (q) {
    navigateToSection('#inscription');
    if (q === 'ok') showSuccess('Retour d\'Orange Money : votre paiement est en cours de confirmation. Votre compte sera activé dès réception de la validation.');
    else showError('Paiement annulé.', true);
    const form = $('#registerForm'); if (form) form.hidden = true;
  }
});

<?php
require_once __DIR__ . '/lib.php';
header('Content-Type: application/xml; charset=utf-8');

$base = rtrim(abs_url(''), '/');
$urls = [
    ['loc' => $base . '/', 'priority' => '1.0', 'changefreq' => 'weekly'],
    ['loc' => $base . '/legal.php', 'priority' => '0.3', 'changefreq' => 'yearly'],
];
foreach (formations_all(true) as $f) {
    $urls[] = ['loc' => $base . '/formation.php?slug=' . rawurlencode((string)$f['slug']), 'priority' => '0.8', 'changefreq' => 'monthly', 'lastmod' => date('Y-m-d')];
}
foreach (services_all() as $k => $s) {
    if ($k === 'formation') continue;
    $urls[] = ['loc' => $base . '/service.php?service=' . rawurlencode($k), 'priority' => '0.7', 'changefreq' => 'monthly'];
}

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
<?php foreach ($urls as $u): ?>
  <url>
    <loc><?= htmlspecialchars($u['loc'], ENT_XML1) ?></loc>
    <?php if (!empty($u['lastmod'])): ?><lastmod><?= $u['lastmod'] ?></lastmod><?php endif; ?>
    <changefreq><?= $u['changefreq'] ?></changefreq>
    <priority><?= $u['priority'] ?></priority>
  </url>
<?php endforeach; ?>
</urlset>

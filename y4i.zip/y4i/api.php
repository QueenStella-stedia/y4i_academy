<?php
require_once __DIR__ . '/pay.php';
$a = $_GET['action'] ?? '';
$db = db();

/* Toutes les écritures exigent le jeton CSRF de la session (sauf webhooks opérateurs). */
$writeActions = [
    'register', 'contact', 'callback_create', 'request_create', 'track_push',
    'admin_login', 'admin_logout', 'admin_toggle', 'admin_tariffs', 'admin_refund', 'admin_delete',
    'admin_formations_save', 'admin_message_status', 'admin_change_password',
    'admin_verify', 'admin_testimonial_save', 'admin_testimonial_delete',
];
if (in_array($a, $writeActions, true) && !csrf_valid(csrf_header())) {
    out(['error' => 'Session expirée ou requête non autorisée. Rechargez la page puis réessayez.'], 403);
}

try {
switch ($a) {

case 'tariffs':
    out([
        'tariffs' => $db->query("SELECT * FROM tariffs")->fetchAll(),
        'formations' => formations_all(true),
        'testimonials' => $db->query("SELECT id, name, role, message, rating FROM testimonials WHERE published=1 ORDER BY id DESC LIMIT 12")->fetchAll(),
        'places' => local_places(),
        'min_guarantee' => max(1000, (int)setting('min_guarantee', 5000)),
        'km_price' => (int)setting('km_price', 300),
        'base_fee' => (int)setting('base_fee', 1000),
        'gateways' => ['campay' => gateway_ready('campay'), 'mtn' => gateway_ready('mtn'), 'orange' => gateway_ready('orange')],
        'modes' => ['campay' => gateway_mode('campay'), 'mtn' => gateway_mode('mtn'), 'orange' => gateway_mode('orange')],
        'map' => cfg()['map'],
        'contact' => ['whatsapp' => cfg()['whatsapp'], 'phone' => cfg()['phone_secondary'] ?? cfg()['whatsapp']],
    ]);

case 'formations':
    out(['formations' => formations_all(true)]);

case 'places':
    out(['places' => local_places()]);

/* ---------- Inscription client / prestataire ---------- */
case 'register': {
    rate_limit('register', (int)(cfg()['security']['max_register'] ?? 12), 3600);
    $multipart = str_starts_with((string)($_SERVER['CONTENT_TYPE'] ?? ''), 'multipart/form-data');
    $b = $multipart ? $_POST : body();
    if (!empty($b['website'])) out(['error' => 'Requête refusée.'], 422); // piège anti-robot

    $name = clean_text($b['name'] ?? '', 120);
    $contact = clean_text($b['contact'] ?? '', 60);
    $email = clean_text($b['email'] ?? '', 160);
    $loc = clean_text($b['location'] ?? '', 160);
    $type = (($b['type'] ?? '') === 'prestataire') ? 'Prestataire' : 'Client';
    $formationCode = strtoupper(clean_text($b['formation_code'] ?? '', 20));
    $isOtherFormation = $formationCode === 'AUTRE';
    $formation = $formationCode !== '' && !$isOtherFormation ? formation_by_code($formationCode) : null;
    $formationSpec = clean_multiline($b['formation_spec'] ?? '', 3000);
    $serviceDescription = clean_multiline($b['service_description'] ?? '', 2000);
    $experience = clean_text($b['experience'] ?? '', 60);
    $zone = clean_text($b['zone'] ?? ($loc !== '' ? $loc : ''), 160);
    $notes = clean_multiline($b['notes'] ?? '', 500);
    $refs = clean_multiline($b['references'] ?? '', 1000);

    if ($name === '' || $contact === '' || $loc === '') out(['error' => 'Nom, contact et quartier sont obligatoires.'], 422);
    if (!valid_phone($contact) && !valid_email($contact)) out(['error' => 'Indiquez un numéro de téléphone camerounais valide (ex : 6XX XXX XXX).'], 422);
    if (!valid_email($email)) out(['error' => 'Adresse e-mail invalide.'], 422);
    // La formation est FACULTATIVE. Si un code est fourni, il doit être valide.
    if ($formationCode !== '' && !$isOtherFormation && !$formation) out(['error' => 'Code formation inconnu. Choisissez une formation dans la liste ou laissez vide.'], 422);
    if ($isOtherFormation && mb_strlen($formationSpec) < 10) out(['error' => 'Précisez votre autre demande (10 caractères minimum) ou choisissez une formation.'], 422);
    if ($formation && $formationSpec === '') $formationSpec = (string)$formation['specification'];

    $formationLabel = $formation['title'] ?? ($isOtherFormation ? 'Autre demande' : null);
    $storedCode = ($formation || $isOtherFormation) ? $formationCode : null;
    if ($isOtherFormation) $storedCode = null;

    if ($type === 'Client') {
        $db->prepare("INSERT INTO accounts(name,contact,email,location,type,payment_method,status,formation_code,formation_label,formation_spec,service_description,experience,zone,notes)
            VALUES(?,?,?,?,?,'', 'Actif',?,?,?,?,?,?,?)")
           ->execute([$name, $contact, $email, $loc, 'Client', $storedCode, $formationLabel,
                      $formationSpec ?: null, $serviceDescription ?: null, $experience ?: null, $zone ?: null, $notes ?: null]);
        $id = (int)$db->lastInsertId();
        log_event('compte_cree', ['account_id' => $id, 'account_name' => $name, 'details' => 'Client · ' . $loc . ' · formation ' . ($storedCode ?: 'aucune')]);
        notify_admin('Y4I Academy — nouveau compte client', '<h2>Nouveau compte client</h2><p><b>' . h($name) . '</b> · ' . h($contact) . ' · ' . h($loc) . '</p><p>Formation : ' . h($formationLabel ?: 'aucune') . '</p>');
        out(['ok' => true, 'type' => 'Client', 'account_id' => $id, 'formation_code' => $storedCode,
             'message' => 'Compte client créé. Nous vous recontactons rapidement.']);
    }

    $gw = in_array($b['gateway'] ?? '', ['campay', 'mtn', 'orange'], true) ? $b['gateway'] : cfg()['default_gateway'];
    $amount = (int)($b['amount'] ?? 0);
    $min = max(1000, (int)setting('min_guarantee', 5000));
    $phone = norm_phone((string)($b['phone'] ?? $contact));
    if ($isOtherFormation) out(['error' => 'Choisissez une formation de la liste, ou aucune formation, pour votre compte prestataire.'], 422);
    if (mb_strlen($serviceDescription) < 20) out(['error' => 'Décrivez la prestation que vous proposez (20 caractères minimum).'], 422);
    if ($amount < $min) out(['error' => "Le fonds de garantie minimum est de " . number_format($min, 0, ',', ' ') . " FCFA."], 422);
    if ($amount > 5000000) out(['error' => 'Le fonds de garantie ne peut pas dépasser 5 000 000 FCFA.'], 422);
    if (!valid_phone($phone)) out(['error' => 'Numéro Mobile Money invalide (ex : 6XXXXXXXX).'], 422);

    // Aucune pièce justificative demandée à l'inscription.
    $idDoc = null; $diplomaDoc = null; $verifyStatus = 'Non requis';

    $db->prepare("INSERT INTO accounts(name,contact,email,location,type,payment_method,status,formation_code,formation_label,formation_spec,service_description,experience,zone,notes,refs,verify_status,id_doc,diploma_doc)
        VALUES(?,?,?,?,?,?, 'En attente de paiement',?,?,?,?,?,?,?,?,?,?,?)")
       ->execute([$name, $contact, $email, $loc, 'Prestataire', $gw, $storedCode, $formationLabel,
                  $formationSpec ?: null, $serviceDescription, $experience ?: null, $zone ?: $loc, $notes ?: null,
                  $refs ?: null, $verifyStatus, $idDoc, $diplomaDoc]);
    $accId = (int)$db->lastInsertId();
    log_event('compte_cree', ['account_id' => $accId, 'account_name' => $name, 'details' => 'Prestataire · ' . $loc . ' · formation ' . ($storedCode ?: 'aucune') . ' · ' . $gw . ' · vérification ' . $verifyStatus]);
    notify_admin('Y4I Academy — nouveau prestataire', '<h2>Nouveau prestataire</h2><p><b>' . h($name) . '</b> · ' . h($contact) . ' · ' . h($loc) . '</p><p>Garantie : ' . number_format($amount, 0, ',', ' ') . ' FCFA · ' . h($gw) . '<br>Vérification : ' . h($verifyStatus) . '</p>');
    try { $p = start_payment($accId, $gw, $phone, $amount); }
    catch (Throwable $e) {
        $db->prepare("UPDATE accounts SET status='Paiement échoué' WHERE id=?")->execute([$accId]);
        out(['error' => $e->getMessage()], 502);
    }
    out(['ok' => true, 'type' => 'Prestataire', 'account_id' => $accId, 'formation_code' => $formationCode] + $p);
}

case 'pay_status': {
    $id = (int)($_GET['id'] ?? 0);
    $token = (string)($_GET['token'] ?? '');
    $s = $db->prepare("SELECT token FROM payments WHERE id=?"); $s->execute([$id]);
    $stored = $s->fetchColumn();
    if ($stored === false || $token === '' || !hash_equals((string)$stored, $token)) out(['error' => 'Paiement introuvable.'], 404);
    out(refresh_payment($id));
}

case 'webhook_campay': {   // URL à saisir dans Campay : /api.php?action=webhook_campay
    $ref = (string)($_GET['reference'] ?? ($_POST['reference'] ?? ''));
    if ($ref === '') { $b = body(); $ref = (string)($b['reference'] ?? ''); }
    if ($ref !== '') {
        $s = $db->prepare("SELECT id FROM payments WHERE reference=?"); $s->execute([$ref]);
        if ($id = $s->fetchColumn()) refresh_payment((int)$id);
    }
    out(['ok' => true]);
}
case 'webhook_orange': {   // notif_url envoyée à Orange
    $b = body(); $tok = (string)($b['notif_token'] ?? '');
    if ($tok !== '') {
        $s = $db->prepare("SELECT id FROM payments WHERE gateway='orange' AND extra=? AND extra<>''"); $s->execute([$tok]);
        if ($id = $s->fetchColumn()) refresh_payment((int)$id);
    }
    out(['ok' => true]);
}

/* ---------- Géocodage : local instantané + Nominatim/Photon + cache ---------- */
case 'geocode': {
    rate_limit('geocode', (int)(cfg()['security']['max_geocode'] ?? 240), 600);
    $q = clean_text($_GET['q'] ?? '', 120);
    if (mb_strlen($q) < 2) out([]);
    $local = local_geocode($q);
    $words = count(preg_split('/\s+/', $q) ?: []);
    $needOnline = count($local) < 3 || preg_match('/\d/', $q) || $words > 2;
    $online = $needOnline ? online_geocode($q) : [];
    $res = []; $seen = [];
    foreach (array_merge($local, $online) as $x) {
        $k = round((float)$x['lat'], 4) . ',' . round((float)$x['lng'], 4);
        if (isset($seen[$k])) continue; $seen[$k] = 1;
        $x['label'] = clean_text($x['label'] ?? $x['name'] ?? '', 180);
        $res[] = $x;
        if (count($res) >= 10) break;
    }
    out($res);
}

case 'reverse': {
    rate_limit('reverse', 120, 600);
    $lat = (float)($_GET['lat'] ?? 0); $lng = (float)($_GET['lng'] ?? 0);
    if ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180 || ($lat == 0 && $lng == 0)) out(['error' => 'Position invalide.'], 422);
    $cacheKey = 'rev:' . round($lat, 5) . ',' . round($lng, 5);
    if ($cached = geocache_get($cacheKey, 86400)) out($cached);
    $label = '';
    $ua = 'Y4I-Academy/2.0 (' . (cfg()['map']['email'] ?? '') . ')';
    $r = http('GET', 'https://nominatim.openstreetmap.org/reverse?' . http_build_query([
        'format' => 'jsonv2', 'lat' => $lat, 'lon' => $lng, 'zoom' => 18, 'addressdetails' => 1,
    ]), ['User-Agent: ' . $ua, 'Accept-Language: fr', 'Accept: application/json'], null, 10);
    if (!empty($r['json']['display_name'])) $label = clean_text($r['json']['display_name'], 180);
    if ($label === '') {
        $best = null; $bd = 1e12;
        foreach (local_places() as $p) {
            $d = haversine_m($lat, $lng, (float)$p['lat'], (float)$p['lng']);
            if ($d < $bd) { $bd = $d; $best = $p; }
        }
        if ($best) $label = $best['name'] . ($bd > 300 ? ' · à ' . round($bd / 100) / 10 . ' km' : ' · à ' . round($bd) . ' m');
    }
    $data = ['label' => $label ?: ('Position ' . round($lat, 5) . ', ' . round($lng, 5)), 'lat' => $lat, 'lng' => $lng];
    if ($label) geocache_set($cacheKey, $data);
    out($data);
}

/* ---------- Itinéraire serveur (contourne CORS + repli si OSRM indisponible) ---------- */
case 'route': {
    rate_limit('route', 300, 600);
    $flat = (float)($_GET['from_lat'] ?? 0); $flng = (float)($_GET['from_lng'] ?? 0);
    $tlat = (float)($_GET['to_lat'] ?? 0);   $tlng = (float)($_GET['to_lng'] ?? 0);
    $profile = in_array($_GET['profile'] ?? '', ['driving', 'walking', 'cycling'], true) ? $_GET['profile'] : 'driving';
    if (abs($flat) > 90 || abs($tlat) > 90 || abs($flng) > 180 || abs($tlng) > 180 || ($flat == 0 && $flng == 0) || ($tlat == 0 && $tlng == 0)) {
        out(['error' => 'Coordonnées invalides.'], 422);
    }
    $cacheKey = 'route:' . $profile . ':' . round($flat, 4) . ',' . round($flng, 4) . ':' . round($tlat, 4) . ',' . round($tlng, 4);
    if ($cached = geocache_get($cacheKey, 180)) out($cached);
    $url = 'https://router.project-osrm.org/route/v1/' . $profile . '/' . $flng . ',' . $flat . ';' . $tlng . ',' . $tlat
         . '?alternatives=true&steps=true&overview=full&geometries=geojson';
    $r = http('GET', $url, ['User-Agent: Y4I-Academy/2.0', 'Accept: application/json'], null, 12);
    if (($r['code'] ?? 0) === 200 && (($r['json']['code'] ?? '') === 'Ok') && !empty($r['json']['routes'])) {
        $data = ['routes' => array_slice($r['json']['routes'], 0, 3), 'fallback' => false, 'profile' => $profile];
        geocache_set($cacheKey, $data);
        out($data);
    }
    out(fallback_route($flat, $flng, $tlat, $tlng, $profile));
}

/* ---------- Demandes de service + estimation ---------- */
case 'request_create': {
    rate_limit('request', 30, 3600);
    $b = body();
    if (!empty($b['website'])) out(['error' => 'Requête refusée.'], 422);
    $name = clean_text($b['name'] ?? '', 120); $phone = norm_phone((string)($b['phone'] ?? ''));
    if ($name === '' || !valid_phone($phone)) out(['error' => 'Nom et téléphone valides requis.'], 422);
    $service = clean_text($b['service'] ?? '', 120);
    $formationCode = strtoupper(clean_text($b['formation_code'] ?? '', 20));
    if ($formationCode !== '' && !formation_by_code($formationCode)) out(['error' => 'Formation inconnue.'], 422);
    $details = clean_multiline($b['details'] ?? '', 600);
    $zone = clean_text($b['zone'] ?? '', 160);
    $address = clean_text($b['address'] ?? '', 240);
    $dist = max(0, min(200000, (int)($b['distance_m'] ?? 0)));
    $dur = max(0, min(72000, (int)($b['duration_s'] ?? 0)));
    // Aucune estimation tarifaire : la carte affiche seulement la distance et la durée.
    $est = 0;
    $coords = function ($k) use ($b) { return isset($b[$k]) && is_numeric($b[$k]) ? (float)$b[$k] : null; };
    $fromLat = $coords('from_lat'); $fromLng = $coords('from_lng'); $toLat = $coords('to_lat'); $toLng = $coords('to_lng');
    $code = ''; $pkey = bin2hex(random_bytes(8));
    for ($i = 0; $i < 6; $i++) {
        $try = strtoupper(bin2hex(random_bytes(3)));
        $s = $db->prepare("SELECT 1 FROM requests WHERE code=?"); $s->execute([$try]);
        if (!$s->fetchColumn()) { $code = $try; break; }
    }
    if ($code === '') out(['error' => 'Impossible de générer un code. Réessayez.'], 500);
    log_event('demande_creee', ['phone' => $phone, 'account_name' => $name, 'reference' => $code, 'details' => substr($service, 0, 60)]);
    $db->prepare("INSERT INTO requests(code,pkey,name,phone,service,formation_code,details,zone,address,from_lat,from_lng,to_lat,to_lng,distance_m,duration_s,estimate)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
       ->execute([$code, $pkey, $name, $phone, $service, $formationCode ?: null, $details, $zone ?: null, $address ?: null,
                  $fromLat, $fromLng, $toLat, $toLng, $dist, $dur, $est]);
    out(['ok' => true, 'code' => $code, 'pkey' => $pkey,
         'share_url' => rtrim((string)cfg()['app_url'], '/') . '/?suivi=' . $code . '#suivi']);
}

/* ---------- Suivi GPS en direct ---------- */
case 'track_push': {  // appelé par le téléphone du prestataire
    rate_limit('track_push', 2400, 3600);
    $b = body();
    $s = $db->prepare("SELECT code FROM requests WHERE code=? AND pkey=?"); $s->execute([strtoupper((string)($b['code'] ?? '')), (string)($b['pkey'] ?? '')]);
    if (!$s->fetchColumn()) out(['error' => 'Code ou clé invalide.'], 403);
    $lat = (float)($b['lat'] ?? 0); $lng = (float)($b['lng'] ?? 0);
    if (abs($lat) > 90 || abs($lng) > 180 || ($lat == 0 && $lng == 0)) out(['error' => 'Position invalide.'], 422);
    $acc = isset($b['accuracy']) && is_numeric($b['accuracy']) ? (float)$b['accuracy'] : null;
    $db->prepare("INSERT INTO tracking(code,lat,lng,accuracy,ts) VALUES(?,?,?,?,?)")->execute([strtoupper((string)$b['code']), $lat, $lng, $acc, time()]);
    $db->prepare("DELETE FROM tracking WHERE code=? AND ts < ?")->execute([strtoupper((string)$b['code']), time() - 7200]);
    out(['ok' => true]);
}
case 'track_get': {
    rate_limit('track_get', 2400, 3600);
    $code = strtoupper(clean_text($_GET['code'] ?? '', 12));
    $s = $db->prepare("SELECT status, from_lat, from_lng, to_lat, to_lng, service FROM requests WHERE code=?"); $s->execute([$code]);
    $r = $s->fetch();
    if (!$r) out(['error' => 'Code introuvable. Vérifiez le code de suivi.'], 404);
    $t = $db->prepare("SELECT lat,lng,accuracy,ts FROM tracking WHERE code=? ORDER BY ts DESC LIMIT 1"); $t->execute([$code]);
    out(['request' => $r, 'position' => $t->fetch() ?: null, 'server_ts' => time()]);
}

/* ---------- Contact (enregistré + WhatsApp) ---------- */
case 'contact': {
    rate_limit('contact', (int)(cfg()['security']['max_contact'] ?? 8), 3600);
    $b = body();
    if (!empty($b['website'])) out(['error' => 'Requête refusée.'], 422);
    $name = clean_text($b['name'] ?? '', 120); $phone = clean_text($b['phone'] ?? '', 40);
    $email = clean_text($b['email'] ?? '', 160); $need = clean_text($b['need'] ?? '', 120);
    $formationCode = strtoupper(clean_text($b['formation_code'] ?? '', 20));
    $message = clean_multiline($b['message'] ?? '', 1500);
    if ($name === '' || !valid_phone($phone)) out(['error' => 'Votre nom et un téléphone valide sont requis.'], 422);
    if (!valid_email($email)) out(['error' => 'Adresse e-mail invalide.'], 422);
    if (mb_strlen($message) < 5) out(['error' => 'Précisez votre besoin (5 caractères minimum).'], 422);
    $db->prepare("INSERT INTO messages(name,phone,email,need,formation_code,message,source,status,ip) VALUES(?,?,?,?,?,?,?, 'Nouveau',?)")
       ->execute([$name, $phone, $email ?: null, $need ?: null, $formationCode ?: null, $message, 'site', $_SERVER['REMOTE_ADDR'] ?? null]);
    $id = (int)$db->lastInsertId();
    log_event('message_recu', ['account_name' => $name, 'phone' => $phone, 'details' => $need . ' · ' . mb_substr($message, 0, 120)]);
    notify_admin('Y4I Academy — nouveau message', '<h2>Nouveau message</h2><p><b>' . h($name) . '</b> · ' . h($phone) . ($email ? ' · ' . h($email) : '') . '</p><p>Besoin : ' . h($need ?: 'information') . '</p><p>' . nl2br(h($message)) . '</p>');
    $text = "Bonjour Y4I Academy, je suis " . $name . " (" . $phone . "). Besoin : " . ($need ?: 'information') . ". " . $message;
    out(['ok' => true, 'message_id' => $id, 'whatsapp' => 'https://wa.me/' . cfg()['whatsapp'] . '?text=' . rawurlencode($text)]);
}

/* ---------- Demande de rappel express ---------- */
case 'callback_create': {
    rate_limit('callback', 10, 3600);
    $b = body();
    if (!empty($b['website'])) out(['error' => 'Requête refusée.'], 422);
    $name = clean_text($b['name'] ?? '', 120);
    $phone = clean_text($b['phone'] ?? '', 40);
    $need = clean_text($b['need'] ?? 'Rappel', 120);
    if ($name === '' || !valid_phone($phone)) out(['error' => 'Indiquez votre nom et un numéro camerounais valide.'], 422);
    $message = 'Demande de rappel' . ($need && $need !== 'Rappel' ? ' — ' . $need : '');
    $db->prepare("INSERT INTO messages(name,phone,email,need,message,source,status,ip) VALUES(?,?,?,?,?,?, 'Nouveau',?)")
       ->execute([$name, $phone, null, 'Rappel · ' . $need, $message, 'rappel', $_SERVER['REMOTE_ADDR'] ?? null]);
    $id = (int)$db->lastInsertId();
    log_event('rappel_demande', ['account_name' => $name, 'phone' => $phone, 'details' => $message]);
    notify_admin('Y4I Academy — demande de rappel', '<h2>Demande de rappel</h2><p><b>' . h($name) . '</b> · ' . h($phone) . '</p><p>' . h($message) . '</p>');
    out(['ok' => true, 'message_id' => $id, 'whatsapp' => 'https://wa.me/' . cfg()['whatsapp'] . '?text=' . rawurlencode('Bonjour Y4I Academy, je suis ' . $name . ' (' . $phone . '). Merci de me rappeler.')]);
}

/* ---------- Administration (session + mot de passe serveur) ---------- */
case 'admin_login': {
    rate_limit('login', (int)(cfg()['security']['max_login'] ?? 8), 900);
    usleep(350000); // freine la force brute
    $b = body();
    if (admin_password_ok((string)($b['password'] ?? ''))) {
        session_regenerate_id(true);
        $_SESSION['admin'] = true;
        $_SESSION['admin_time'] = time();
        log_event('admin_connexion');
        out(['ok' => true]);
    }
    log_event('admin_echec_connexion', ['status' => 'REFUSE']);
    out(['error' => 'Mot de passe incorrect'], 401);
}
case 'admin_logout': $_SESSION = []; session_destroy(); out(['ok' => true]);

case 'admin_data':
    require_admin();
    $latest = "(SELECT p.amount FROM payments p WHERE p.account_id=a.id ORDER BY p.id DESC LIMIT 1)";
    $latestStatus = "(SELECT p.status FROM payments p WHERE p.account_id=a.id ORDER BY p.id DESC LIMIT 1)";
    $latestGw = "(SELECT p.gateway FROM payments p WHERE p.account_id=a.id ORDER BY p.id DESC LIMIT 1)";
    $accounts = $db->query("SELECT a.*, $latest amount, $latestStatus pay_status, $latestGw gateway FROM accounts a ORDER BY a.id DESC")->fetchAll();
    $stats = [
        'accounts' => (int)$db->query("SELECT COUNT(*) FROM accounts")->fetchColumn(),
        'clients' => (int)$db->query("SELECT COUNT(*) FROM accounts WHERE type='Client'")->fetchColumn(),
        'providers' => (int)$db->query("SELECT COUNT(*) FROM accounts WHERE type='Prestataire'")->fetchColumn(),
        'active_providers' => (int)$db->query("SELECT COUNT(*) FROM accounts WHERE type='Prestataire' AND status='Actif'")->fetchColumn(),
        'guarantee_total' => (int)$db->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='SUCCESS'")->fetchColumn(),
        'guarantee_refunded' => (int)$db->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='REFUNDED'")->fetchColumn(),
        'pending_payments' => (int)$db->query("SELECT COUNT(*) FROM payments WHERE status='PENDING'")->fetchColumn(),
        'requests' => (int)$db->query("SELECT COUNT(*) FROM requests")->fetchColumn(),
        'messages_new' => (int)$db->query("SELECT COUNT(*) FROM messages WHERE status='Nouveau'")->fetchColumn(),
        'formations' => (int)$db->query("SELECT COUNT(*) FROM formations WHERE active=1")->fetchColumn(),
        'pending_verifications' => (int)$db->query("SELECT COUNT(*) FROM accounts WHERE type='Prestataire' AND verify_status IN ('En attente','Documents partiels')")->fetchColumn(),
    ];
    out([
        'accounts' => $accounts,
        'requests' => $db->query("SELECT * FROM requests ORDER BY id DESC LIMIT 80")->fetchAll(),
        'payments' => array_map(fn($r) => ['id' => $r['id'], 'ts' => (int)$r['created_ts'], 'gateway' => $r['gateway'], 'reference' => $r['reference'],
            'amount' => (int)$r['amount'], 'status' => $r['status'], 'phone' => mask_phone($r['phone']),
            'name' => $r['name'] ?? ('(compte supprimé #' . $r['account_id'] . ')')],
            $db->query("SELECT p.*, a.name FROM payments p LEFT JOIN accounts a ON a.id=p.account_id ORDER BY p.id DESC LIMIT 300")->fetchAll()),
        'log' => $db->query("SELECT * FROM activity_log ORDER BY id DESC LIMIT 400")->fetchAll(),
        'tariffs' => $db->query("SELECT * FROM tariffs")->fetchAll(),
        'formations' => formations_all(false),
        'messages' => $db->query("SELECT * FROM messages ORDER BY id DESC LIMIT 200")->fetchAll(),
        'testimonials' => $db->query("SELECT * FROM testimonials ORDER BY id DESC LIMIT 200")->fetchAll(),
        'stats' => $stats,
        'min_guarantee' => max(1000, (int)setting('min_guarantee', 5000)),
        'gateways' => ['campay' => gateway_ready('campay'), 'mtn' => gateway_ready('mtn'), 'orange' => gateway_ready('orange')],
        'modes' => ['campay' => gateway_mode('campay'), 'mtn' => gateway_mode('mtn'), 'orange' => gateway_mode('orange')],
    ]);

case 'admin_tracking': {
    require_admin();
    $rows = $db->query("SELECT r.id, r.code, r.name, r.phone, r.service, r.status, r.from_lat, r.from_lng, r.to_lat, r.to_lng,
            (SELECT t.lat FROM tracking t WHERE t.code=r.code ORDER BY t.ts DESC LIMIT 1) lat,
            (SELECT t.lng FROM tracking t WHERE t.code=r.code ORDER BY t.ts DESC LIMIT 1) lng,
            (SELECT t.accuracy FROM tracking t WHERE t.code=r.code ORDER BY t.ts DESC LIMIT 1) accuracy,
            (SELECT t.ts FROM tracking t WHERE t.code=r.code ORDER BY t.ts DESC LIMIT 1) ts
        FROM requests r
        WHERE EXISTS (SELECT 1 FROM tracking t WHERE t.code=r.code)
        ORDER BY r.id DESC LIMIT 100")->fetchAll();
    out(['tracking' => $rows, 'server_ts' => time()]);
}

case 'admin_toggle': {
    require_admin(); $b = body();
    $id = (int)($b['id'] ?? 0);
    $db->prepare("UPDATE accounts SET status = CASE WHEN status='Actif' THEN 'Bloqué' ELSE 'Actif' END WHERE id=?")->execute([$id]);
    $s = $db->prepare("SELECT name,status FROM accounts WHERE id=?"); $s->execute([$id]); $r = $s->fetch();
    if ($r) log_event($r['status'] === 'Actif' ? 'compte_active' : 'compte_bloque', ['account_id' => $id, 'account_name' => $r['name'], 'status' => $r['status']]);
    out(['ok' => true]);
}
case 'admin_tariffs': {
    require_admin(); $b = body();
    $u = $db->prepare("UPDATE tariffs SET price=? WHERE k=?");
    foreach (($b['tariffs'] ?? []) as $k => $v) $u->execute([max(0, min(10000000, (int)$v)), clean_text($k, 40)]);
    foreach (['min_guarantee', 'km_price', 'base_fee'] as $k) if (isset($b[$k])) {
        $max = $k === 'min_guarantee' ? 5000000 : ($k === 'km_price' ? 10000 : 100000);
        set_setting($k, max($k === 'min_guarantee' ? 1000 : 0, min($max, (int)$b[$k])));
    }
    log_event('tarifs_modifies', ['details' => json_encode(['tarifs' => $b['tariffs'] ?? [], 'garantie_min' => $b['min_guarantee'] ?? null, 'frais_fixes' => $b['base_fee'] ?? null, 'prix_km' => $b['km_price'] ?? null])]);
    out(['ok' => true]);
}
case 'admin_formations_save': {
    require_admin(); $b = body();
    $u = $db->prepare("UPDATE formations SET title=?, short=?, description=?, specification=?, modules=?, duration=?, prerequisites=?, certification=?, price=?, price_note=?, active=? WHERE id=?");
    $s = $db->prepare("SELECT * FROM formations WHERE id=?");
    foreach (($b['formations'] ?? []) as $id => $v) {
        $id = (int)$id; $s->execute([$id]); $f = $s->fetch();
        if (!$f) continue;
        $u->execute([
            clean_text($v['title'] ?? $f['title'], 140),
            clean_multiline($v['short'] ?? $f['short'], 500),
            clean_multiline($v['description'] ?? $f['description'], 2500),
            clean_multiline($v['specification'] ?? $f['specification'], 3500),
            clean_multiline($v['modules'] ?? $f['modules'], 2000),
            clean_text($v['duration'] ?? $f['duration'], 100),
            clean_multiline($v['prerequisites'] ?? $f['prerequisites'], 1000),
            clean_text($v['certification'] ?? $f['certification'], 240),
            max(0, min(10000000, (int)($v['price'] ?? $f['price']))),
            clean_text($v['price_note'] ?? $f['price_note'], 120),
            !empty($v['active']) ? 1 : 0,
            $id,
        ]);
    }
    log_event('formations_modifiees', ['details' => 'Mise à jour de ' . count((array)($b['formations'] ?? [])) . ' formation(s)']);
    out(['ok' => true]);
}
case 'admin_message_status': {
    require_admin(); $b = body();
    $id = (int)($b['id'] ?? 0);
    $st = in_array($b['status'] ?? '', ['Nouveau', 'Lu', 'Archivé'], true) ? $b['status'] : 'Lu';
    $db->prepare("UPDATE messages SET status=? WHERE id=?")->execute([$st, $id]);
    out(['ok' => true]);
}
case 'admin_change_password': {
    require_admin(); $b = body();
    $current = (string)($b['current'] ?? ''); $new = (string)($b['new'] ?? '');
    if (!admin_password_ok($current)) out(['error' => 'Mot de passe actuel incorrect.'], 403);
    if (mb_strlen($new) < 10) out(['error' => 'Le nouveau mot de passe doit contenir au moins 10 caractères.'], 422);
    if (!preg_match('/[A-Za-z]/', $new) || !preg_match('/\d/', $new)) out(['error' => 'Utilisez au moins une lettre et un chiffre.'], 422);
    set_setting('admin_password_hash', password_hash($new, PASSWORD_DEFAULT));
    log_event('mot_de_passe_change');
    out(['ok' => true]);
}
case 'admin_refund': {   // libère/rembourse le fonds de garantie d'un prestataire
    require_admin(); $b = body();
    $s = $db->prepare("SELECT * FROM payments WHERE account_id=? AND status='SUCCESS' ORDER BY id DESC LIMIT 1"); $s->execute([(int)($b['id'] ?? 0)]);
    $p = $s->fetch();
    if (!$p) out(['error' => 'Aucun fonds bloqué pour ce compte.'], 404);
    $auto = false;
    if ($p['gateway'] === 'campay' && $p['reference'] !== 'seed' && gateway_ready('campay')) {
        if (!campay_withdraw($p['phone'], (int)$p['amount'], 'RF-' . $p['external_ref'])) out(['error' => 'Remboursement Campay refusé.'], 502);
        $auto = true;
    }
    $db->prepare("UPDATE payments SET status='REFUNDED', updated_at=CURRENT_TIMESTAMP WHERE id=?")->execute([$p['id']]);
    log_event('remboursement', ['account_id' => (int)$p['account_id'], 'account_name' => account_name((int)$p['account_id']), 'amount' => (int)$p['amount'], 'gateway' => $p['gateway'],
        'reference' => $p['reference'], 'status' => 'REFUNDED', 'phone' => $p['phone'], 'details' => $auto ? 'remboursement automatique' : 'à effectuer manuellement']);
    out(['ok' => true, 'auto' => $auto, 'note' => $auto ? 'Remboursé sur Mobile Money.' : 'Marqué remboursé : effectuez le virement manuellement depuis votre compte opérateur.']);
}

case 'admin_delete': {   // supprime le compte ; l'historique des transactions est CONSERVÉ
    require_admin(); $b = body(); $id = (int)($b['id'] ?? 0);
    $s = $db->prepare("SELECT * FROM accounts WHERE id=?"); $s->execute([$id]); $acc = $s->fetch();
    if (!$acc) out(['error' => 'Compte introuvable.'], 404);
    $f = $db->prepare("SELECT COUNT(*) FROM payments WHERE account_id=? AND status='SUCCESS'"); $f->execute([$id]);
    if ((int)$f->fetchColumn() > 0) out(['error' => 'Ce prestataire a un fonds de garantie bloqué : remboursez-le d\'abord (bouton Rembourser), puis supprimez le compte.'], 409);
    $db->prepare("DELETE FROM accounts WHERE id=?")->execute([$id]);
    log_event('compte_supprime', ['account_id' => $id, 'account_name' => $acc['name'], 'details' => $acc['type'] . ' · ' . $acc['location'] . ' · ' . $acc['contact']]);
    out(['ok' => true]);
}
/* ---------- Consultation protégée des pièces justificatives ---------- */
case 'admin_doc': {
    require_admin();
    $id = (int)($_GET['id'] ?? 0);
    $which = ($_GET['doc'] ?? '') === 'diploma_doc' ? 'diploma_doc' : 'id_doc';
    $s = $db->prepare("SELECT $which p FROM accounts WHERE id=?"); $s->execute([$id]);
    $rel = (string)$s->fetchColumn();
    if ($rel === '' || !str_starts_with($rel, 'data/uploads/')) out(['error' => 'Document introuvable.'], 404);
    $abs = realpath(__DIR__ . '/' . $rel);
    $base = realpath(__DIR__ . '/data/uploads');
    if (!$abs || !$base || !str_starts_with($abs, $base) || !is_file($abs)) out(['error' => 'Document introuvable.'], 404);
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($abs) ?: 'application/octet-stream';
    header('Content-Type: ' . $mime);
    header('Content-Disposition: inline; filename="' . basename($abs) . '"');
    header('X-Robots-Tag: noindex, nofollow');
    readfile($abs);
    exit;
}

/* ---------- Vérification des prestataires (CNI + diplôme) ---------- */
case 'admin_verify': {
    require_admin(); $b = body();
    $id = (int)($b['id'] ?? 0);
    $s = $db->prepare("SELECT * FROM accounts WHERE id=? AND type='Prestataire'"); $s->execute([$id]);
    $acc = $s->fetch();
    if (!$acc) out(['error' => 'Prestataire introuvable.'], 404);
    $allowed = ['Vérifié', 'Refusé', 'En attente', 'Documents partiels', 'Documents à fournir'];
    $st = in_array($b['status'] ?? '', $allowed, true) ? $b['status'] : 'En attente';
    $note = clean_text($b['note'] ?? '', 240);
    $db->prepare("UPDATE accounts SET verify_status=?, verify_note=?, verified_at=" . ($st === 'Vérifié' ? 'CURRENT_TIMESTAMP' : 'NULL') . " WHERE id=?")
       ->execute([$st, $note ?: null, $id]);
    log_event('verification_maj', ['account_id' => $id, 'account_name' => $acc['name'], 'status' => $st, 'details' => 'Vérification prestataire : ' . $st . ($note ? ' · ' . $note : '')]);
    if ($st === 'Vérifié') notify_admin('Y4I Academy — prestataire vérifié', '<h2>Prestataire vérifié</h2><p><b>' . h($acc['name']) . '</b> · ' . h($acc['contact']) . '</p>');
    out(['ok' => true, 'status' => $st]);
}

/* ---------- Témoignages (publics + administration) ---------- */
case 'admin_testimonial_save': {
    require_admin(); $b = body();
    $id = (int)($b['id'] ?? 0);
    $name = clean_text($b['name'] ?? '', 120);
    $role = clean_text($b['role'] ?? '', 120);
    $message = clean_multiline($b['message'] ?? '', 1200);
    $rating = max(1, min(5, (int)($b['rating'] ?? 5)));
    $published = !empty($b['published']) ? 1 : 0;
    if ($name === '' || mb_strlen($message) < 10) out(['error' => 'Indiquez un nom et un témoignage de 10 caractères minimum.'], 422);
    if ($id > 0) {
        $db->prepare("UPDATE testimonials SET name=?, role=?, message=?, rating=?, published=? WHERE id=?")
           ->execute([$name, $role ?: null, $message, $rating, $published, $id]);
        log_event('temoignage_modifie', ['account_name' => $name, 'details' => $message]);
    } else {
        $db->prepare("INSERT INTO testimonials(name, role, message, rating, published) VALUES(?,?,?,?,?)")
           ->execute([$name, $role ?: null, $message, $rating, $published]);
        $id = (int)$db->lastInsertId();
        log_event('temoignage_cree', ['account_name' => $name, 'details' => $message]);
    }
    out(['ok' => true, 'id' => $id]);
}
case 'admin_testimonial_delete': {
    require_admin(); $b = body();
    $id = (int)($b['id'] ?? 0);
    $s = $db->prepare("SELECT name FROM testimonials WHERE id=?"); $s->execute([$id]);
    $n = $s->fetchColumn();
    $db->prepare("DELETE FROM testimonials WHERE id=?")->execute([$id]);
    log_event('temoignage_supprime', ['account_name' => (string)$n]);
    out(['ok' => true]);
}

case 'admin_export': {   // export CSV du journal complet (ouvrable dans Excel / LibreOffice)
    require_admin(); log_event('journal_exporte');
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="journal-y4i-' . date('Ymd-His') . '.csv"');
    $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF");
    fputcsv($o, ['Date', 'Evenement', 'Compte', 'Montant FCFA', 'Passerelle', 'Reference', 'Statut', 'Telephone', 'IP', 'Details'], ';');
    foreach ($db->query("SELECT * FROM activity_log ORDER BY id ASC") as $r)
        fputcsv($o, [date('Y-m-d H:i:s', (int)$r['ts']), $r['event'], $r['account_name'], $r['amount'], $r['gateway'], $r['reference'], $r['status'], $r['phone'], $r['ip'], $r['details']], ';');
    exit;
}
case 'admin_export_accounts': {
    require_admin(); log_event('comptes_exportes');
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="comptes-y4i-' . date('Ymd-His') . '.csv"');
    $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF");
    fputcsv($o, ['ID', 'Nom', 'Contact', 'Email', 'Quartier', 'Type', 'Formation', 'Code formation', 'Description prestation', 'Statut', 'Creation'], ';');
    foreach ($db->query("SELECT * FROM accounts ORDER BY id ASC") as $r)
        fputcsv($o, [$r['id'], $r['name'], $r['contact'], $r['email'], $r['location'], $r['type'], $r['formation_label'], $r['formation_code'], $r['service_description'], $r['status'], $r['created_at']], ';');
    exit;
}

default: out(['error' => 'Action inconnue'], 404);
}
} catch (Throwable $e) {
    out(['error' => !empty(cfg()['debug']) ? $e->getMessage() : 'Erreur serveur. Réessayez dans un instant.'], 500);
}

/* ---------- Repli d'itinéraire (aucune dépendance à un service externe) ---------- */
function fallback_route(float $flat, float $flng, float $tlat, float $tlng, string $profile): array {
    $dist = haversine_m($flat, $flng, $tlat, $tlng);
    $factor = $profile === 'walking' ? 1.22 : ($profile === 'cycling' ? 1.28 : 1.38);
    $distance = max(60, $dist * $factor);
    $speed = $profile === 'walking' ? 1.35 : ($profile === 'cycling' ? 4.2 : 8.8);
    $duration = max(60, $distance / $speed);
    $n = 10; $pts = [];
    for ($i = 0; $i <= $n; $i++) {
        $t = $i / $n;
        $curve = sin(pi() * $t) * 0.0018;
        $lat = $flat + ($tlat - $flat) * $t + $curve * (($tlng - $flng) >= 0 ? 1 : -1);
        $lng = $flng + ($tlng - $flng) * $t - $curve * (($tlat - $flat) >= 0 ? 1 : -1);
        $pts[] = [round($lng, 6), round($lat, 6)];
    }
    if (end($pts) !== [round($tlng, 6), round($tlat, 6)]) $pts[] = [round($tlng, 6), round($tlat, 6)];
    $steps = [
        ['maneuver' => ['type' => 'depart', 'modifier' => 'straight'], 'name' => 'Point de départ', 'distance' => 0, 'duration' => 0],
        ['maneuver' => ['type' => 'continue', 'modifier' => 'straight'], 'name' => 'Trajet estimé (mode simplifié)', 'distance' => $distance, 'duration' => $duration],
        ['maneuver' => ['type' => 'arrive', 'modifier' => 'straight'], 'name' => 'Destination', 'distance' => 0, 'duration' => 0],
    ];
    return ['routes' => [[
        'geometry' => ['type' => 'LineString', 'coordinates' => $pts],
        'distance' => round($distance, 1), 'duration' => round($duration, 1),
        'legs' => [['steps' => $steps, 'distance' => round($distance, 1), 'duration' => round($duration, 1)]],
    ]], 'fallback' => true, 'profile' => $profile];
}

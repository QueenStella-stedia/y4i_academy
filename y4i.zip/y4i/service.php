<?php
require_once __DIR__ . '/inc_public.php';

$key = trim((string)($_GET['service'] ?? ''));
$s = $key !== '' ? service_by_key($key) : null;

if (!$s) {
    http_response_code(404);
    public_head('Service introuvable', 'Ce service n’existe pas ou n’est plus disponible.', 'service.php');
    public_footer();
    exit;
}

$title = (string)$s[1];
$desc = (string)$s[2];
$tariff = null;
try { foreach (db()->query("SELECT * FROM tariffs") as $r) if ($r['k'] === $key) $tariff = $r; } catch (Throwable $e) {}
$waText = rawurlencode('Bonjour Y4I Academy, je souhaite des informations sur le service : ' . $title . '.');

public_head($title . ' à Yaoundé', mb_substr($desc, 0, 180), 'service.php?service=' . urlencode($key));
?>
<section class="page-hero"><div class="wrap">
  <p class="breadcrumb" style="color:#B9CBE3"><a style="color:#fff" href="<?= h(abs_url('index.php')) ?>">Accueil</a> › <a style="color:#fff" href="<?= h(abs_url('index.php#services')) ?>">Services</a> › <?= h($title) ?></p>
  <span class="kicker"><i></i> Service à domicile</span>
  <h1><?= h($title) ?></h1>
  <p><?= h($desc) ?></p>
</div></section>

<main class="page-main"><div class="wrap page-grid">
  <article class="legal-body">
    <h2>Ce que comprend le service</h2>
    <p><?= h($desc) ?></p>
    <ul><?php foreach ($s[3] as $item): ?><li><i class="fas fa-check" style="color:var(--ok);margin-right:.4rem"></i><?= h($item) ?></li><?php endforeach; ?></ul>

    <h2>Comment ça se passe</h2>
    <h3>1. Vous décrivez votre besoin</h3>
    <p>Par téléphone, WhatsApp ou via le formulaire du site. Nous précisons ensemble les tâches, les horaires et le lieu d'intervention.</p>
    <h3>2. Nous proposons un intervenant</h3>
    <p>Nous choisissons une personne adaptée à votre situation. Les prestataires déposent un fonds de garantie bloqué par Mobile Money.</p>
    <h3>3. Vous suivez l'intervention</h3>
    <p>Un code de suivi permet de voir la position de l'intervenant sur la carte, uniquement pendant la prestation.</p>

    <h2>Tarif</h2>
    <p><?php if ($tariff && (int)$tariff['price'] > 0): ?><b>Dès <?= number_format((int)$tariff['price'], 0, ',', ' ') ?> FCFA / <?= h((string)$tariff['unit']) ?></b><?php else: ?><b>Tarif sur devis</b><?php endif; ?> — le prix dépend des heures, des tâches et du lieu. Aucun montant n'est débité sur cette page.</p>
    <p class="hint">Les soins médicaux et la kinésithérapie sont organisés avec des professionnels qualifiés, selon l'orientation médicale lorsque nécessaire.</p>

    <div class="row" style="margin-top:1.4rem">
      <a class="btn btn-primary" href="<?= h(abs_url('index.php?service=' . urlencode($key) . '#contact')) ?>"><i class="fas fa-file-signature"></i> Demander un devis</a>
      <a class="btn btn-ghost" href="https://wa.me/<?= h(cfg()['whatsapp']) ?>?text=<?= $waText ?>" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i> WhatsApp</a>
    </div>
  </article>

  <aside>
    <div class="side-card">
      <h3><i class="fas fa-shield-halved"></i> Un cadre sécurisé</h3>
      <p>Fonds de garantie bloqué, paiement Mobile Money, suivi de position pendant la prestation et administration joignable <?= h(company_info()['hours']) ?>.</p>
    </div>
    <div class="side-card" style="margin-top:1rem">
      <h3><i class="fas fa-hand-holding-heart"></i> Autres services</h3>
      <?php foreach (services_all() as $k => $other): if ($k === $key || $k === 'formation') continue; ?>
        <p><a href="service.php?service=<?= h($k) ?>" style="text-decoration:none;color:var(--navy);font-weight:700"><?= h($other[1]) ?></a></p>
      <?php endforeach; ?>
      <p><a href="<?= h(abs_url('index.php#formations')) ?>" style="text-decoration:none;color:var(--navy);font-weight:700">Formations professionnelles</a></p>
    </div>
    <div class="side-card" style="margin-top:1rem">
      <h3><i class="fas fa-phone"></i> Nous joindre</h3>
      <p><?= h(company_info()['address']) ?><br><a href="tel:+<?= h(cfg()['phone_secondary'] ?? '') ?>">+237 622 142 496</a></p>
    </div>
  </aside>
</div></main>
<?php public_footer(); ?>

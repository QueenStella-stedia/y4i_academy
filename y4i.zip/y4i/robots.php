<?php
require_once __DIR__ . '/lib.php';
header('Content-Type: text/plain; charset=utf-8');
?>
User-agent: *
Allow: /
Disallow: /api.php
Disallow: /admin/
Disallow: /data/
Disallow: /check.php
Disallow: /export.php
Disallow: /receipt.php
Disallow: /payment.php

Sitemap: <?= abs_url('sitemap.xml') ?>

# Y4I Academy — robots.txt généré par robots.php

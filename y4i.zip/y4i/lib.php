<?php
$CFG = require __DIR__ . '/config.php';

/* ---------- Sécurité de base ---------- */
function is_https(): bool {
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || (($_SERVER['SERVER_PORT'] ?? '') === '443');
}
if (!empty($CFG['debug'])) { ini_set('display_errors', '1'); error_reporting(E_ALL); }
else { ini_set('display_errors', '0'); error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE); }

if (is_https()) {
    header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
}
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=(self), camera=(), microphone=(), payment=(self)');
$analytics = cfg()['analytics'] ?? [];
$extraScript = ' https://www.googletagmanager.com https://www.google-analytics.com';
$extraConnect = ' https://www.google-analytics.com https://region1.google-analytics.com';
$extraImg = ' https://www.google-analytics.com https://www.googletagmanager.com';
if (($analytics['provider'] ?? '') === 'matomo' && !empty($analytics['host'])) {
    $mh = rtrim((string)$analytics['host'], '/');
    $extraScript .= ' ' . $mh; $extraConnect .= ' ' . $mh; $extraImg .= ' ' . $mh;
}
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://unpkg.com https://cdnjs.cloudflare.com" . $extraScript . "; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdnjs.cloudflare.com https://unpkg.com; font-src 'self' data: https://fonts.gstatic.com https://cdnjs.cloudflare.com; img-src 'self' data: blob: https://*.tile.openstreetmap.org https://tile.openstreetmap.org https://unpkg.com" . $extraImg . "; connect-src 'self'" . $extraConnect . "; frame-ancestors 'self'; base-uri 'self'; form-action 'self' https://wa.me;");

/* ---------- Erreurs lisibles (fini la page blanche) ---------- */
set_exception_handler(function (Throwable $e) {
    $msg = !empty(cfg()['debug']) ? $e->getMessage() : 'Erreur serveur';
    if (str_contains($_SERVER['SCRIPT_NAME'] ?? '', 'api.php')) {
        http_response_code(500); header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => $msg], JSON_UNESCAPED_UNICODE); return;
    }
    http_response_code(500);
    echo '<!DOCTYPE html><meta charset="utf-8"><body style="font-family:sans-serif;max-width:640px;margin:60px auto;padding:0 20px">'
       . '<h2 style="color:#C8102E">Le site ne peut pas démarrer</h2><p><b>' . htmlspecialchars($msg) . '</b></p>'
       . (!empty(cfg()['debug']) ? '<p>Ouvrez la page de diagnostic : <a href="check.php">check.php</a></p>' : '') . '</body>';
});

/* ---------- Session sécurisée ---------- */
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    if (is_https()) ini_set('session.cookie_secure', '1');
    session_name('y4i_sid');
    @session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    @session_start();
}

function cfg(): array { global $CFG; return $CFG; }
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

/* ---------- URL, entreprise, e-mails ---------- */
function app_url(): string { return rtrim((string)(cfg()['app_url'] ?? ''), '/'); }
function abs_url(string $path = ''): string { return app_url() . '/' . ltrim($path, '/'); }
function company_info(): array {
    $c = cfg()['company'] ?? [];
    return array_merge([
        'name' => 'Y4I Academy', 'legal_name' => 'Y4I Academy — à compléter',
        'registration' => 'RCCM / NIU : à compléter', 'address' => 'Odza, Yaoundé, Cameroun',
        'manager' => 'Responsable de publication : à compléter', 'hours' => '24h/24 – 7j/7',
        'maps' => 'https://maps.google.com/?q=Odza,Yaound%C3%A9,Cameroun',
    ], is_array($c) ? $c : []);
}
function is_local_request(): bool {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'cli';
    $host = $_SERVER['HTTP_HOST'] ?? '';
    return in_array($ip, ['127.0.0.1', '::1', 'cli'], true)
        || in_array($host, ['localhost', '127.0.0.1'], true)
        || str_starts_with($host, 'localhost:') || str_starts_with($host, '127.0.0.1:');
}
/** Envoi d'e-mail HTML simple. Retourne false si désactivé ou en cas d'échec (jamais bloquant). */
function send_mail(string $to, string $subject, string $html, string $text = ''): bool {
    $m = cfg()['mail'] ?? [];
    if (empty($m['enabled']) || !valid_email($to)) return false;
    $from = (string)($m['from'] ?? ''); $fromName = (string)($m['from_name'] ?? 'Y4I Academy');
    if (!valid_email($from)) return false;
    $clean = fn($s) => trim(str_replace(["\r", "\n"], ' ', (string)$s));
    $headers = [
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . mb_encode_mimeheader($clean($fromName), 'UTF-8') . ' <' . $clean($from) . '>',
        'Reply-To: ' . $clean((string)($m['reply_to'] ?? $from)),
        'X-Mailer: Y4I-Academy',
    ];
    $body = '<!DOCTYPE html><html lang="fr"><body style="font-family:Arial,sans-serif;color:#12233b;line-height:1.55">'
        . '<div style="max-width:640px;margin:auto;padding:24px">'
        . '<p style="font-size:13px;color:#5b6b7f;margin:0 0 18px">' . h(company_info()['name']) . ' · ' . h(company_info()['address']) . '</p>'
        . $html
        . '<hr style="border:0;border-top:1px solid #e5eaf0;margin:26px 0"><p style="font-size:12px;color:#7a8798">'
        . 'Message automatique — ne répondez pas directement. Écrivez à ' . h((string)($m['reply_to'] ?? $from)) . '.</p></div></body></html>';
    try { return @mail($to, mb_encode_mimeheader($clean($subject), 'UTF-8'), $body, implode("\r\n", $headers)); }
    catch (Throwable $e) { return false; }
}
function notify_admin(string $subject, string $html): void {
    $to = (string)(cfg()['mail']['admin'] ?? '');
    if ($to === '' || !valid_email($to)) return;
    send_mail($to, $subject, $html);
}
function receipt_url(int $paymentId, string $token): string { return abs_url('receipt.php?id=' . $paymentId . '&token=' . urlencode($token)); }
function send_payment_receipt_email(int $paymentId): bool {
    $db = db();
    $s = $db->prepare("SELECT p.*, a.name, a.email FROM payments p LEFT JOIN accounts a ON a.id=p.account_id WHERE p.id=?");
    $s->execute([$paymentId]); $p = $s->fetch();
    if (!$p || empty($p['email'])) return false;
    $url = receipt_url((int)$p['id'], (string)$p['token']);
    $html = '<h2 style="color:#0C2B4E">Fonds de garantie confirmé</h2>'
        . '<p>Bonjour ' . h((string)$p['name']) . ',</p>'
        . '<p>Votre paiement de <b>' . number_format((int)$p['amount'], 0, ',', ' ') . ' FCFA</b> a bien été reçu. '
        . 'Votre fonds de garantie est enregistré et votre compte prestataire est actif.</p>'
        . '<p><a href="' . h($url) . '" style="display:inline-block;background:#C8102E;color:#fff;padding:11px 18px;border-radius:8px;text-decoration:none">Télécharger mon reçu</a></p>'
        . '<p style="font-size:13px;color:#5b6b7f">Référence : ' . h((string)$p['reference']) . '</p>';
    return send_mail((string)$p['email'], 'Y4I Academy — reçu de votre fonds de garantie', $html);
}

/* ---------- Catalogue services (partagé par index.php et service.php) ---------- */
function services_all(): array {
    return [
        'formation' => ['fa-graduation-cap', 'Formations professionnelles', 'Des parcours encadrés dans le domaine de la santé, pensés pour acquérir des compétences concrètes et rejoindre durablement le monde professionnel.', array_map(fn($f) => $f['title'], formations_all(true))],
        'aide'      => ['fa-hand-holding-heart', 'Aide à domicile', 'Un soutien adapté aux gestes du quotidien, avec une présence attentive qui respecte le rythme de chacun.', ['Auxiliaires de vie', 'Toilette & repas', 'Présence quotidienne']],
        'hopital'   => ['fa-hospital', 'Accompagnement à l\'hôpital', 'Une présence rassurante lors des hospitalisations, rendez-vous, examens ou sorties d\'établissement.', ['Rendez-vous', 'Visites', 'Retour à domicile']],
        'kine'      => ['fa-user-doctor', 'Kinésithérapie & soins', 'Séances de rééducation et de bien-être à domicile, selon les besoins et l\'orientation médicale.', ['Rééducation', 'Mobilité', 'Professionnels qualifiés']],
        'courses'   => ['fa-basket-shopping', 'Courses & quotidien', 'Marché, pharmacie, petites démarches : nous nous en occupons, pour que la maison reste un lieu simple à vivre.', ['Courses', 'Pharmacie', 'Petites commissions']],
    ];
}
function service_by_key(string $key): ?array { $s = services_all(); return $s[$key] ?? null; }
function formation_by_slug(string $slug): ?array {
    foreach (formations_all(true) as $f) if (($f['slug'] ?? '') === $slug) return $f;
    return null;
}

/* ---------- Upload sécurisé des pièces de vérification ---------- */
function upload_doc(string $field, string $prefix): ?string {
    if (empty($_FILES[$field]) || !is_array($_FILES[$field]) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    $f = $_FILES[$field];
    if (($f['error'] ?? 0) !== UPLOAD_ERR_OK) throw new Exception('Le fichier « ' . $field . ' » n’a pas pu être envoyé. Réessayez.');
    if (($f['size'] ?? 0) > 4 * 1024 * 1024) throw new Exception('Chaque document doit faire moins de 4 Mo.');
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string)$finfo->file($f['tmp_name']);
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf'];
    if (!isset($allowed[$mime])) throw new Exception('Format non accepté. Utilisez une photo JPG/PNG ou un PDF.');
    $dir = __DIR__ . '/data/uploads';
    if (!is_dir($dir) && !@mkdir($dir, 0770, true)) throw new Exception('Dossier de stockage indisponible.');
    $name = $prefix . '-' . date('Ymd') . '-' . bin2hex(random_bytes(10)) . '.' . $allowed[$mime];
    if (!@move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) throw new Exception('Impossible d’enregistrer le document.');
    @chmod($dir . '/' . $name, 0640);
    return 'data/uploads/' . $name;
}

/* ---------- Connexion : MySQL (XAMPP) en priorité, SQLite en secours ---------- */
function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $c = cfg()['db']; $errors = []; $driver = null;
    $opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC];

    if (in_array($c['driver'], ['auto', 'mysql'], true)) {
        if (!extension_loaded('pdo_mysql')) $errors[] = 'extension pdo_mysql absente';
        else try {
            $p = new PDO("mysql:host={$c['host']};port={$c['port']};charset=utf8mb4", $c['user'], $c['pass'], $opt);
            $p->exec("CREATE DATABASE IF NOT EXISTS `{$c['name']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $p->exec("USE `{$c['name']}`");
            $pdo = $p; $driver = 'mysql';
        } catch (Throwable $e) { $errors[] = 'MySQL : ' . $e->getMessage(); }
    }
    if (!$pdo && in_array($c['driver'], ['auto', 'sqlite'], true)) {
        if (!extension_loaded('pdo_sqlite')) $errors[] = 'extension pdo_sqlite absente';
        else try {
            $dir = __DIR__ . '/data';
            if (!is_dir($dir)) @mkdir($dir, 0777, true);
            if (!is_writable($dir)) throw new Exception("dossier data/ non inscriptible (faites : sudo chmod -R 777 $dir)");
            $pdo = new PDO('sqlite:' . $dir . '/y4i.sqlite', null, null, $opt); $driver = 'sqlite';
        } catch (Throwable $e) { $errors[] = 'SQLite : ' . $e->getMessage(); }
    }
    if (!$pdo) throw new Exception('Aucune base disponible. ' . implode(' | ', $errors));
    $GLOBALS['DB_DRIVER'] = $driver;
    init_schema($pdo, $driver);
    return $pdo;
}
function db_driver(): string { db(); return $GLOBALS['DB_DRIVER'] ?? 'mysql'; }

function table_cols(PDO $pdo, string $d, string $t): array {
    try {
        if ($d === 'mysql') return array_map(fn($r) => $r['Field'], $pdo->query("SHOW COLUMNS FROM `$t`")->fetchAll());
        return array_map(fn($r) => $r['name'], $pdo->query("PRAGMA table_info($t)")->fetchAll());
    } catch (Throwable $e) { return []; }
}
function ensure_column(PDO $pdo, string $d, string $t, string $col, string $def): void {
    if (!in_array($col, table_cols($pdo, $d, $t), true)) {
        $pdo->exec("ALTER TABLE $t ADD COLUMN $col $def");
    }
}

function init_schema(PDO $pdo, string $d): void {
    $pk  = $d === 'mysql' ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY';
    $ig  = $d === 'mysql' ? 'INSERT IGNORE' : 'INSERT OR IGNORE';
    $eng = $d === 'mysql' ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4' : '';

    $tables = [
      'accounts' => "id $pk, name VARCHAR(120), contact VARCHAR(60), email VARCHAR(160), location VARCHAR(160), type VARCHAR(20),
         payment_method VARCHAR(60), status VARCHAR(40) DEFAULT 'Actif', formation_code VARCHAR(20), formation_label VARCHAR(140),
         formation_spec TEXT, service_description TEXT, experience VARCHAR(60), zone VARCHAR(160), notes TEXT,
         refs TEXT, verify_status VARCHAR(30) DEFAULT 'Non vérifié', verify_note VARCHAR(240), id_doc VARCHAR(200),
         diploma_doc VARCHAR(200), verified_at TIMESTAMP NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
      'payments' => "id $pk, account_id INT, gateway VARCHAR(20), reference VARCHAR(120), external_ref VARCHAR(120),
         amount INT, phone VARCHAR(20), status VARCHAR(20) DEFAULT 'PENDING', ussd_code VARCHAR(40), pay_url VARCHAR(500),
         extra VARCHAR(200), token VARCHAR(64), created_ts INT DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
      'tariffs' => "k VARCHAR(40) PRIMARY KEY, label VARCHAR(120), price INT, unit VARCHAR(40)",
      'settings' => "k VARCHAR(40) PRIMARY KEY, v TEXT",
      'formations' => "id $pk, code VARCHAR(20) UNIQUE, slug VARCHAR(80), title VARCHAR(140), short TEXT, description TEXT,
         specification TEXT, modules TEXT, duration VARCHAR(100), prerequisites TEXT, certification VARCHAR(240), price INT DEFAULT 0,
         price_note VARCHAR(120), icon VARCHAR(50), image VARCHAR(160), color VARCHAR(20), active INT DEFAULT 1, sort INT DEFAULT 0,
         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
      'requests' => "id $pk, code VARCHAR(12), pkey VARCHAR(40), name VARCHAR(120), phone VARCHAR(40), service VARCHAR(120),
         formation_code VARCHAR(20), details TEXT, zone VARCHAR(160), address VARCHAR(240), from_lat DOUBLE, from_lng DOUBLE,
         to_lat DOUBLE, to_lng DOUBLE, distance_m INT, duration_s INT, estimate INT, status VARCHAR(30) DEFAULT 'Nouvelle',
         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
      'tracking' => "code VARCHAR(12), lat DOUBLE, lng DOUBLE, accuracy DOUBLE, ts INT",
      'messages' => "id $pk, name VARCHAR(120), phone VARCHAR(40), email VARCHAR(160), need VARCHAR(120), formation_code VARCHAR(20),
         message TEXT, source VARCHAR(30), status VARCHAR(20) DEFAULT 'Nouveau', ip VARCHAR(45), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
      'geocache' => "k VARCHAR(190) PRIMARY KEY, json TEXT, ts INT",
      'rate_limits' => "k VARCHAR(190), ts INT",
      'activity_log' => "id $pk, ts INT, event VARCHAR(40), account_id INT, account_name VARCHAR(120), amount INT, gateway VARCHAR(20),
         reference VARCHAR(120), status VARCHAR(30), phone VARCHAR(30), ip VARCHAR(45), details VARCHAR(400)",
      'testimonials' => "id $pk, name VARCHAR(120), role VARCHAR(120), message TEXT, rating INT DEFAULT 5,
         published INT DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
    ];
    foreach ($tables as $name => $def) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS $name($def)$eng");
    }

    // Migration douce : on ajoute les colonnes manquantes au lieu de renommer/supprimer la table
    foreach ([
        ['accounts', 'email', 'VARCHAR(160)'], ['accounts', 'formation_code', 'VARCHAR(20)'],
        ['accounts', 'formation_label', 'VARCHAR(140)'], ['accounts', 'formation_spec', 'TEXT'],
        ['accounts', 'service_description', 'TEXT'], ['accounts', 'experience', 'VARCHAR(60)'],
        ['accounts', 'zone', 'VARCHAR(160)'], ['accounts', 'notes', 'TEXT'],
        ['accounts', 'refs', 'TEXT'], ['accounts', 'verify_status', "VARCHAR(30) DEFAULT 'Non vérifié'"],
        ['accounts', 'verify_note', 'VARCHAR(240)'], ['accounts', 'id_doc', 'VARCHAR(200)'],
        ['accounts', 'diploma_doc', 'VARCHAR(200)'], ['accounts', 'verified_at', 'TIMESTAMP NULL'],
        ['payments', 'token', 'VARCHAR(64)'],
        ['requests', 'formation_code', 'VARCHAR(20)'], ['requests', 'zone', 'VARCHAR(160)'], ['requests', 'address', 'VARCHAR(240)'],
        ['tracking', 'accuracy', 'DOUBLE'],
    ] as [$t, $col, $def]) ensure_column($pdo, $d, $t, $col, $def);

    // Un jeton par paiement : le statut n'est consultable qu'avec ce jeton
    try {
        $rows = $pdo->query("SELECT id FROM payments WHERE token IS NULL OR token=''")->fetchAll();
        if ($rows) {
            $u = $pdo->prepare("UPDATE payments SET token=? WHERE id=?");
            foreach ($rows as $r) $u->execute([bin2hex(random_bytes(24)), $r['id']]);
        }
    } catch (Throwable $e) { /* ignore */ }

    foreach (['idx_track' => 'tracking(code, ts)', 'idx_rate' => 'rate_limits(k, ts)', 'idx_messages' => 'messages(created_at)'] as $name => $cols) {
        try { $pdo->exec("CREATE INDEX IF NOT EXISTS $name ON $cols"); } catch (Throwable $e) { /* MySQL ne connaît pas IF NOT EXISTS pour un index */ }
    }

    // Données de base (idempotent)
    $t = $pdo->prepare("$ig INTO tariffs(k,label,price,unit) VALUES(?,?,?,?)");
    foreach ([
        ['aide', 'Aide à domicile', 0, 'intervention'],
        ['hopital', 'Accompagnement hôpital & soins', 0, 'visite'],
        ['kine', 'Kinésithérapie à domicile', 0, 'séance'],
        ['courses', 'Courses & quotidien', 0, 'commission'],
    ] as $r) $t->execute($r);

    $s = $pdo->prepare("$ig INTO settings(k,v) VALUES(?,?)");
    foreach ([['min_guarantee', cfg()['min_guarantee']], ['km_price', 300], ['base_fee', 1000]] as $r) $s->execute($r);
    // Réparation : une ancienne valeur de garantie aberrante (ex. 5 FCFA) est corrigée
    $min = (int)setting('min_guarantee', 5000);
    if ($min < 1000) set_setting('min_guarantee', max(5000, (int)cfg()['min_guarantee']));

    seed_formations($pdo, $d, $ig);

    if ((int)$pdo->query("SELECT COUNT(*) FROM accounts")->fetchColumn() === 0) {
        $a = $pdo->prepare("INSERT INTO accounts(name,contact,location,type,payment_method,status) VALUES(?,?,?,?,?,?)");
        $a->execute(['Pauline Manga', '+237 690000001', 'Odza', 'Client', 'Orange Money', 'Actif']);
        $a->execute(['Dr. Armand Tamo', '+237 670000002', 'Bastos', 'Prestataire', 'MTN MoMo', 'Actif']);
        $pdo->prepare("INSERT INTO payments(account_id,gateway,reference,amount,phone,status,token,created_ts) VALUES(2,'sim','seed',40000,'237670000002','SUCCESS',?,?)")
            ->execute([bin2hex(random_bytes(24)), time()]);
    }
}

function seed_formations(PDO $pdo, string $d, string $ig): void {
    $rows = [
      [
        'AV', 'auxiliaire-de-vie', 'Auxiliaire de vie',
        "Un accompagnement humain et pratique auprès des personnes âgées, malades ou en situation de dépendance.",
        "La formation d'auxiliaire de vie prépare à accompagner une personne dans les gestes essentiels du quotidien : hygiène, repas, lever et coucher, mobilité, présence et lien social. Elle combine apports théoriques, mises en situation et stage pratique encadré.",
        "À l'issue du parcours, le stagiaire sait organiser son intervention, respecter l'intimité et la dignité de la personne, prévenir les chutes, réagir face à une situation inhabituelle et communiquer avec la famille et les soignants.",
        "Hygiène et confort; Alimentation et hydratation; Mobilisation et prévention des chutes; Communication et éthique; Organisation de l'intervention; Stage pratique",
        '6 mois — théorie + stage', 'Savoir lire et écrire; être âgé de 18 ans et plus; dossier de candidature',
        'Attestation de fin de formation Y4I Academy + évaluation pratique', 0, 'Nous consulter', 'fa-hand-holding-heart', 'formation-auxiliaire-vie.jpg', 'rose', 1, 1,
      ],
      [
        'SI', 'soin-infirmier', 'Soin infirmier',
        "Les fondamentaux du soin infirmier pour accompagner les patients avec rigueur, douceur et professionnalisme.",
        "Ce parcours professionnalisant aborde les bases du soin, l'hygiène, la surveillance du patient, les gestes techniques encadrés et la relation de soin. Les apprenants travaillent sur des cas concrets et effectuent des stages en structure de santé.",
        "Le stagiaire apprend à préparer un soin, appliquer les règles d'hygiène et d'asepsie, surveiller les signes vitaux, transmettre les informations utiles et adopter une posture professionnelle auprès du patient et de sa famille.",
        "Hygiène hospitalière et asepsie; Surveillance des signes vitaux; Soins de confort; Relation et communication; Déontologie; Stages en structure",
        '24 mois — théorie + stages', 'Niveau BEPC ou équivalent; être âgé de 17 ans et plus; dossier de candidature',
        'Attestation Y4I Academy + dossier de présentation aux évaluations', 0, 'Nous consulter', 'fa-user-nurse', 'formation-soin-infirmier.jpg', 'blue', 1, 2,
      ],
      [
        'KIN', 'kinesitherapie', 'Kinésithérapie',
        "La rééducation et le mouvement au service du confort, de l'autonomie et de la récupération.",
        "La formation en kinésithérapie présente les bases de l'anatomie, de la biomécanique et des techniques de rééducation. Elle insiste sur la prévention, la mobilisation, les exercices adaptés et la collaboration avec les professionnels de santé.",
        "Le stagiaire est initié à l'évaluation de la mobilité, à la préparation d'une séance, aux techniques de base encadrées et aux règles de sécurité. Une attention particulière est portée au respect du cadre médical et des orientations du patient.",
        "Anatomie et biomécanique; Mobilisation et renforcement; Rééducation fonctionnelle; Prévention des blessures; Relation thérapeutique; Stage pratique",
        '24 mois — théorie + stage', 'Niveau Bac ou équivalent recommandé; dossier de candidature; entretien de motivation',
        'Attestation Y4I Academy + évaluation des compétences', 0, 'Nous consulter', 'fa-person-walking', 'formation-kinesitherapie.jpg', 'teal', 1, 3,
      ],
      [
        'LAB', 'laboratoire', 'Laboratoire',
        "Les gestes et les règles du laboratoire d'analyses pour travailler avec précision et sécurité.",
        "Cette formation couvre l'organisation du laboratoire, les prélèvements, la préparation des échantillons, les contrôles de qualité et les bonnes pratiques d'hygiène et de sécurité. Les apprenants manipulent le matériel sous supervision.",
        "Le stagiaire apprend à identifier le matériel, respecter un protocole, tracer les résultats, appliquer les règles de biosécurité et alerter en cas d'anomalie. La rigueur et la confidentialité sont au cœur du parcours.",
        "Organisation du laboratoire; Prélèvements et échantillons; Contrôle qualité; Biosécurité; Traçabilité; Stage en laboratoire",
        '18 mois — théorie + stage', 'Niveau Bac scientifique recommandé; dossier de candidature',
        'Attestation Y4I Academy + évaluation pratique', 0, 'Nous consulter', 'fa-flask-vial', 'formation-laboratoire.jpg', 'violet', 1, 4,
      ],
      [
        'AP', 'auxiliaire-de-pharmacie', 'Auxiliaire de pharmacie',
        "Un parcours concret pour accompagner l'équipe officinale et conseiller avec responsabilité.",
        "La formation d'auxiliaire de pharmacie aborde la connaissance des médicaments, la lecture des ordonnances, la gestion des stocks, l'accueil du client et les règles de délivrance. Elle prépare à un rôle d'appui sous la responsabilité du pharmacien.",
        "Le stagiaire apprend à organiser une officine, ranger et suivre les produits, accueillir le public, transmettre une information fiable et respecter scrupuleusement la réglementation et la confidentialité.",
        "Médicaments et formes galéniques; Lecture d'ordonnance; Gestion des stocks; Accueil et conseil; Réglementation; Stage en officine",
        '12 mois — théorie + stage', 'Niveau Bac ou équivalent recommandé; dossier de candidature',
        'Attestation Y4I Academy + évaluation pratique', 0, 'Nous consulter', 'fa-capsules', 'formation-pharmacie.jpg', 'gold', 1, 5,
      ],
    ];
    $stmt = $pdo->prepare("$ig INTO formations(code,slug,title,short,description,specification,modules,duration,prerequisites,certification,price,price_note,icon,image,color,active,sort)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    foreach ($rows as $r) $stmt->execute($r);
}

/* ---------- Journal d'activité permanent ---------- */
function mask_phone(?string $p): ?string {
    if (!$p) return null; $p = preg_replace('/\D/', '', $p);
    return strlen($p) > 7 ? substr($p, 0, 4) . str_repeat('*', strlen($p) - 7) . substr($p, -3) : $p;
}
function account_name(int $id): ?string {
    $s = db()->prepare("SELECT name FROM accounts WHERE id=?"); $s->execute([$id]);
    $n = $s->fetchColumn(); return $n === false ? null : $n;
}
function log_event(string $event, array $d = []): void {
    try {
        db()->prepare("INSERT INTO activity_log(ts,event,account_id,account_name,amount,gateway,reference,status,phone,ip,details) VALUES(?,?,?,?,?,?,?,?,?,?,?)")
          ->execute([time(), $event, $d['account_id'] ?? null, $d['account_name'] ?? null, $d['amount'] ?? null, $d['gateway'] ?? null,
                     $d['reference'] ?? null, $d['status'] ?? null, mask_phone($d['phone'] ?? null), $_SERVER['REMOTE_ADDR'] ?? 'cli',
                     substr((string)($d['details'] ?? ''), 0, 400)]);
    } catch (Throwable $e) { /* le journal ne doit jamais bloquer le site */ }
}

function out($data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, max-age=0');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function body(): array {
    $raw = file_get_contents('php://input');
    $j = json_decode($raw, true);
    return is_array($j) ? $j : $_POST;
}
function setting(string $k, $def = null) {
    $r = db()->prepare("SELECT v FROM settings WHERE k=?"); $r->execute([$k]);
    $v = $r->fetchColumn(); return $v === false ? $def : $v;
}
function set_setting(string $k, $v): void {
    db()->prepare("DELETE FROM settings WHERE k=?")->execute([$k]);
    db()->prepare("INSERT INTO settings(k,v) VALUES(?,?)")->execute([$k, (string)$v]);
}

/* ---------- Nettoyage / validation ---------- */
function clean_text($s, int $max = 160): string {
    $s = trim(strip_tags((string)$s));
    $s = preg_replace('/\s+/u', ' ', $s) ?? $s;
    return mb_substr($s, 0, $max);
}
function clean_multiline($s, int $max = 2000): string {
    $s = trim(strip_tags((string)$s));
    $s = preg_replace("/\r\n?/", "\n", $s) ?? $s;
    $s = preg_replace('/[ \t]+/u', ' ', $s) ?? $s;
    return mb_substr($s, 0, $max);
}
function valid_email(?string $e): bool { return !$e || filter_var($e, FILTER_VALIDATE_EMAIL) !== false; }

/** Normalise un numéro camerounais -> 2376XXXXXXXX */
function norm_phone(string $p): string {
    $p = preg_replace('/\D/', '', $p);
    if (str_starts_with($p, '00237')) $p = substr($p, 2);
    if (strlen($p) === 9) $p = '237' . $p;
    return $p;
}
function valid_phone(string $p): bool { return (bool)preg_match('/^2376\d{8}$/', norm_phone($p)); }
function format_phone(string $p): string {
    $p = norm_phone($p);
    if (strlen($p) !== 12) return $p;
    return '+237 ' . substr($p, 3, 1) . substr($p, 4, 2) . ' ' . substr($p, 6, 2) . ' ' . substr($p, 8, 2) . ' ' . substr($p, 10, 2);
}

/* ---------- CSRF ---------- */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_valid(?string $t): bool {
    return is_string($t) && $t !== '' && !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $t);
}
function csrf_header(): ?string {
    return $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf'] ?? null);
}

/* ---------- Limitation de débit (anti-spam / force brute) ---------- */
function rate_limit(string $key, int $max, int $window): void {
    $pdo = db(); $ip = $_SERVER['REMOTE_ADDR'] ?? 'cli'; $k = $key . '|' . $ip; $now = time();
    try {
        $pdo->prepare("DELETE FROM rate_limits WHERE ts < ?")->execute([$now - $window]);
        $s = $pdo->prepare("SELECT COUNT(*) FROM rate_limits WHERE k=? AND ts>=?"); $s->execute([$k, $now - $window]);
        if ((int)$s->fetchColumn() >= $max) out(['error' => 'Trop de tentatives. Patientez quelques minutes avant de réessayer.'], 429);
        $pdo->prepare("INSERT INTO rate_limits(k,ts) VALUES(?,?)")->execute([$k, $now]);
    } catch (Throwable $e) { /* ne jamais bloquer le site si la table est indisponible */ }
}

/* ---------- Admin ---------- */
function admin_password_ok(string $pass): bool {
    $hash = (string)setting('admin_password_hash', '');
    if ($hash !== '' && password_verify($pass, $hash)) return true;
    $cfgHash = (string)(cfg()['admin_password_hash'] ?? '');
    if ($cfgHash !== '' && password_verify($pass, $cfgHash)) return true;
    $plain = (string)(cfg()['admin_password'] ?? '');
    return $plain !== '' && hash_equals($plain, $pass);
}
function is_admin(): bool {
    if (empty($_SESSION['admin'])) return false;
    $hours = (int)(cfg()['security']['session_hours'] ?? 3);
    if ($hours > 0 && !empty($_SESSION['admin_time']) && (time() - (int)$_SESSION['admin_time']) > $hours * 3600) {
        $_SESSION = []; @session_destroy(); return false;
    }
    return true;
}
function require_admin(): void {
    if (!is_admin()) out(['error' => 'Accès refusé. Reconnectez-vous.'], 401);
}

/* ---------- Formations ---------- */
function formations_all(bool $activeOnly = false): array {
    $sql = "SELECT * FROM formations" . ($activeOnly ? " WHERE active=1" : "") . " ORDER BY sort ASC, id ASC";
    return db()->query($sql)->fetchAll();
}
function formation_by_code(string $code): ?array {
    $s = db()->prepare("SELECT * FROM formations WHERE code=?"); $s->execute([$code]);
    $r = $s->fetch(); return $r ?: null;
}
function formation_price_label(array $f): string {
    return (int)$f['price'] > 0 ? number_format((int)$f['price'], 0, ',', ' ') . ' FCFA' : (($f['price_note'] ?? '') ?: 'Nous consulter');
}

/* ---------- Lieux locaux (repli hors-ligne / anti rate-limit) ---------- */
function local_places(): array {
    static $p = null;
    if ($p === null) {
        $file = __DIR__ . '/places.php';
        $p = is_file($file) ? require $file : [];
    }
    return $p;
}
function normalize_text(string $s): string {
    $s = mb_strtolower(trim($s), 'UTF-8');
    $s = strtr($s, ['à'=>'a','á'=>'a','â'=>'a','ä'=>'a','ã'=>'a','å'=>'a','ç'=>'c','è'=>'e','é'=>'e','ê'=>'e','ë'=>'e','ì'=>'i','í'=>'i','î'=>'i','ï'=>'i','ñ'=>'n','ò'=>'o','ó'=>'o','ô'=>'o','ö'=>'o','õ'=>'o','ù'=>'u','ú'=>'u','û'=>'u','ü'=>'u','ý'=>'y','ÿ'=>'y','œ'=>'oe','æ'=>'ae','ß'=>'ss']);
    $s = preg_replace('/[^a-z0-9]+/', ' ', $s) ?? $s;
    return trim(preg_replace('/\s+/', ' ', $s) ?? $s);
}
function haversine_m(float $lat1, float $lng1, float $lat2, float $lng2): float {
    $r = 6371000; $p1 = deg2rad($lat1); $p2 = deg2rad($lat2);
    $dp = deg2rad($lat2 - $lat1); $dl = deg2rad($lng2 - $lng1);
    $a = sin($dp / 2) ** 2 + cos($p1) * cos($p2) * sin($dl / 2) ** 2;
    return 2 * $r * asin(min(1, sqrt($a)));
}

/** Recherche locale : instantanée, fonctionne même si Nominatim/Photon sont indisponibles. */
function local_geocode(string $q, int $limit = 8): array {
    $q = normalize_text($q);
    if ($q === '') return [];
    $tokens = array_values(array_filter(explode(' ', $q), fn($t) => mb_strlen($t) >= 2));
    $res = [];
    foreach (local_places() as $p) {
        $name = normalize_text($p['name']);
        $label = normalize_text($p['label'] ?? $p['name']);
        $aliases = array_map('normalize_text', $p['aliases'] ?? []);
        $score = 0;
        if ($name === $q) $score = 120;
        elseif (str_starts_with($name, $q)) $score = 100;
        elseif (str_contains($name, $q)) $score = 82;
        elseif ($q !== '' && str_contains($label, $q)) $score = 62;
        else {
            $hay = $name . ' ' . $label . ' ' . implode(' ', $aliases);
            $hit = 0;
            foreach ($tokens as $t) if (str_contains($hay, $t)) $hit++;
            if ($hit > 0) $score = 45 + $hit * 6;
        }
        foreach ($aliases as $al) {
            if ($al !== '' && $al === $q) $score = max($score, 118);
            elseif ($al !== '' && $q !== '' && str_contains($al, $q)) $score = max($score, 70);
        }
        if ($score > 0) $res[] = [
            'label' => $p['label'] ?? $p['name'],
            'name'  => $p['name'],
            'lat'   => (float)$p['lat'],
            'lng'   => (float)$p['lng'],
            'type'  => $p['type'] ?? 'lieu',
            'source'=> 'local',
            '_score'=> $score,
        ];
    }
    usort($res, fn($a, $b) => $b['_score'] <=> $a['_score']);
    $res = array_slice($res, 0, $limit);
    foreach ($res as &$r) unset($r['_score']);
    return $res;
}

function geocache_get(string $key, int $maxAge = 2592000): ?array {
    try {
        $s = db()->prepare("SELECT json, ts FROM geocache WHERE k=?"); $s->execute([$key]);
        $r = $s->fetch();
        if ($r && (time() - (int)$r['ts']) < $maxAge) {
            $j = json_decode((string)$r['json'], true);
            return is_array($j) ? $j : null;
        }
    } catch (Throwable $e) { /* cache facultatif */ }
    return null;
}
function geocache_set(string $key, array $value): void {
    try {
        $json = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $db = db();
        $db->prepare("DELETE FROM geocache WHERE k=?")->execute([$key]);
        $db->prepare("INSERT INTO geocache(k,json,ts) VALUES(?,?,?)")->execute([$key, $json, time()]);
    } catch (Throwable $e) { /* ignore */ }
}

/** Recherche en ligne : cache + Nominatim + Photon, filtrée sur le Grand Yaoundé. */
function online_geocode(string $q): array {
    $q = trim($q);
    if (mb_strlen($q) < 3) return [];
    $cacheKey = 'geo:' . normalize_text($q);
    if ($cached = geocache_get($cacheKey)) return $cached;
    $out = [];
    $cfg = cfg();
    $ua = 'Y4I-Academy/2.0 (' . ($cfg['app_url'] ?? '') . '; ' . ($cfg['map']['email'] ?? '') . ')';
    $viewbox = '11.35,4.06,11.72,3.68';

    $r = http('GET', 'https://nominatim.openstreetmap.org/search?' . http_build_query([
        'format' => 'jsonv2', 'limit' => 10, 'countrycodes' => 'cm', 'bounded' => 1,
        'viewbox' => $viewbox, 'q' => $q . ' Yaoundé', 'addressdetails' => 0,
    ]), ['User-Agent: ' . $ua, 'Accept-Language: fr', 'Accept: application/json'], null, 12);
    foreach (($r['json'] ?? []) as $x) {
        if (!isset($x['lat'], $x['lon'])) continue;
        $lat = (float)$x['lat']; $lng = (float)$x['lon'];
        if ($lat < 3.60 || $lat > 4.12 || $lng < 11.28 || $lng > 11.80) continue;
        $out[] = ['label' => $x['display_name'] ?? $q, 'lat' => $lat, 'lng' => $lng, 'source' => 'nominatim'];
    }

    if (count($out) < 3) {
        $p = http('GET', 'https://photon.komoot.io/api/?' . http_build_query([
            'q' => $q, 'lat' => 3.8667, 'lon' => 11.5167, 'limit' => 10, 'lang' => 'fr',
        ]), ['User-Agent: ' . $ua, 'Accept: application/json'], null, 12);
        foreach (($p['json']['features'] ?? []) as $f) {
            $c = $f['geometry']['coordinates'] ?? null; $pr = $f['properties'] ?? [];
            if (!$c) continue; $lng = (float)$c[0]; $lat = (float)$c[1];
            if ($lat < 3.60 || $lat > 4.12 || $lng < 11.28 || $lng > 11.80) continue;
            $parts = array_filter([$pr['name'] ?? '', $pr['street'] ?? '', $pr['city'] ?? 'Yaoundé', $pr['country'] ?? 'Cameroun']);
            $out[] = ['label' => implode(', ', $parts), 'lat' => $lat, 'lng' => $lng, 'source' => 'photon'];
        }
    }

    // Dédoublonnage par position arrondie
    $seen = []; $clean = [];
    foreach ($out as $x) {
        $k = round($x['lat'], 4) . ',' . round($x['lng'], 4);
        if (isset($seen[$k])) continue; $seen[$k] = 1; $clean[] = $x;
        if (count($clean) >= 10) break;
    }
    if ($clean) geocache_set($cacheKey, $clean);
    return $clean;
}

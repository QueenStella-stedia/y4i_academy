<?php
require_once __DIR__ . '/lib.php';

function public_head(string $title, string $description, string $canonical = '', string $extraHead = ''): void {
    $co = company_info();
    ?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($title) ?> — Y4I Academy</title>
<meta name="description" content="<?= h($description) ?>">
<meta name="theme-color" content="#0C2B4E">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Y4I Academy">
<meta property="og:title" content="<?= h($title) ?>">
<meta property="og:description" content="<?= h($description) ?>">
<meta property="og:url" content="<?= h(abs_url($canonical)) ?>">
<meta property="og:image" content="<?= h(abs_url('assets/img/photos/og-cover.jpg')) ?>">
<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<link rel="canonical" href="<?= h(abs_url($canonical)) ?>">
<link rel="icon" href="<?= h(abs_url('assets/img/logo-mark.png')) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,700;1,600;1,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="<?= h(abs_url('assets/css/style.css?v=' . (int)@filemtime(__DIR__ . '/assets/css/style.css'))) ?>">
<?= $extraHead ?>
</head>
<body>
<div class="infobar"><div class="wrap"><span><i class="fas fa-location-dot"></i> <?= h($co['address']) ?></span><span class="info-links"><a href="tel:+<?= h(cfg()['phone_secondary'] ?? '') ?>"><i class="fas fa-phone"></i> +237 622 142 496</a><a href="https://wa.me/<?= h(cfg()['whatsapp']) ?>" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i> WhatsApp</a></span></div></div>
<header class="site"><div class="wrap bar">
  <a href="<?= h(abs_url('index.php')) ?>" class="brand"><span class="mark"><img src="<?= h(abs_url('assets/img/logo-mark.png')) ?>" alt="Logo Y4I Academy" decoding="async"></span><span class="brand-t">Y4I Academy<small>Se former aujourd'hui, soigner demain !</small></span></a>
  <nav id="nav">
    <a class="nav-link" href="<?= h(abs_url('index.php#formations')) ?>">Formations</a>
    <a class="nav-link" href="<?= h(abs_url('index.php#services')) ?>">Services</a>
    <a class="nav-link" href="<?= h(abs_url('index.php#suivi')) ?>">Carte & suivi</a>
    
    <a class="btn btn-primary nav-cta" href="<?= h(abs_url('index.php#inscription')) ?>">S'inscrire <i class="fas fa-arrow-right"></i></a>
  </nav>
</div></header>
<?php
}

function public_footer(): void {
    $co = company_info();
    ?>
<footer><div class="wrap foot">
  <div class="brand"><span class="mark"><img src="<?= h(abs_url('assets/img/logo-mark.png')) ?>" alt="" decoding="async"></span><span class="brand-t">Y4I Academy<small>Se former aujourd'hui, soigner demain !</small></span></div>
  <div class="foot-links"><a href="<?= h(abs_url('index.php#formations')) ?>">Formations</a><a href="<?= h(abs_url('index.php#services')) ?>">Services</a><a href="<?= h(abs_url('index.php#inscription')) ?>">S'inscrire</a></div>
  <div class="avail"><small>DISPONIBLES</small><b><?= h($co['hours']) ?></b><span><?= h($co['address']) ?></span></div>
</div><div class="wrap legal"><span>© <?= date('Y') ?> <?= h($co['name']) ?> — Tous droits réservés.</span><span>Site sécurisé · Paiements Mobile Money</span></div></footer>
<a class="whatsapp-float" href="https://wa.me/<?= h(cfg()['whatsapp']) ?>?text=Bonjour,%20je%20souhaite%20des%20informations." target="_blank" rel="noopener" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
<div class="mobile-cta" aria-label="Actions rapides">
  <a href="tel:+<?= h(cfg()['phone_secondary'] ?? '') ?>"><i class="fas fa-phone"></i><span>Appeler</span></a>
  <a href="https://wa.me/<?= h(cfg()['whatsapp']) ?>" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i><span>WhatsApp</span></a>
  <a href="<?= h(abs_url('index.php#inscription')) ?>" class="mcta-main"><i class="fas fa-user-plus"></i><span>S'inscrire</span></a>
</div>
</body>
</html>
<?php
}

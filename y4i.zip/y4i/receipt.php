<?php
require_once __DIR__ . '/inc_public.php';
$co = company_info();
$id = (int)($_GET['id'] ?? 0);
$token = (string)($_GET['token'] ?? '');
$p = null;
if ($id > 0 && $token !== '') {
    $s = db()->prepare("SELECT p.*, a.name, a.email, a.contact FROM payments p LEFT JOIN accounts a ON a.id=p.account_id WHERE p.id=? AND p.token=?");
    $s->execute([$id, $token]);
    $p = $s->fetch() ?: null;
}
if (!$p) {
    http_response_code(404);
    public_head('Reçu introuvable', 'Ce reçu n’existe pas ou le lien a expiré.', 'receipt.php');
    echo '<main class="page-main"><div class="wrap"><div class="legal-body"><h2>Reçu introuvable</h2><p>Vérifiez le lien reçu par e-mail ou contactez l’administration avec votre référence de transaction.</p><p><a class="btn btn-primary" href="' . h(abs_url('index.php')) . '">Retour au site</a></p></div></div></main>';
    public_footer();
    exit;
}
$status = (string)$p['status'];
$labels = ['SUCCESS' => 'Confirmé · fonds bloqué', 'PENDING' => 'En attente', 'FAILED' => 'Échoué', 'REFUNDED' => 'Remboursé'];
public_head('Reçu ' . $p['reference'], 'Reçu du fonds de garantie Y4I Academy.', 'receipt.php?id=' . $id . '&token=' . urlencode($token));
?>
<main class="page-main"><div class="receipt">
  <div class="rc-head">
    <div><h1>Reçu de fonds de garantie</h1><p class="hint"><?= h($co['name']) ?> · <?= h($co['address']) ?></p></div>
    <div style="text-align:right"><b><?= h((string)$p['reference']) ?></b><br><small><?= h(date('d/m/Y H:i', (int)$p['created_ts'] ?: strtotime((string)$p['created_at']))) ?></small></div>
  </div>
  <table>
    <tr><th>Titulaire</th><td><?= h((string)($p['name'] ?: '—')) ?></td></tr>
    <tr><th>Téléphone</th><td><?= h(mask_phone((string)$p['phone'])) ?></td></tr>
    <tr><th>Passerelle</th><td><?= h($p['gateway'] === 'sim' ? 'Simulation' : (string)$p['gateway']) ?></td></tr>
    <tr><th>Montant</th><td><b><?= number_format((int)$p['amount'], 0, ',', ' ') ?> FCFA</b></td></tr>
    <tr><th>Statut</th><td><?= h($labels[$status] ?? $status) ?></td></tr>
    <tr><th>Référence opérateur</th><td><?= h((string)($p['external_ref'] ?: '—')) ?></td></tr>
  </table>
  <?php if ($status === 'SUCCESS'): ?><p><span class="stamp">FONDS BLOQUÉ</span></p><?php endif; ?>
  <p class="hint">Ce reçu atteste l'enregistrement du fonds de garantie. Il ne constitue pas une facture de prestation. La restitution intervient après clôture du compte et validation par l'administration.</p>
  <div class="row no-print" style="margin-top:1.2rem">
    <button class="btn btn-primary" onclick="window.print()"><i class="fas fa-print"></i> Imprimer / PDF</button>
    <a class="btn btn-ghost" href="<?= h(abs_url('index.php')) ?>">Retour au site</a>
  </div>
</div></main>
<?php public_footer(); ?>

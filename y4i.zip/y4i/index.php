<?php
require_once __DIR__ . '/lib.php';
$T = []; foreach (db()->query("SELECT * FROM tariffs") as $r) $T[$r['k']] = $r;
$formations = formations_all(true);
$formByTitle = array_column($formations, 'code', 'title');
$wa = cfg()['whatsapp'];
$phone2 = cfg()['phone_secondary'] ?? $wa;
$minG = max(1000, (int)setting('min_guarantee', 5000));
$places = local_places();
$csrf = csrf_token();
function fcfa($n) { return number_format((int)$n, 0, ',', ' ') . ' FCFA'; }
function fprice(array $f): string { return formation_price_label($f); }
function ftags(array $f, int $n = 3): array { $m = array_values(array_filter(array_map('trim', explode(';', (string)$f['modules'])))); return array_slice($m, 0, $n); }
$services = [
  'formation' => ['fa-graduation-cap', 'Formations professionnelles', 'Des parcours encadrés dans le domaine de la santé, pensés pour acquérir des compétences concrètes et rejoindre durablement le monde professionnel.', array_map(fn($f) => $f['title'], $formations)],
  'aide'    => ['fa-hand-holding-heart', 'Aide à domicile', 'Un soutien adapté aux gestes du quotidien, avec une présence attentive qui respecte le rythme de chacun.', ['Auxiliaires de vie', 'Toilette & repas', 'Présence quotidienne']],
  'hopital' => ['fa-hospital', 'Accompagnement à l\'hôpital', 'Une présence rassurante lors des hospitalisations, rendez-vous, examens ou sorties d\'établissement.', ['Rendez-vous', 'Visites', 'Retour à domicile']],
  'kine'    => ['fa-user-doctor', 'Kinésithérapie & soins', 'Séances de rééducation et de bien-être à domicile, selon les besoins et l\'orientation médicale.', ['Rééducation', 'Mobilité', 'Professionnels qualifiés']],
  'courses' => ['fa-basket-shopping', 'Courses & quotidien', 'Marché, pharmacie, petites démarches : nous nous en occupons, pour que la maison reste un lieu simple à vivre.', ['Courses', 'Pharmacie', 'Petites commissions']],
];
$slides = [
  ['formation-hero', 'Des formations professionnelles dans la santé'],
  ['formation-soin-infirmier', 'Soin infirmier'],
  ['photo-hospital', 'Accompagnement à l\'hôpital'],
  ['formation-laboratoire', 'Laboratoire'],
  ['photo-home', 'Aide à domicile'],
];
$groups = ['quartier' => 'Quartiers de Yaoundé', 'arrondissement' => 'Arrondissements', 'sante' => 'Santé & hôpitaux', 'marche' => 'Marchés', 'education' => 'Écoles & universités', 'carrefour' => 'Carrefours & ronds-points', 'transport' => 'Gares & aéroports', 'lieu' => 'Lieux publics'];
$byType = [];
foreach ($places as $p) $byType[$p['type'] ?? 'lieu'][] = $p;
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Y4I Academy — Formations santé, aide à domicile et accompagnement à Yaoundé</title>
<meta name="description" content="Y4I Academy à Odza (Yaoundé) : formations professionnelles en santé (auxiliaire de vie, soin infirmier, kinésithérapie, laboratoire, auxiliaire de pharmacie), aide à domicile, accompagnement hospitalier et suivi sur carte.">
<meta name="theme-color" content="#0C2B4E">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Y4I Academy">
<meta property="og:title" content="Y4I Academy — Se former aujourd'hui, soigner demain">
<meta property="og:description" content="Formations professionnelles dans le domaine de la santé à Yaoundé. Aide à domicile et accompagnement hospitalier avec intervenants garantis.">
<meta property="og:url" content="<?= h(abs_url('')) ?>/">
<meta property="og:image" content="<?= h(abs_url('assets/img/photos/og-cover.jpg')) ?>">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:locale" content="fr_FR">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Y4I Academy — Se former aujourd'hui, soigner demain">
<meta name="twitter:description" content="Formations santé, aide à domicile et accompagnement hospitalier à Yaoundé.">
<meta name="twitter:image" content="<?= h(abs_url('assets/img/photos/og-cover.jpg')) ?>">
<link rel="canonical" href="<?= h(abs_url('')) ?>/">
<link rel="icon" href="assets/img/logo-mark.png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,700;1,600;1,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<link rel="stylesheet" href="assets/css/style.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/style.css') ?>">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  "name": "Y4I Academy",
  "slogan": "Se former aujourd'hui, soigner demain !",
  "description": "Centre de formation professionnelle dans le domaine de la santé et services d'accompagnement à Yaoundé.",
  "address": {"@type": "PostalAddress", "streetAddress": "Odza, en face du dispensaire", "addressLocality": "Yaoundé", "addressCountry": "CM"},
  "telephone": "+237622142496",
  "areaServed": "Yaoundé",
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "Formations santé",
    "itemListElement": [<?php foreach ($formations as $i => $f): ?>{ "@type": "Course", "name": <?= json_encode($f['title']) ?>, "description": <?= json_encode($f['short']) ?>, "provider": {"@type": "Organization", "name": "Y4I Academy"} }<?= $i < count($formations) - 1 ? ',' : '' ?><?php endforeach; ?>]
  }
}
</script>
</head>
<body>
<a class="skip-link" href="#accueil">Aller au contenu principal</a>
<div class="infobar"><div class="wrap"><span><i class="fas fa-location-dot"></i> Odza, Yaoundé (face dispensaire) · Formations & services 24h/24 – 7j/7</span><span class="info-links"><a href="tel:+<?= h($phone2) ?>"><i class="fas fa-phone"></i> +237 622 142 496</a><a href="https://wa.me/<?= h($wa) ?>" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i> +237 696 500 949</a></span></div></div>
<header class="site"><div class="wrap bar">
  <a href="#accueil" class="brand"><span class="mark"><img src="assets/img/logo-mark.png" alt="Logo Y4I Academy" decoding="async"></span><span class="brand-t">Y4I Academy<small>Votre avenir commence ici…</small></span></a>
  <button class="burger" id="burger" aria-label="Ouvrir le menu" aria-expanded="false"><i class="fas fa-bars"></i></button>
  <nav id="nav">
    <a class="nav-link active" href="#accueil">Accueil</a>
    <a class="nav-link" href="#formations">Formations</a>
    <a class="nav-link" href="#services">Services</a>
    <a class="nav-link" href="#suivi">Carte & suivi</a>
    <a class="nav-link" href="#inscription">Créer un compte</a>
    <a class="nav-link" href="#contact">Nous contacter</a>
    <a class="nav-link lock" href="#admin" aria-label="Administration"><i class="fas fa-lock"></i></a>
    <a class="btn btn-primary nav-cta" href="#inscription">S'inscrire <i class="fas fa-arrow-right"></i></a>
  </nav>
</div></header>

<!-- ACCUEIL -->
<section id="accueil" class="page-section active">
  <div class="hero"><div class="wrap hero-grid">
    <div class="hero-text reveal">
      <span class="kicker"><i></i> Centre de formation & services de santé · Odza, Yaoundé</span>
      <h1>Se former <em>aujourd'hui</em>, soigner demain.</h1>
      <p class="lead">Y4I Academy forme les professionnels de la santé de demain et accompagne les familles au quotidien. Des parcours pratiques, un encadrement sérieux, des intervenants vérifiés et un suivi transparent sur la carte de Yaoundé.</p>
      <div class="cta"><a class="btn btn-primary btn-lg" href="#formations">Découvrir les formations <i class="fas fa-arrow-right"></i></a><a class="link" href="#services">Voir nos services <i class="fas fa-arrow-right"></i></a></div>
      <div class="hero-proof"><span><i class="fas fa-circle-check"></i> 5 parcours santé</span><span><i class="fas fa-shield-halved"></i> Fonds de garantie</span><span><i class="fas fa-location-crosshairs"></i> Suivi sur carte</span></div>
    </div>
    <div class="hero-visual reveal">
      <div class="slideshow" id="slideshow">
        <?php foreach ($slides as $i => $s): ?><figure class="slide<?= $i === 0 ? ' active-slide' : '' ?>"><img src="assets/img/photos/<?= h($s[0]) ?>.jpg" alt="<?= h($s[1]) ?>"<?= $i ? ' loading="lazy"' : '' ?> decoding="async"><figcaption><?= h($s[1]) ?></figcaption></figure><?php endforeach; ?>
        <div class="dots" id="dots"></div>
      </div>
      <div class="float-badge"><i class="fas fa-graduation-cap"></i><span><b>Formations certifiantes</b>théorie + stage pratique</span></div>
    </div>
  </div></div>

  <div class="wrap stats reveal">
    <div><b><?= count($formations) ?> parcours</b><span>Dans le domaine de la santé, à Yaoundé</span></div>
    <div><b>Fonds de garantie</b><span>Chaque prestataire bloque une somme sécurisée</span></div>
    <div><b>Carte & suivi</b><span>Recherche, itinéraire, durée et position en direct</span></div>
  </div>

  <div class="wrap callback reveal">
    <div class="callback-txt"><i class="fas fa-phone-volume"></i><div><b>Vous préférez qu'on vous rappelle ?</b><span>Laissez votre nom et votre numéro : nous vous rappelons rapidement, sans engagement.</span></div></div>
    <form id="callbackForm" class="callback-form" novalidate>
      <input type="text" id="cbWebsite" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
      <input id="cbName" placeholder="Votre nom *" autocomplete="name" required>
      <input id="cbPhone" placeholder="Téléphone *" inputmode="tel" autocomplete="tel" required>
      <select id="cbNeed" aria-label="Sujet du rappel"><option value="Rappel">Être rappelé</option><option value="Formation">Formation</option><option value="Aide à domicile">Aide à domicile</option><option value="Accompagnement hôpital">Accompagnement hôpital</option><option value="Devis">Devis</option></select>
      <button class="btn btn-red" type="submit"><i class="fas fa-phone"></i> Rappelez-moi</button>
      <p class="hint" id="callbackResult" aria-live="polite"></p>
    </form>
  </div>

  <div class="formation-ribbon reveal">
    <div class="wrap"><span class="ribbon-label"><i class="fas fa-star"></i> Nos parcours</span>
      <?php foreach ($formations as $f): ?><button class="ribbon-item" onclick="openFormation('<?= h($f['code']) ?>')"><b><?= h($f['code']) ?></b><?= h($f['title']) ?></button><?php endforeach; ?>
    </div>
  </div>

  <div class="band mint"><div class="wrap">
    <div class="head reveal"><span class="kicker red"><i></i> Une démarche claire</span><h2>De la première demande au <em>bon accompagnement.</em></h2><p>Que vous veniez pour vous former ou pour trouver une aide, nous avançons étape par étape pour construire une réponse adaptée à votre situation.</p></div>
    <div class="steps3">
      <div class="reveal"><small>01</small><i class="dotline"></i><h3>Vous racontez votre besoin</h3><p>Une demande simple suffit : une formation, une aide à domicile, un accompagnement à l'hôpital ou un service ponctuel.</p></div>
      <div class="reveal"><small>02</small><i class="dotline"></i><h3>Nous organisons</h3><p>Nous choisissons le parcours ou l'intervenant adapté, avec un itinéraire clair et une durée indicative.</p></div>
      <div class="reveal"><small>03</small><i class="dotline"></i><h3>Vous êtes accompagné</h3><p>Écoute, coordination et suivi en direct sur la carte jusqu'à la fin de la formation ou de l'intervention.</p></div>
    </div>
    <p class="note"><i class="fas fa-stethoscope"></i> Les interventions de kinésithérapie sont organisées avec des professionnels qualifiés, selon les besoins et l'orientation médicale lorsqu'elle est nécessaire.</p>
  </div></div>

  <div class="split">
    <div class="split-img"><img src="assets/img/photos/photo-hospital.jpg" alt="Un intervenant accompagne une patiente à l'hôpital" loading="lazy" decoding="async"></div>
    <div class="split-txt reveal"><span class="kicker light"><i></i> L'hôpital autrement</span>
      <h2>Parce qu'un proche ne devrait jamais traverser l'hôpital <em>seul.</em></h2>
      <p>Nos intervenants vous accompagnent lors des consultations, des hospitalisations, des visites et du retour à domicile. Une présence qui aide aussi les proches à souffler.</p>
      <a class="btn btn-light" href="#contact">Parler de mon besoin <i class="fas fa-arrow-right"></i></a></div>
  </div>

  <div class="wrap pad about-grid">
    <div class="about-img reveal"><img src="assets/img/photos/photo-about.jpg" alt="Encadrement des apprenants Y4I Academy" loading="lazy" decoding="async"><div class="about-badge"><b>Y4I</b><span>Votre partenaire pour un meilleur avenir</span></div></div>
    <div class="about-txt reveal"><span class="kicker red"><i></i> Pourquoi Y4I Academy</span><h2>Une école de proximité, <em>tournée vers le terrain.</em></h2>
      <p>Installée à Odza, face au dispensaire, Y4I Academy accompagne ses apprenants avec une pédagogie concrète : cours, mises en situation, stages et suivi individualisé. Notre objectif est simple : des compétences utiles, une posture professionnelle et une vraie confiance en soi.</p>
      <ul class="checklist"><li><i class="fas fa-check"></i> Encadrement par des professionnels du secteur</li><li><i class="fas fa-check"></i> Formation pratique et stages en structure</li><li><i class="fas fa-check"></i> Accompagnement administratif et orientation</li><li><i class="fas fa-check"></i> Paiement Mobile Money sécurisé</li></ul>
      <a class="btn btn-red" href="#formations">Voir les formations <i class="fas fa-arrow-right"></i></a>
    </div>
  </div>

  <div class="wrap pad">
    <div class="head reveal"><span class="kicker red"><i></i> Confiance & sécurité</span><h2>Des intervenants <em>engagés</em>, un cadre clair.</h2></div>
    <div class="cards3">
      <a class="trust-card reveal" href="#inscription" aria-label="Fonds de garantie : en savoir plus et s'inscrire"><i class="fas fa-lock"></i><h3>Fonds de garantie</h3><p>Chaque prestataire dépose une garantie par Mobile Money. Elle reste bloquée pendant son activité et lui est restituée à la fin.</p><span class="trust-more">En savoir plus <i class="fas fa-arrow-right"></i></span></a>
      <a class="trust-card reveal" href="#inscription" aria-label="Paiement simple : en savoir plus et s'inscrire"><i class="fas fa-mobile-screen"></i><h3>Paiement simple</h3><p>Orange Money et MTN MoMo : vous confirmez avec votre code secret directement sur votre téléphone.</p><span class="trust-more">En savoir plus <i class="fas fa-arrow-right"></i></span></a>
      <a class="trust-card reveal" href="#suivi" aria-label="Suivi en direct : voir la carte et le suivi"><i class="fas fa-route"></i><h3>Suivi en direct</h3><p>La position de l'intervenant n'est partagée que pendant la prestation, avec itinéraire et heure d'arrivée estimée.</p><span class="trust-more">Voir la carte <i class="fas fa-arrow-right"></i></span></a>
    </div>
  </div>

    <?php
      $testimonials = [];
      try { $testimonials = db()->query("SELECT id,name,role,message,rating FROM testimonials WHERE published=1 ORDER BY id DESC LIMIT 9")->fetchAll(); } catch (Throwable $e) {}
    ?>
  <?php if ($testimonials): ?>
  <div class="wrap pad">
    <div class="head split2 reveal"><div><span class="kicker red"><i></i> Ils nous font confiance</span><h2>Des mots qui <em>rassurent.</em></h2></div><p>Les témoignages publiés depuis l'administration apparaissent ici. Ils sont affichés avec le prénom et le service concerné.</p></div>
    <div class="testimonials" id="testimonialsList">
      <?php if ($testimonials): foreach ($testimonials as $t): ?>
      <figure class="testimonial reveal">
        <div class="tm-stars" aria-label="<?= (int)$t['rating'] ?> étoiles sur 5"><?php for ($i = 0; $i < 5; $i++): ?><i class="fas fa-star<?= $i < (int)$t['rating'] ? '' : ' off' ?>"></i><?php endfor; ?></div>
        <blockquote><?= nl2br(h($t['message'])) ?></blockquote>
        <figcaption><b><?= h($t['name']) ?></b><span><?= h($t['role'] ?: 'Client Y4I Academy') ?></span></figcaption>
      </figure>
      <?php endforeach; endif; ?>
    </div>
  </div>
  <?php endif; ?>

  <div class="band mint"><div class="wrap narrow2">
    <div class="head reveal"><h2>Questions <em>fréquentes</em></h2></div>
    <details class="faq reveal"><summary>Comment se déroulent les formations ?</summary><p>Chaque parcours combine des cours théoriques, des mises en situation pratiques et un stage encadré. Les durées et prérequis sont indiqués sur la fiche de chaque formation. Contactez-nous pour le calendrier de la prochaine rentrée.</p></details>
    <details class="faq reveal"><summary>Comment fonctionne le fonds de garantie ?</summary><p>À l'inscription, le prestataire choisit un montant (minimum fixé par l'administration) et le règle par Mobile Money. La somme est bloquée et lui est remboursée à la clôture de son compte.</p></details>
    <details class="faq reveal"><summary>Comment payer avec Orange Money ou MTN MoMo ?</summary><p>Vous saisissez votre numéro, puis un message arrive sur votre téléphone. Vous tapez votre code secret sur le téléphone pour confirmer. Aucun code n'est demandé sur le site.</p></details>
    <details class="faq reveal"><summary>Dans quelles zones intervenez-vous ?</summary><p>Partout à Yaoundé, avec une permanence à Odza (face dispensaire). La carte affiche la distance et la durée du trajet ; le tarif de la prestation est confirmé avec vous selon le service demandé.</p></details>
    <details class="faq reveal"><summary>Puis-je suivre l'arrivée de l'intervenant ?</summary><p>Oui. Après votre demande, un code de suivi vous permet de voir sa position en direct sur la carte, uniquement pendant la prestation.</p></details>
  </div></div>

  <div class="wrap pad"><div class="ctaband reveal"><div><h2>Besoin d'une aide <em>aujourd'hui</em> ?</h2><p>Notre permanence répond 24h/24 à Odza.</p></div><a class="btn btn-red btn-lg" href="#contact">Demander de l'aide <i class="fas fa-arrow-right"></i></a></div></div>
</section>

<!-- FORMATIONS -->
<section id="formations" class="page-section"><div class="wrap pad">
  <div class="head split2 reveal"><div><span class="kicker red"><i></i> Nos formations</span><h2>Des métiers qui <em>prennent soin.</em></h2></div><p>Cinq parcours professionnalisants dans le domaine de la santé. Choisissez une fiche pour découvrir le programme, les prérequis et les débouchés.</p></div>

  <div class="formation-showcase">
    <div class="poster-wrap reveal">
      <figure class="poster" id="formationPoster">
        <img src="assets/img/photos/flyer-formations.jpg?v=<?= (int)@filemtime(__DIR__ . '/assets/img/photos/flyer-formations.jpg') ?>" alt="Affiche officielle des formations Y4I Academy : auxiliaire de vie, soin infirmier, kinésithérapie, laboratoire, auxiliaire de pharmacie" decoding="async">
        <figcaption><i class="fas fa-graduation-cap"></i> Affiche officielle Y4I Academy</figcaption>
      </figure>
      <p class="hint center">Cliquez sur une formation de la liste pour voir le programme complet.</p>
    </div>
    <div class="formation-list reveal">
      <span class="kicker red"><i></i> Choisissez votre parcours</span>
      <?php foreach ($formations as $f): ?>
      <button class="formation-line" onclick="openFormation('<?= h($f['code']) ?>')">
        <span class="fl-code"><?= h($f['code']) ?></span>
        <span class="fl-main"><b><?= h($f['title']) ?></b><small><?= h($f['duration']) ?> · <?= h($f['certification']) ?></small></span>
        <span class="fl-arrow"><i class="fas fa-arrow-right"></i></span>
      </button>
      <?php endforeach; ?>
      <div class="formation-note"><i class="fas fa-info-circle"></i> Les places sont limitées. Contactez l'administration pour connaître la prochaine rentrée et les modalités de paiement.</div>
      <a class="btn btn-primary wide" href="#inscription">Je souhaite m'inscrire <i class="fas fa-arrow-right"></i></a>
    </div>
  </div>

  <div class="formation-cards">
    <?php foreach ($formations as $f): ?>
    <article class="formation-card reveal" data-code="<?= h($f['code']) ?>">
      <div class="fc-media"><img src="assets/img/photos/<?= h($f['image']) ?>" alt="<?= h($f['title']) ?>" loading="lazy" decoding="async"><span class="fc-code"><?= h($f['code']) ?></span><span class="fc-duration"><i class="fas fa-clock"></i> <?= h($f['duration']) ?></span></div>
      <div class="fc-body"><h3><?= h($f['title']) ?></h3><p><?= h($f['short']) ?></p>
        <ul class="fc-modules"><?php foreach (ftags($f, 3) as $m): ?><li><i class="fas fa-check"></i> <?= h($m) ?></li><?php endforeach; ?></ul>
        <div class="fc-foot"><span class="fc-price"><?= h(fprice($f)) ?></span><div class="row"><button class="btn btn-ghost small" onclick="openFormation('<?= h($f['code']) ?>')">Aperçu</button><a class="btn btn-primary small" href="formation.php?slug=<?= h($f['slug']) ?>">Fiche complète</a></div></div>
      </div>
    </article>
    <?php endforeach; ?>
  </div>

  <div class="devis reveal"><i class="fas fa-file-signature"></i><div><h3>Une question sur une formation ?</h3><p>Programme détaillé, prérequis, calendrier, frais de formation : écrivez-nous ou passez à Odza, en face du dispensaire. Nous vous répondons avec un accompagnement clair, sans engagement.</p></div><a class="btn btn-red" href="#contact">Nous écrire <i class="fas fa-arrow-right"></i></a></div>
</div></section>

<!-- SERVICES -->
<section id="services" class="page-section"><div class="wrap pad">
  <div class="head split2 reveal"><div><span class="kicker red"><i></i> Nos services</span><h2>Un même objectif : <em>vous soulager.</em></h2></div><p>Chaque intervention s'inscrit dans une logique simple : préserver l'autonomie, faciliter l'organisation et apporter une présence humaine qui compte vraiment.</p></div>
  <div class="svc-grid">
    <?php $n = 0; foreach ($services as $k => $s): $n++; ?>
    <article class="service-card reveal<?= $k === 'formation' ? ' service-formation' : '' ?>" data-key="<?= h($k) ?>">
      <small class="num">0<?= $n ?></small>
      <div class="svc-body"><div class="svc-top"><span class="ico c<?= $n ?>"><i class="fas <?= h($s[0]) ?>"></i></span><h3><?= h($s[1]) ?></h3><button class="go" onclick="<?= $k === 'formation' ? "navigateToSection('#formations')" : "selectService('" . h($k) . "')" ?>" aria-label="<?= $k === 'formation' ? 'Voir les formations' : 'Demander : ' . h($s[1]) ?>"><i class="fas fa-arrow-right"></i></button></div>
        <p><?= h($s[2]) ?></p>
        <div class="tags"><?php foreach ($s[3] as $tag): if ($k === 'formation'): ?><button type="button" class="tag-btn" onclick="openFormation('<?= h($formByTitle[$tag] ?? '') ?>')"><?= h($tag) ?></button><?php else: ?><button type="button" class="tag-btn subservice" onclick="selectSubservice('<?= h($k) ?>', <?= h(json_encode($tag, JSON_UNESCAPED_UNICODE)) ?>)" title="Demander : <?= h($tag) ?>"><?= h($tag) ?></button><?php endif; endforeach; ?></div>
        <p class="service-price"><?php if ($k === 'formation'): ?><i class="fas fa-layer-group"></i> <?= count($formations) ?> parcours · <?php $prices = array_filter(array_map(fn($f) => (int)$f['price'], $formations)); echo $prices ? 'dès ' . fcfa(min($prices)) : 'Tarif sur devis'; ?><?php elseif ((int)($T[$k]['price'] ?? 0) > 0): ?><i class="fas fa-tag"></i> Dès <span><?= fcfa($T[$k]['price']) ?></span> / <?= h($T[$k]['unit']) ?><?php else: ?><i class="fas fa-circle-info"></i> Tarif sur devis · selon les heures et les tâches<?php endif; ?></p>
        <?php if ($k !== 'formation'): ?><a class="svc-more" href="service.php?service=<?= h($k) ?>">Page dédiée <i class="fas fa-arrow-right"></i></a><?php endif; ?>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
  <div class="devis reveal"><i class="fas fa-file-invoice"></i><div><h3>Un tarif adapté à votre besoin</h3><p>Le prix dépend du service demandé, du nombre d'heures, des tâches à réaliser et du lieu d'intervention. Décrivez-nous votre besoin : nous vous répondons avec un devis clair, sans engagement.</p></div><a class="btn btn-red" href="#contact">Demander un devis <i class="fas fa-arrow-right"></i></a></div>
</div></section>

<!-- CARTE & SUIVI -->
<section id="suivi" class="page-section"><div class="wrap pad">
  <div class="head split2 reveal"><div><span class="kicker red"><i></i> Carte de Yaoundé</span><h2>Un trajet clair, un suivi <em>réel.</em></h2></div><p>Indiquez le départ et la destination : la distance, la durée et l'heure d'arrivée s'affichent. Pendant la prestation, le client et l'administration peuvent suivre la position de l'intervenant en direct.</p></div>
  <div class="map-layout">
    <aside class="map-panel">
      <div class="field"><label for="fromInput">Départ</label><div class="ac"><input id="fromInput" placeholder="Quartier, hôpital, rue…" autocomplete="off"><ul class="ac-list" id="fromList"></ul></div></div>
      <div class="field"><label for="toInput">Destination</label><div class="ac"><input id="toInput" placeholder="Quartier, hôpital, rue…" autocomplete="off"><ul class="ac-list" id="toList"></ul></div></div>
      <div class="row"><button type="button" class="btn btn-primary small" id="btnRoute"><i class="fas fa-route"></i> Calculer l'itinéraire</button><button type="button" class="btn btn-ghost small" id="btnLocate"><i class="fas fa-crosshairs"></i> Ma position</button><button type="button" class="btn btn-ghost small" id="btnSwap" title="Inverser le départ et la destination"><i class="fas fa-arrow-right-arrow-left"></i></button><button type="button" class="btn btn-ghost small" id="btnClear">Effacer</button></div>
      <div class="chips" id="chips"></div>
      <p class="hint" id="mapNotice" aria-live="polite">Cliquez sur la carte pour placer le départ, puis la destination. Vous pouvez aussi taper un quartier (Odza, Melen, Bastos…).</p>
      <div id="routeBox" hidden>
        <div id="routeTabs" class="tabs"></div>
        <div class="estimate"><div><small>Distance</small><b id="estDist">–</b></div><div><small>Durée</small><b id="estTime">–</b></div><div><small>Arrivée prévue</small><b id="estEta">–</b></div></div>
        <details class="req"><summary>Voir le détail de l'itinéraire</summary><ol id="steps" class="steps"></ol></details>
        <details class="req" open><summary>Envoyer cette demande</summary>
          <p class="hint">Un code de suivi sera généré pour partager la position de l'intervenant avec le client concerné.</p>
          <select id="reqService"></select>
          <input id="reqName" placeholder="Votre nom" autocomplete="name">
          <input id="reqPhone" placeholder="Téléphone / WhatsApp" inputmode="tel" autocomplete="tel">
          <input id="reqDetails" placeholder="Précisions (facultatif)">
          <button type="button" class="btn btn-primary" id="btnRequest">Valider la demande</button><div id="reqResult" aria-live="polite"></div></details>
      </div>
      <details class="req" id="followBox"><summary>Suivre un intervenant en direct</summary>
        <p class="hint">Client : saisissez le code de suivi reçu après votre demande. La position ne s'affiche que pendant la prestation.</p>
        <input id="followCode" placeholder="Code de suivi (ex : A1B2C3)" maxlength="6" autocomplete="off">
        <div class="row"><button type="button" class="btn btn-primary small" id="btnFollow">Suivre</button><button type="button" class="btn btn-ghost small" id="btnStopFollow" hidden>Arrêter</button></div>
        <p id="followState" class="hint" aria-live="polite"></p>
        <hr>
        <p class="hint"><b>Intervenant :</b> saisissez le code et la clé reçus, puis partagez votre position. Gardez la page ouverte pendant l'intervention.</p>
        <input id="pushKey" placeholder="Clé intervenant" autocomplete="off">
        <button type="button" class="btn btn-ghost small" id="btnPush">Partager ma position</button></details>
    </aside>
    <div id="yaoundeRealMap" class="map"></div>
  </div>
</div></section>

<!-- INSCRIPTION -->
<section id="inscription" class="page-section"><div class="wrap pad">
  <div class="head reveal"><span class="kicker red"><i></i> Créer un compte</span><h2>Rejoignez Y4I Academy, <em>simplement.</em></h2><p>Client ou prestataire, choisissez votre profil. Les champs marqués d'un <b>*</b> sont obligatoires.</p></div>
  <div class="reg-grid">
    <aside class="dark-card reveal"><i class="fas fa-shield-halved"></i><h3>Un cadre sécurisé.</h3>
      <p>Les prestataires déposent un fonds de garantie bloqué par Mobile Money. Le code secret se saisit uniquement sur le téléphone, jamais sur le site.</p>
      <ul><li><i class="fas fa-mobile-screen"></i> Orange Money · MTN MoMo</li><li><i class="fas fa-lock"></i> Fonds bloqué et remboursable</li><li><i class="fas fa-user-check"></i> Compte actif dès le paiement confirmé</li><li><i class="fas fa-graduation-cap"></i> Formation facultative, à votre rythme</li></ul>
      <div class="guarantee-mini"><small>Fonds de garantie minimum</small><b><?= fcfa($minG) ?></b><span>Remboursable après clôture du compte</span></div>
    </aside>
    <div class="card-offset reveal">
      <form id="registerForm" novalidate enctype="multipart/form-data">
        <input type="text" id="regWebsite" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
        <div class="field"><label for="regName">Nom complet *</label><input id="regName" required autocomplete="name"></div>
        <div class="two"><div class="field"><label for="regContact">Téléphone / WhatsApp *</label><input id="regContact" required placeholder="+237 6XX XXX XXX" inputmode="tel" autocomplete="tel"></div>
        <div class="field"><label for="regEmail">E-mail</label><input id="regEmail" type="email" placeholder="vous@exemple.com" autocomplete="email"></div></div>
        <div class="two"><div class="field"><label for="regLocation">Quartier *</label><input id="regLocation" required placeholder="Ex : Odza, Melen, Bastos…" autocomplete="address-level2"></div>
        <div class="field"><label for="regZone">Zone d'intervention</label><input id="regZone" placeholder="Yaoundé et environs"></div></div>
        <div class="field"><label for="regType">Type de compte *</label><select id="regType"><option value="client">Client (demandeur de service / futur apprenant)</option><option value="prestataire">Prestataire (intervenant / formateur)</option></select></div>

        <div class="formation-block">
          <div class="formation-block-head"><i class="fas fa-graduation-cap"></i><div><b>Formation <span class="opt-badge">Facultatif</span></b><small>Vous pouvez créer un compte sans choisir de formation. Si vous en choisissez une, son code et vos précisions sont enregistrés avec votre dossier.</small></div></div>
          <div class="field"><label for="regFormation">Formation souhaitée</label><select id="regFormation"><option value="">— Aucune formation pour le moment —</option><?php foreach ($formations as $f): ?><option value="<?= h($f['code']) ?>"><?= h($f['code']) ?> — <?= h($f['title']) ?></option><?php endforeach; ?><option value="AUTRE">AUTRE — Autre demande (précisez ci-dessous)</option></select></div>
          <div class="two"><div class="field"><label for="regFormationCode">Code formation</label><input id="regFormationCode" readonly placeholder="Aucun code sélectionné"></div>
          <div class="field"><label for="regFormationSpec">Précisions sur la formation</label><textarea id="regFormationSpec" rows="3" placeholder="Facultatif : objectifs, modules ou précisions…"></textarea></div></div>
        </div>

        <div id="clientFields">
          <div class="field"><label for="regPaymentMethod">Mode de paiement préféré</label><select id="regPaymentMethod"><option>Orange Money</option><option>MTN Mobile Money</option><option>Espèces sur place</option></select></div>
          <div class="field"><label for="regMessage">Votre message</label><textarea id="regMessage" rows="3" placeholder="Précisez votre besoin (facultatif)…"></textarea></div>
        </div>

        <div id="prestataireFields" hidden>
          <div class="field"><label for="regServiceDescription">Description de la prestation *</label><textarea id="regServiceDescription" rows="4" placeholder="Décrivez la prestation pour laquelle vous vous enregistrez : ce que vous savez faire, votre expérience, vos disponibilités…"></textarea><small class="hint">20 caractères minimum. Cette description sera visible par l'administration.</small></div>
          <div class="two"><div class="field"><label for="regExperience">Expérience</label><select id="regExperience"><option value="">— Choisir —</option><option>Débutant</option><option>1 à 3 ans</option><option>3 à 5 ans</option><option>Plus de 5 ans</option></select></div>
          <div class="field"><label for="regGateway">Paiement du fonds de garantie</label><select id="regGateway"><option value="campay">Campay — Orange Money & MTN MoMo</option><option value="orange">Orange Money (page sécurisée Orange)</option><option value="mtn">MTN MoMo (demande sur le téléphone)</option></select></div></div>
          <div class="two"><div class="field"><label for="regPhone">Numéro Mobile Money à débiter *</label><input id="regPhone" inputmode="tel" placeholder="6XX XXX XXX"></div>
          <div class="field"><label for="regAmount">Fonds de garantie (FCFA) *</label><input type="number" id="regAmount" min="<?= $minG ?>" step="1" value="<?= $minG ?>"><small id="minG" class="hint">Minimum : <?= fcfa($minG) ?></small></div></div>

          <div class="field"><label for="regReferences">Références professionnelles <span class="opt-badge">Facultatif</span></label><textarea id="regReferences" rows="2" placeholder="Ex : structure, nom et téléphone d'une personne de référence (facultatif)"></textarea></div>

          <p class="secure"><i class="fas fa-shield-halved"></i> Vous ne saisissez jamais votre code secret ici : il se compose uniquement sur votre téléphone quand l'opérateur vous le demande.</p>
        </div>

        <label class="check-line"><input type="checkbox" id="regTerms" required> <span>J'accepte que mes informations soient utilisées pour traiter ma demande et je certifie l'exactitude des renseignements fournis. *</span></label>
        <button class="btn btn-primary wide" type="submit" id="regSubmit">Créer mon compte</button>
      </form>
      <div id="payBox" class="paybox" hidden><div class="phone"><i class="fas fa-mobile-screen-button"></i><div><b id="payTitle">Vérifiez votre téléphone</b><p id="payText"></p></div></div><div class="spinner" id="paySpin"></div><p id="payMeta" class="hint"></p></div>
      <div id="registrationSuccess" class="result ok" hidden><i class="fas fa-circle-check"></i><h3>Votre dossier est bien reçu.</h3><p id="successDetails"></p><div id="successReceipt"></div><button class="btn btn-ghost" id="btnNewRegistration">Nouvelle inscription</button></div>
      <div id="registrationError" class="result ko" hidden><i class="fas fa-triangle-exclamation"></i><h3>Inscription non aboutie</h3><p id="errorDetails"></p><button class="btn btn-red" id="btnRetryRegistration">Réessayer</button></div>
    </div>
  </div>
</div></section>

<!-- CONTACT -->
<section id="contact" class="page-section dark"><div class="wrap contact">
  <div class="contact-info reveal"><span class="kicker light"><i></i> Parlons de votre situation</span>
    <h2>Organisons l'aide ou la formation qui vous <em class="gold">ressemble.</em></h2>
    <p>Décrivez-nous votre besoin : une formation, une aide ponctuelle, une présence régulière, un accompagnement à l'hôpital ou une organisation plus globale.</p>
    <p class="cl"><i class="fas fa-location-dot"></i> Odza, en face du dispensaire — Yaoundé</p>
    <p class="cl"><i class="fab fa-whatsapp"></i> WhatsApp : +237 696 500 949 · Tél. : +237 622 142 496</p>
    <p class="cl"><i class="fas fa-clock"></i> Disponibles 24h/24 · 7j/7</p></div>
  <form id="contactForm" class="card-offset reveal" novalidate>
    <input type="text" id="cWebsite" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
    <div class="two"><div class="field"><label for="cName">Votre nom *</label><input id="cName" required placeholder="Votre nom" autocomplete="name"></div><div class="field"><label for="cPhone">Téléphone / WhatsApp *</label><input id="cPhone" required placeholder="+237 6 XX XX XX XX" inputmode="tel" autocomplete="tel"></div></div>
    <div class="field"><label for="cEmail">E-mail</label><input id="cEmail" type="email" placeholder="vous@exemple.com" autocomplete="email"></div>
    <div class="field"><label for="cNeed">Votre besoin</label><select id="cNeed"><optgroup label="Formations"><?php foreach ($formations as $f): ?><option value="<?= h($f['code']) ?>">Formation — <?= h($f['title']) ?></option><?php endforeach; ?></optgroup><optgroup label="Services"><?php foreach ($services as $k => $s): if ($k === 'formation') continue; ?><option value="<?= h($k) ?>"><?= h($s[1]) ?></option><?php endforeach; ?></optgroup></select></div>
    <div class="field"><label for="cMsg">Quartier & précisions *</label><textarea id="cMsg" rows="4" required placeholder="Expliquez-nous simplement ce dont vous avez besoin…"></textarea></div>
    <button class="btn btn-red wide" type="submit" id="cSubmit"><i class="fab fa-whatsapp"></i> Envoyer ma demande</button>
    <p class="hint" id="contactResult" aria-live="polite">Votre demande est enregistrée sur le site, puis WhatsApp s'ouvre avec le message prérempli.</p>
  </form>
</div></section>

<!-- ADMIN -->
<section id="admin" class="page-section"><div class="wrap pad">
  <div id="adminLogin" class="card-offset narrow2 center"><i class="fas fa-lock big"></i><h3>Accès administrateur</h3>
    <div class="field"><input type="password" id="adminPasswordInput" placeholder="Mot de passe" autocomplete="current-password"></div>
    <button class="btn btn-primary wide" id="btnAdminLogin">Se connecter</button><p id="adminLoginError" class="err" hidden>Mot de passe incorrect.</p>
    <p class="hint">Connexion limitée contre les tentatives répétées. Pensez à changer le mot de passe par défaut.</p></div>
  <div id="adminDashboard" hidden>
    <div class="row between admin-head"><div><span class="kicker red"><i></i> Administration</span><h2>Tableau de <em>bord</em></h2></div><div class="row"><a class="btn btn-ghost small" href="export.php?type=accounts"><i class="fas fa-file-csv"></i> Comptes</a><a class="btn btn-ghost small" href="export.php?type=payments"><i class="fas fa-file-csv"></i> Paiements</a><a class="btn btn-ghost small" href="export.php?type=messages"><i class="fas fa-file-csv"></i> Messages</a><a class="btn btn-ghost small" href="export.php?type=journal"><i class="fas fa-file-csv"></i> Journal</a><button class="btn btn-ghost small" id="btnLockAdmin"><i class="fas fa-lock"></i> Verrouiller</button></div></div>
    <div class="admin-stats" id="adminStats"></div>

    <div class="card"><h3><i class="fas fa-graduation-cap"></i> Formations (prix, statut, contenu)</h3><p class="hint">Ces informations alimentent la page Formations, l'inscription et le flyer interactif. Laissez le prix à 0 pour afficher « Nous consulter ».</p>
      <div class="scroll"><table><thead><tr><th>Code</th><th>Titre</th><th>Durée</th><th>Prix (FCFA)</th><th>Actif</th></tr></thead><tbody id="formationsAdminBody"></tbody></table></div>
      <button class="btn btn-primary" id="btnSaveFormations"><i class="fas fa-save"></i> Enregistrer les formations</button><span id="formationsSaveStatus" class="okmsg" hidden>Formations mises à jour.</span></div>

    <div class="card"><h3><i class="fas fa-tags"></i> Tarifs et barème</h3><p class="hint">Les prix sont facultatifs : laissez <b>0</b> pour afficher « Tarif sur devis » sur le site. Dès qu'un prix est saisi, il apparaît sur la page Services.</p><div class="grid4" id="tariffInputs"></div>
      <div class="grid4"><div class="field"><label>Garantie min. (FCFA)</label><input type="number" id="adminMinGuarantee"></div></div>
      <button class="btn btn-primary" id="btnSaveTariffs"><i class="fas fa-save"></i> Enregistrer</button><span id="tariffSaveStatus" class="okmsg" hidden>Tarifs mis à jour sur tout le site.</span></div>

    <div class="card"><h3><i class="fas fa-users"></i> Comptes et fonds bloqués</h3><div class="scroll"><table><thead><tr><th>Nom</th><th>Contact</th><th>Quartier</th><th>Type</th><th>Formation</th><th>Prestation</th><th>Garantie</th><th>Statut</th><th>Actions</th></tr></thead><tbody id="accountsTableBody"></tbody></table></div></div>


    <div class="card"><h3><i class="fas fa-comment-dots"></i> Témoignages publiés</h3><p class="hint">Ces avis apparaissent sur la page d'accueil. Utilisez des exemples tant que vous n'avez pas de vrais témoignages, puis remplacez-les.</p>
      <div class="grid4"><div class="field"><label>Nom / prénom *</label><input id="tmName" maxlength="120" placeholder="Ex : Marie N."></div><div class="field"><label>Rôle / service</label><input id="tmRole" maxlength="120" placeholder="Ex : Apprenante auxiliaire de vie"></div><div class="field"><label>Note (1 à 5)</label><select id="tmRating"><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select></div><div class="field"><label>Publié</label><select id="tmPublished"><option value="1">Oui</option><option value="0">Non</option></select></div></div>
      <div class="field"><label>Témoignage *</label><textarea id="tmMessage" rows="3" maxlength="1200" placeholder="Décrivez l'expérience…"></textarea></div>
      <input type="hidden" id="tmId" value="0">
      <div class="row"><button class="btn btn-primary" id="btnSaveTestimonial"><i class="fas fa-save"></i> Enregistrer le témoignage</button><button class="btn btn-ghost small" id="btnResetTestimonial">Nouveau</button></div>
      <div class="scroll" style="margin-top:1rem"><table><thead><tr><th>Date</th><th>Nom</th><th>Rôle</th><th>Avis</th><th>Note</th><th>Publié</th><th>Actions</th></tr></thead><tbody id="testimonialsBody"></tbody></table></div>
    </div>

    <div class="card"><h3><i class="fas fa-envelope-open-text"></i> Messages reçus</h3><p class="hint">Les messages du formulaire de contact sont conservés ici, même si WhatsApp est utilisé ensuite.</p><div class="scroll"><table><thead><tr><th>Date</th><th>Nom</th><th>Contact</th><th>Besoin</th><th>Message</th><th>Statut</th><th></th></tr></thead><tbody id="messagesBody"></tbody></table></div></div>

    <div class="card"><h3><i class="fas fa-receipt"></i> Transactions</h3><p class="hint">Chaque paiement effectué sur le site est enregistré et conservé, même si le compte est ensuite supprimé. « simulation » = aucun opérateur branché ; une passerelle en mode test ne débite aucun argent réel.</p>
      <div class="scroll"><table><thead><tr><th>Date</th><th>Compte</th><th>Montant</th><th>Passerelle</th><th>Téléphone</th><th>Référence</th><th>Statut</th></tr></thead><tbody id="paymentsBody"></tbody></table></div></div>

    <div class="card"><div class="row between" style="margin:0 0 .6rem"><h3 style="margin:0"><i class="fas fa-clipboard-list"></i> Journal d'activité</h3><a class="btn btn-ghost small" href="export.php?type=journal"><i class="fas fa-file-csv"></i> Exporter (CSV)</a></div>
      <p class="hint">Historique permanent et non modifiable depuis le site : créations, suppressions et blocages de comptes, paiements, remboursements, changements de tarifs, connexions admin (avec adresse IP). Les 400 derniers événements sont affichés ; l'export contient tout.</p>
      <div class="scroll"><table><thead><tr><th>Date</th><th>Événement</th><th>Compte</th><th>Montant</th><th>Passerelle · Réf.</th><th>Statut</th><th>IP</th><th>Détails</th></tr></thead><tbody id="logBody"></tbody></table></div></div>

    <div class="card"><h3><i class="fas fa-satellite-dish"></i> Suivi en direct des interventions</h3><p class="hint">Positions partagées par les intervenants via leur téléphone. La carte et le tableau se mettent à jour automatiquement toutes les 15 secondes. Le client concerné peut suivre la même position avec le code de suivi.</p><div id="adminTrackMap" class="map map-admin"></div><div class="scroll"><table><thead><tr><th>Code</th><th>Client</th><th>Service</th><th>Dernière position</th><th>Mise à jour</th><th>Statut</th></tr></thead><tbody id="trackingBody"></tbody></table></div><p class="hint" id="trackingEmpty" hidden>Aucune position partagée pour le moment.</p></div>

    <div class="card"><h3><i class="fas fa-credit-card"></i> Passerelles de paiement</h3><p class="hint">Campay est utilisé en priorité pour le fonds de garantie. Les identifiants se renseignent dans <code>config.php</code> (section <b>campay</b>) : <i>username</i> et <i>password</i>. Sans identifiants, le site reste en mode simulation.</p><div id="gatewayStatus" class="gateway-status"></div></div>

    <div class="card"><h3><i class="fas fa-route"></i> Dernières demandes</h3><div class="scroll"><table><thead><tr><th>Code</th><th>Client</th><th>Service</th><th>Trajet</th><th>Date</th></tr></thead><tbody id="requestsBody"></tbody></table></div></div>

    <div class="card"><h3><i class="fas fa-key"></i> Sécurité du compte admin</h3><p class="hint">Changez le mot de passe par défaut. Il est stocké sous forme de hash et n'est plus jamais affiché en clair.</p>
      <div class="grid4"><div class="field"><label>Mot de passe actuel</label><input type="password" id="adminCurrentPassword" autocomplete="current-password"></div><div class="field"><label>Nouveau mot de passe</label><input type="password" id="adminNewPassword" autocomplete="new-password" placeholder="10 caractères minimum"></div><div class="field"><label>Confirmer</label><input type="password" id="adminConfirmPassword" autocomplete="new-password"></div></div>
      <button class="btn btn-primary" id="btnChangePassword"><i class="fas fa-key"></i> Changer le mot de passe</button><span id="passwordStatus" class="okmsg" hidden>Mot de passe modifié.</span></div>
  </div>
</div></section>

<!-- MODAL FORMATION -->
<div class="modal" id="formationModal" hidden role="dialog" aria-modal="true" aria-labelledby="formationModalTitle">
  <div class="modal-backdrop" onclick="closeFormation()"></div>
  <div class="modal-card" role="document">
    <button class="modal-close" onclick="closeFormation()" aria-label="Fermer">×</button>
    <div id="formationModalContent"></div>
  </div>
</div>

<div class="toast-wrap" id="toastWrap" aria-live="polite"></div>

<footer><div class="wrap foot">
  <div class="brand"><span class="mark"><img src="assets/img/logo-mark.png" alt="" decoding="async"></span><span class="brand-t">Y4I Academy<small>Se former aujourd'hui, soigner demain !</small></span></div>
  <div class="foot-links"><a href="#formations">Formations</a><a href="#services">Services</a><a href="#suivi">Carte & suivi</a><a href="#inscription">S'inscrire</a><a href="#contact">Contact</a></div>
  <div class="avail"><small>DISPONIBLES</small><b>24h/24 · 7j/7</b><span>Odza, Yaoundé · Cameroun</span></div>
  <a href="#accueil" class="totop">Haut de page <i class="fas fa-arrow-up"></i></a>
</div><div class="wrap legal"><span>© <?= date('Y') ?> Y4I Academy — Tous droits réservés.</span><span>Odza, face au dispensaire · Yaoundé, Cameroun</span><span>Site sécurisé · Paiements Mobile Money</span></div></footer>
<a class="whatsapp-float" href="https://wa.me/<?= h($wa) ?>?text=Bonjour,%20je%20souhaite%20des%20informations%20sur%20vos%20formations%20et%20services." target="_blank" rel="noopener" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>

<div class="mobile-cta" aria-label="Actions rapides">
  <a href="tel:+<?= h($phone2) ?>"><i class="fas fa-phone"></i><span>Appeler</span></a>
  <a href="https://wa.me/<?= h($wa) ?>" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i><span>WhatsApp</span></a>
  <a href="#inscription" class="mcta-main"><i class="fas fa-user-plus"></i><span>S'inscrire</span></a>
</div>

<div class="cookie-banner" id="cookieBanner" hidden>
  <p>Nous utilisons des mesures d'audience pour améliorer le site. Vous pouvez accepter ou refuser.</p>
  <div class="row"><button class="btn btn-ghost small" id="cookieRefuse">Refuser</button><button class="btn btn-primary small" id="cookieAccept">Accepter</button></div>
</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>window.Y4I = { csrf: <?= json_encode($csrf) ?>, whatsapp: <?= json_encode($wa) ?>, phone: <?= json_encode($phone2) ?>, places: <?= json_encode($places, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>, analytics: <?= json_encode(cfg()['analytics'] ?? [], JSON_UNESCAPED_SLASHES) ?> };</script>
<script src="assets/js/app.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/app.js') ?>"></script>
</body>
</html>

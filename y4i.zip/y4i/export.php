<?php
require_once __DIR__ . '/lib.php';

if (!is_admin()) {
    http_response_code(401);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Accès refusé. Connectez-vous à l'administration puis réessayez.";
    exit;
}

$type = (string)($_GET['type'] ?? 'accounts');
$db = db();
$date = date('Ymd-His');
$o = null;

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="y4i-' . preg_replace('/[^a-z_]/', '', $type) . '-' . $date . '.csv"');
header('X-Robots-Tag: noindex, nofollow');
$o = fopen('php://output', 'w');
fwrite($o, "\xEF\xBB\xBF");

switch ($type) {
    case 'journal':
        fputcsv($o, ['Date', 'Événement', 'Compte', 'Montant FCFA', 'Passerelle', 'Référence', 'Statut', 'Téléphone', 'IP', 'Détails'], ';');
        foreach ($db->query("SELECT * FROM activity_log ORDER BY id ASC") as $r) {
            fputcsv($o, [date('Y-m-d H:i:s', (int)$r['ts']), $r['event'], $r['account_name'], $r['amount'], $r['gateway'], $r['reference'], $r['status'], $r['phone'], $r['ip'], $r['details']], ';');
        }
        log_event('journal_exporte', ['details' => 'Export CSV via export.php']);
        break;

    case 'payments':
        fputcsv($o, ['Date', 'ID', 'Compte', 'Montant FCFA', 'Passerelle', 'Référence', 'Référence opérateur', 'Statut', 'Téléphone'], ';');
        foreach ($db->query("SELECT p.*, a.name FROM payments p LEFT JOIN accounts a ON a.id=p.account_id ORDER BY p.id ASC") as $r) {
            fputcsv($o, [date('Y-m-d H:i:s', (int)$r['created_ts']), $r['id'], $r['name'], $r['amount'], $r['gateway'], $r['reference'], $r['external_ref'], $r['status'], mask_phone($r['phone'])], ';');
        }
        log_event('paiements_exportes', ['details' => 'Export CSV via export.php']);
        break;

    case 'messages':
        fputcsv($o, ['Date', 'Nom', 'Téléphone', 'E-mail', 'Besoin', 'Message', 'Source', 'Statut'], ';');
        foreach ($db->query("SELECT * FROM messages ORDER BY id ASC") as $r) {
            fputcsv($o, [$r['created_at'], $r['name'], $r['phone'], $r['email'], $r['need'], $r['message'], $r['source'], $r['status']], ';');
        }
        log_event('messages_exportes', ['details' => 'Export CSV via export.php']);
        break;

    default:
        $type = 'accounts';
        fputcsv($o, ['ID', 'Nom', 'Contact', 'E-mail', 'Quartier', 'Type', 'Formation', 'Code formation', 'Description prestation', 'Références', 'Vérification', 'Statut', 'Création'], ';');
        foreach ($db->query("SELECT * FROM accounts ORDER BY id ASC") as $r) {
            fputcsv($o, [$r['id'], $r['name'], $r['contact'], $r['email'], $r['location'], $r['type'], $r['formation_label'], $r['formation_code'], $r['service_description'], $r['refs'], $r['verify_status'], $r['status'], $r['created_at']], ';');
        }
        log_event('comptes_exportes', ['details' => 'Export CSV via export.php']);
        break;
}
fclose($o);
exit;

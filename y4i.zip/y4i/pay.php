<?php
// Passerelles de paiement : Campay, MTN MoMo, Orange Money Web Pay (+ mode simulation)
require_once __DIR__ . '/lib.php';

function http(string $method, string $url, array $headers = [], $body = null, int $timeout = 30): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 3,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT      => 'Y4I-Academy/2.0 (+' . (cfg()['app_url'] ?? '') . ')',
    ]);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    return ['code' => $code, 'json' => json_decode((string)$res, true), 'raw' => $res, 'err' => $err];
}
function uuid4(): string {
    $d = random_bytes(16); $d[6] = chr(ord($d[6]) & 0x0f | 0x40); $d[8] = chr(ord($d[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($d), 4));
}
function gateway_ready(string $g): bool {
    $c = cfg();
    return match ($g) {
        'campay' => $c['campay']['username'] !== '' && $c['campay']['password'] !== '',
        'mtn'    => $c['mtn']['subscription_key'] !== '' && $c['mtn']['api_user'] !== '' && $c['mtn']['api_key'] !== '',
        'orange' => $c['orange']['auth_header'] !== '' && $c['orange']['merchant_key'] !== '',
        default  => false,
    };
}

/* ---------- CAMPAY ---------- */
function campay_token(bool $force = false): string {
    $c = cfg()['campay'];
    if (!$force) {
        $cached = json_decode((string)setting('campay_token', ''), true);
        // Le cache est lié au nom d'utilisateur : changer les identifiants dans config.php invalide l'ancien jeton.
        if (is_array($cached) && ($cached['exp'] ?? 0) > time() + 60 && !empty($cached['token'])
            && ($cached['username'] ?? '') === (string)$c['username']) {
            return $cached['token'];
        }
    }
    $r = http('POST', $c['base'] . '/token/', ['Content-Type: application/json'],
        json_encode(['username' => $c['username'], 'password' => $c['password']]));
    if (empty($r['json']['token'])) {
        $msg = $r['json']['message'] ?? $r['json']['detail'] ?? $r['err'] ?? ('HTTP ' . (int)$r['code']);
        throw new Exception('Campay : authentification refusée (' . $msg . '). Vérifiez username et password dans config.php.');
    }
    set_setting('campay_token', json_encode(['token' => $r['json']['token'], 'exp' => time() + 3000,
        'username' => (string)$c['username']]));
    return $r['json']['token'];
}
function campay_collect(string $phone, int $amount, string $ext, string $desc): array {
    $c = cfg()['campay'];
    $payload = json_encode(['amount' => (string)$amount, 'currency' => 'XAF', 'from' => $phone,
        'description' => $desc, 'external_reference' => $ext]);
    $r = http('POST', $c['base'] . '/collect/', ['Authorization: Token ' . campay_token(), 'Content-Type: application/json'], $payload);
    // Jeton expiré ou révoqué : on en redemande un une seule fois.
    if ((int)($r['code'] ?? 0) === 401) {
        $r = http('POST', $c['base'] . '/collect/', ['Authorization: Token ' . campay_token(true), 'Content-Type: application/json'], $payload);
    }
    if (empty($r['json']['reference'])) {
        $msg = $r['json']['message'] ?? $r['json']['detail'] ?? $r['raw'] ?: $r['err'];
        throw new Exception('Campay : ' . mb_substr((string)$msg, 0, 300));
    }
    return ['reference' => $r['json']['reference'], 'ussd_code' => $r['json']['ussd_code'] ?? null, 'operator' => $r['json']['operator'] ?? null];
}
function campay_status(string $ref): string {
    $c = cfg()['campay'];
    $r = http('GET', $c['base'] . '/transaction/' . urlencode($ref) . '/', ['Authorization: Token ' . campay_token()]);
    return match (strtoupper((string)($r['json']['status'] ?? 'PENDING'))) {
        'SUCCESSFUL', 'SUCCESS' => 'SUCCESS', 'FAILED', 'CANCELLED', 'EXPIRED' => 'FAILED', default => 'PENDING'
    };
}
function campay_withdraw(string $phone, int $amount, string $ext): bool {
    $c = cfg()['campay'];
    $r = http('POST', $c['base'] . '/withdraw/', ['Authorization: Token ' . campay_token(), 'Content-Type: application/json'],
        json_encode(['amount' => (string)$amount, 'to' => $phone, 'description' => 'Remboursement fonds de garantie Y4I', 'external_reference' => $ext]));
    return !empty($r['json']['reference']);
}

/* ---------- MTN MoMo ---------- */
function mtn_token(): string {
    $c = cfg()['mtn'];
    $r = http('POST', $c['base'] . '/collection/token/', [
        'Authorization: Basic ' . base64_encode($c['api_user'] . ':' . $c['api_key']),
        'Ocp-Apim-Subscription-Key: ' . $c['subscription_key'], 'Content-Length: 0']);
    if (empty($r['json']['access_token'])) throw new Exception('MTN MoMo : authentification refusée');
    return $r['json']['access_token'];
}
function mtn_collect(string $phone, int $amount, string $ext, string $desc): array {
    $c = cfg()['mtn']; $id = uuid4();
    $r = http('POST', $c['base'] . '/collection/v1_0/requesttopay', [
        'Authorization: Bearer ' . mtn_token(), 'X-Reference-Id: ' . $id, 'X-Target-Environment: ' . $c['environment'],
        'Ocp-Apim-Subscription-Key: ' . $c['subscription_key'], 'Content-Type: application/json'],
        json_encode(['amount' => (string)$amount, 'currency' => $c['currency'], 'externalId' => $ext,
                     'payer' => ['partyIdType' => 'MSISDN', 'partyId' => $phone],
                     'payerMessage' => $desc, 'payeeNote' => 'Y4I Academy']));
    if ($r['code'] !== 202) throw new Exception('MTN MoMo : refus (' . $r['code'] . ') ' . $r['raw']);
    return ['reference' => $id, 'ussd_code' => null, 'operator' => 'MTN'];
}
function mtn_status(string $id): string {
    $c = cfg()['mtn'];
    $r = http('GET', $c['base'] . '/collection/v1_0/requesttopay/' . $id, [
        'Authorization: Bearer ' . mtn_token(), 'X-Target-Environment: ' . $c['environment'],
        'Ocp-Apim-Subscription-Key: ' . $c['subscription_key']]);
    return match (strtoupper((string)($r['json']['status'] ?? 'PENDING'))) {
        'SUCCESSFUL', 'SUCCESS' => 'SUCCESS', 'FAILED', 'CANCELLED', 'EXPIRED' => 'FAILED', default => 'PENDING'
    };
}

/* ---------- ORANGE MONEY Web Pay (redirection vers la page Orange) ---------- */
function orange_token(): string {
    $c = cfg()['orange'];
    $r = http('POST', 'https://api.orange.com/oauth/v3/token', ['Authorization: ' . $c['auth_header'],
        'Content-Type: application/x-www-form-urlencoded', 'Accept: application/json'], 'grant_type=client_credentials');
    if (empty($r['json']['access_token'])) throw new Exception('Orange Money : authentification refusée');
    return $r['json']['access_token'];
}
function orange_collect(int $amount, string $orderId, string $desc): array {
    $c = cfg()['orange']; $u = rtrim(cfg()['app_url'], '/');
    $r = http('POST', $c['base'] . '/webpayment', ['Authorization: Bearer ' . orange_token(), 'Content-Type: application/json'],
        json_encode(['merchant_key' => $c['merchant_key'], 'currency' => $c['currency'], 'order_id' => $orderId,
            'amount' => $amount, 'return_url' => $u . '/?paiement=ok#inscription',
            'cancel_url' => $u . '/?paiement=annule#inscription',
            'notif_url' => $u . '/api.php?action=webhook_orange', 'lang' => 'fr', 'reference' => $desc]));
    if (empty($r['json']['payment_url'])) throw new Exception('Orange Money : ' . ($r['json']['message'] ?? $r['raw']));
    return ['reference' => $r['json']['pay_token'] ?? $orderId, 'pay_url' => $r['json']['payment_url'],
            'extra' => $r['json']['notif_token'] ?? '', 'ussd_code' => null, 'operator' => 'ORANGE'];
}
function orange_status(string $orderId, int $amount, string $payToken): string {
    $c = cfg()['orange'];
    $r = http('POST', $c['base'] . '/transactionstatus', ['Authorization: Bearer ' . orange_token(), 'Content-Type: application/json'],
        json_encode(['order_id' => $orderId, 'amount' => $amount, 'pay_token' => $payToken]));
    return match (strtoupper((string)($r['json']['status'] ?? 'PENDING'))) {
        'SUCCESS' => 'SUCCESS', 'FAILED', 'EXPIRED', 'CANCELLED' => 'FAILED', default => 'PENDING'
    };
}

/** sim = aucune clé ; test = environnement de démonstration (aucun argent réel) ; live = production */
function gateway_mode(string $g): string {
    if (!gateway_ready($g)) return 'sim';
    $base = (string)(cfg()[$g]['base'] ?? '');
    return preg_match('#demo|sandbox|/dev/#i', $base) ? 'test' : 'live';
}

/* ---------- Orchestration ---------- */
function start_payment(int $accountId, string $gateway, string $phone, int $amount): array {
    $db = db();
    $ext = 'Y4I-' . $accountId . '-' . time() . '-' . bin2hex(random_bytes(3));
    $token = bin2hex(random_bytes(24));
    $live = gateway_ready($gateway);
    $res = ['reference' => 'SIM-' . $ext, 'ussd_code' => null, 'pay_url' => null, 'extra' => '', 'operator' => 'SIMULATION'];
    if ($live) {
        $desc = 'Fonds de garantie Y4I Academy';
        $res = array_merge($res, match ($gateway) {
            'campay' => campay_collect($phone, $amount, $ext, $desc),
            'mtn'    => mtn_collect($phone, $amount, $ext, $desc),
            'orange' => orange_collect($amount, $ext, $desc),
        });
    }
    $db->prepare("INSERT INTO payments(account_id,gateway,reference,external_ref,amount,phone,ussd_code,pay_url,extra,token,created_ts) VALUES(?,?,?,?,?,?,?,?,?,?,?)")
       ->execute([$accountId, $live ? $gateway : 'sim', $res['reference'], $ext, $amount, $phone, $res['ussd_code'], $res['pay_url'] ?? null, $res['extra'] ?? '', $token, time()]);
    $pid = (int)$db->lastInsertId();
    log_event('paiement_initie', ['account_id' => $accountId, 'account_name' => account_name($accountId), 'amount' => $amount, 'gateway' => $live ? $gateway : 'sim',
        'reference' => $res['reference'], 'status' => 'PENDING', 'phone' => $phone, 'details' => 'mode=' . ($live ? gateway_mode($gateway) : 'sim')]);
    return ['payment_id' => $pid, 'payment_token' => $token, 'live' => $live, 'mode' => $live ? gateway_mode($gateway) : 'sim', 'operator' => $res['operator'],
            'ussd_code' => $res['ussd_code'], 'pay_url' => $res['pay_url'] ?? null];
}

/** Interroge l'opérateur (jamais de confiance aveugle aux webhooks) puis met à jour la base. */
function refresh_payment(int $paymentId): array {
    $db = db();
    $s = $db->prepare("SELECT * FROM payments WHERE id=?"); $s->execute([$paymentId]);
    $p = $s->fetch();
    if (!$p) return ['status' => 'NOTFOUND'];
    if ($p['status'] === 'PENDING') {
        try {
            $st = match ($p['gateway']) {
                'campay' => campay_status($p['reference']),
                'mtn'    => mtn_status($p['reference']),
                'orange' => orange_status($p['external_ref'], (int)$p['amount'], $p['reference']),
                default  => (time() - (int)$p['created_ts'] >= 8) ? 'SUCCESS' : 'PENDING', // simulation
            };
        } catch (Throwable $e) { $st = 'PENDING'; }
        if ($st !== 'PENDING') {
            $db->prepare("UPDATE payments SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?")->execute([$st, $paymentId]);
            $db->prepare("UPDATE accounts SET status=? WHERE id=?")->execute([$st === 'SUCCESS' ? 'Actif' : 'Paiement échoué', $p['account_id']]);
            $p['status'] = $st;
            $nm = account_name((int)$p['account_id']);
            log_event($st === 'SUCCESS' ? 'paiement_confirme' : 'paiement_echoue', ['account_id' => $p['account_id'], 'account_name' => $nm, 'amount' => $p['amount'],
                'gateway' => $p['gateway'], 'reference' => $p['reference'], 'status' => $st, 'phone' => $p['phone'],
                'details' => $nm === null ? 'ATTENTION : compte introuvable (supprimé)' : '']);
            if ($st === 'SUCCESS') {
                try { send_payment_receipt_email($paymentId); } catch (Throwable $e) { /* jamais bloquant */ }
            }
        }
    }
    return ['status' => $p['status'], 'account_id' => (int)$p['account_id']];
}

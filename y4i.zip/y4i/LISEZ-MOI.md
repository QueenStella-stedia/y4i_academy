# Y4I Academy — Site PHP (Yaoundé)

## Contenu du dossier
- `index.php` : accueil, formations, services, carte/suivi, inscription, contact, administration.
- `formation.php` : fiche dédiée par formation (`formation.php?slug=...`).
- `service.php` : page dédiée par service (`service.php?service=aide`).
- (page légale retirée à la demande du client)
- `receipt.php` : reçu imprimable du fonds de garantie (`receipt.php?id=...&token=...`).
- `export.php` : exports CSV réservés à l'admin (`?type=accounts|payments|messages|journal`).
- `sitemap.php` / `robots.php` : génération de `sitemap.xml` et `robots.txt` via `.htaccess`.
- `404.php` : page d'erreur personnalisée.
- `inc_public.php` : en-tête/pied communs aux pages secondaires.
- `api.php` : API (inscription multipart, contact, rappel, paiement, webhooks, carte, suivi, admin, vérification, témoignages).
- `pay.php` : passerelles Campay / MTN MoMo / Orange Money.
- `config.php` : **toutes vos clés et réglages**.
- `lib.php` : base MySQL ou SQLite, schéma automatique, helpers e-mail/upload/services.
- `check.php` : diagnostic local uniquement (404 hors local ou si `debug=false`).
- `assets/` : logo, images, CSS, JS.

## Nouvelles fonctionnalités « pro »
- **Vérification des prestataires** : pièce d'identité + diplôme/certificat. **Le casier judiciaire n'est pas demandé.** Les fichiers sont stockés dans `data/uploads/` (accès HTTP bloqué) et consultables uniquement par l'admin via `api.php?action=admin_doc`.
- **Témoignages** : gérés depuis l'administration, publiés sur l'accueil. Trois exemples sont créés automatiquement : remplacez-les par de vrais avis.
- **Formulaire « Être rappelé »** : nom + téléphone, enregistré dans les messages de l'admin.
- **Demande préremplie** : `index.php?formation=CODE#inscription` ou `index.php?service=aide#contact`.
- **Reçu** : lien téléchargeable après paiement confirmé.
- **Exports CSV** : comptes, paiements, messages et journal.
- **SEO** : `og:image` absolue (1200×630), `og:url`, Twitter Card, `sitemap.xml`, `robots.txt`, page 404.
- **Accessibilité** : lien d'évitement, focus visible, labels, CTA mobile fixe.
- **Mesure d'audience** : GA4 ou Matomo, chargée uniquement après consentement (bandeau cookies).

## Photos (à remplacer par vos propres images)
Les photos sont dans `assets/img/photos/`. Gardez les mêmes noms de fichiers pour un remplacement simple (idéalement 1600 px de large, JPG). L'image de partage WhatsApp/Facebook est `assets/img/photos/og-cover.jpg` (1200×630) : remplacez-la si vous changez de visuel. Le logo d'en-tête est `assets/img/logo-mark.png`.

## Test local avec XAMPP (Linux)
```
sudo /opt/lampp/lampp start
sudo rm -rf /opt/lampp/htdocs/y4i
sudo cp -r y4i /opt/lampp/htdocs/
sudo chmod -R 777 /opt/lampp/htdocs/y4i/data
```
Puis ouvrez `http://localhost/y4i/check.php` (diagnostic) et `http://localhost/y4i/`.
- Base : **MySQL de XAMPP**, créée automatiquement (`y4i_academy`). Si MySQL est indisponible, bascule sur SQLite (`data/y4i.sqlite`).
- Réglages dans `config.php` → `db` (utilisateur `root`, mot de passe vide par défaut dans XAMPP).

## Installation (cPanel ou VPS)
1. PHP 8.0+ avec `curl`, `pdo_mysql` (ou `pdo_sqlite`), `fileinfo`, `mbstring`. HTTPS obligatoire.
2. Envoyez le dossier dans `public_html/`. Le dossier `data/` doit être inscriptible (755/775) et `data/uploads/` protégé.
3. Dans `config.php` :
   - `app_url` = `https://votre-domaine.cm` (sans slash final) ;
   - `debug` = `false`, `force_https` = `true` ;
   - `admin_password` = un mot de passe fort (ou changez-le depuis l'admin) ;
   - section `company` : nom légal, RCCM/NIU, adresse, responsable de publication ;
   - section `mail` : activez `enabled` seulement si l'hébergement envoie les e-mails ;
   - section `analytics` : `provider` = `''`, `ga4` ou `matomo`.
4. Ouvrez le site : sans identifiants Campay, le paiement reste en **mode simulation**.
5. Vérifiez `https://votre-domaine.cm/sitemap.xml` et `robots.txt`, puis déclarez le sitemap dans Google Search Console.

## Faire fonctionner le paiement RÉEL

### Option A — Campay (recommandée : Orange + MTN avec un seul compte)
1. Créez un compte marchand sur campay.net et faites valider l'entreprise.
2. Créez une application : copiez *App Username* et *App Password* dans `config.php` → `campay`.
3. Testez d'abord avec `https://demo.campay.net/api` (numéros de test fournis par Campay).
4. En production : `base` = `https://www.campay.net/api`.
5. Webhook dans Campay : `https://votre-domaine.cm/api.php?action=webhook_campay`.
6. Le site demande le paiement → Campay envoie la demande sur le téléphone → le prestataire saisit son **code secret sur son téléphone** → le site confirme et active le compte.
7. Remboursement : le bouton « Rembourser » de l'admin utilise l'API de retrait Campay.

> Les identifiants et l'URL doivent correspondre : des identifiants démo avec l'URL réelle donnent « authentification refusée ».

### Option B — MTN MoMo direct
1. Compte sur momodeveloper.mtn.com, produit *Collection*, clé `subscription_key`.
2. Créez l'API user/key, renseignez `config.php` → `mtn`.
3. Production : `base` = `https://proxy.momoapi.mtn.com`, `environment` = `mtncameroon`, `currency` = `XAF`.

### Option C — Orange Money direct
1. Compte developer.orange.com, API *Orange Money WebPay Cameroun*, contrat marchand.
2. Renseignez `auth_header` et `merchant_key` dans `config.php` → `orange`.
3. Production : `base` = `https://api.orange.com/orange-money-webpay/cm/v1`, `currency` = `XAF`.

> Le code secret ne passe JAMAIS par le site. Il est saisi sur le téléphone ou la page de l'opérateur.
> « Fonds bloqué » = argent encaissé sur le compte marchand et enregistré comme garantie ; restitution par l'admin.

## E-mails automatiques
Dans `config.php` → `mail` :
- `enabled` : `false` par défaut (l'environnement local n'envoie pas d'e-mail) ;
- `from`, `from_name`, `admin`, `reply_to` : adresses professionnelles.
Quand l'hébergement dispose de `mail()` ou d'un SMTP, passez `enabled` à `true`. Les notifications admin, la confirmation de paiement et le lien de reçu seront envoyés automatiquement.

## Informations légales (à remplacer)
- nom légal, RCCM, NIU ;
- responsable de publication ;
- adresse et horaires ;
- e-mail professionnel et hébergeur.
Faites valider les CGU/CGV et les règles du fonds de garantie par un conseil juridique avant la mise en production.

## Vérification des prestataires
- Documents acceptés : JPG, PNG, WebP ou PDF, 4 Mo maximum.
- Stockage : `data/uploads/` avec `.htaccess` `Require all denied`.
- Consultation : administration → « Vérification des prestataires » → boutons Vérifié / Refusé / En attente.
- Aucun casier judiciaire n'est demandé.

## Carte « type Google Maps » pour Yaoundé
- Fond OpenStreetMap limité à Yaoundé, recherche d'adresses/quartiers/hôpitaux, repères A/B, itinéraires, étapes, durée, distance, heure d'arrivée et suivi GPS en direct.
- Gratuit mais OSRM public est limité : pour un trafic réel, utilisez OpenRouteService, Mapbox ou votre propre OSRM.
- Pour Google Maps : clé Google Maps Platform et remplacement de `initMap()`/`route()`.

## Sécurité avant la mise en ligne
- [ ] Changer `admin_password` (12 caractères minimum, jamais `ChangeMoi!2026`).
- [ ] `debug` = `false`, `force_https` = `true`.
- [ ] HTTPS actif, certificat valide, redirection HTTP → HTTPS.
- [ ] Sauvegardes automatiques de la base et du dossier `data/uploads/`, avec test de restauration.
- [ ] Vérifier que `check.php`, `config.php`, `lib.php`, `pay.php` et `data/` renvoient 403/404.
- [ ] Remplacer les informations `company` et les témoignages d'exemple.
- [ ] Configurer Campay en production et tester un vrai paiement de 5 000 FCFA.
- [ ] Déclarer le site dans Google Search Console et créer une fiche Google Business Profile.

## Maintenance
- Journal d'activité : administration → Journal, export CSV via `export.php?type=journal`.
- Témoignages : administration → Témoignages publiés.
- Tarifs et formations : administration → Tarifs / Formations.
- Les anciennes pages `api.php?action=admin_export*` restent disponibles pour compatibilité.

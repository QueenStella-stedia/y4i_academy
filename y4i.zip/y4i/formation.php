<?php
require_once __DIR__ . '/inc_public.php';

$slug = trim((string)($_GET['slug'] ?? ''));
$f = $slug !== '' ? formation_by_slug($slug) : null;

if (!$f) {
    http_response_code(404);
    public_head('Formation introuvable', 'Cette formation n’existe pas ou n’est plus disponible.', 'formation.php');
    public_footer();
    exit;
}

$title = (string)$f['title'];
$desc = mb_substr((string)($f['short'] ?: strip_tags((string)$f['description'])), 0, 180);
$modules = array_values(array_filter(array_map('trim', preg_split('/[;\n]+/', (string)$f['modules']))));
$price = formation_price_label($f);
$waText = rawurlencode('Bonjour Y4I Academy, je souhaite des informations sur la formation ' . $f['code'] . ' — ' . $title . '.');

$jsonLd = json_encode([
    '@context' => 'https://schema.org',
    '@type' => 'Course',
    'name' => $title,
    'description' => (string)$f['short'],
    'provider' => ['@type' => 'EducationalOrganization', 'name' => company_info()['name'], 'url' => abs_url('')],
    'url' => abs_url('formation.php?slug=' . urlencode((string)$f['slug'])),
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

public_head($title . ' — Formation santé à Yaoundé', $desc, 'formation.php?slug=' . urlencode((string)$f['slug']), '<script type="application/ld+json">' . $jsonLd . '</script>');
?>
<section class="page-hero"><div class="wrap">
  <p class="breadcrumb" style="color:#B9CBE3"><a style="color:#fff" href="<?= h(abs_url('index.php')) ?>">Accueil</a> › <a style="color:#fff" href="<?= h(abs_url('index.php#formations')) ?>">Formations</a> › <?= h($title) ?></p>
  <span class="kicker"><i></i> Formation <?= h($f['code']) ?></span>
  <h1><?= h($title) ?></h1>
  <p><?= h((string)$f['short']) ?></p>
</div></section>

<main class="page-main"><div class="wrap page-grid">
  <article class="legal-body">
    <h2>Présentation</h2>
    <p><?= nl2br(h((string)$f['description'])) ?></p>

    <h2>Programme & compétences</h2>
    <?php if ($modules): ?>
      <ul><?php foreach ($modules as $m): ?><li><i class="fas fa-check" style="color:var(--ok);margin-right:.4rem"></i><?= h($m) ?></li><?php endforeach; ?></ul>
    <?php endif; ?>
    <?php if (trim((string)$f['specification']) !== ''): ?><p><?= nl2br(h((string)$f['specification'])) ?></p><?php endif; ?>

    <h2>Prérequis</h2>
    <p><?= nl2br(h((string)($f['prerequisites'] ?: 'Aucun prérequis particulier. Motivation et assiduité attendues.'))) ?></p>

    <h2>Durée & certification</h2>
    <p><b>Durée :</b> <?= h((string)$f['duration']) ?><br><b>Certification :</b> <?= h((string)$f['certification']) ?></p>

    <h2>Frais de formation</h2>
    <p><b><?= h($price) ?></b><?= trim((string)$f['price_note']) !== '' ? ' — ' . h((string)$f['price_note']) : '' ?></p>
    <p class="hint">Les modalités de paiement et le calendrier de la prochaine rentrée sont confirmés avec l'administration. Aucun paiement n'est demandé sur cette page.</p>

    <div class="row" style="margin-top:1.4rem">
      <a class="btn btn-primary" href="<?= h(abs_url('index.php?formation=' . urlencode((string)$f['code']) . '#inscription')) ?>"><i class="fas fa-user-plus"></i> S'inscrire à cette formation</a>
      <a class="btn btn-ghost" href="https://wa.me/<?= h(cfg()['whatsapp']) ?>?text=<?= $waText ?>" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i> Poser une question</a>
    </div>
  </article>

  <aside>
    <div class="side-card">
      <h3><i class="fas fa-graduation-cap"></i> En bref</h3>
      <p><b>Code :</b> <?= h($f['code']) ?><br><b>Durée :</b> <?= h((string)$f['duration']) ?><br><b>Tarif :</b> <?= h($price) ?></p>
      <a class="btn btn-red wide" href="<?= h(abs_url('index.php?formation=' . urlencode((string)$f['code']) . '#inscription')) ?>">Créer mon dossier</a>
    </div>
    <div class="side-card" style="margin-top:1rem">
      <h3><i class="fas fa-layer-group"></i> Autres formations</h3>
      <?php foreach (formations_all(true) as $other): if (($other['slug'] ?? '') === ($f['slug'] ?? '')) continue; ?>
        <p><a href="formation.php?slug=<?= h($other['slug']) ?>" style="text-decoration:none;color:var(--navy);font-weight:700"><?= h($other['title']) ?></a><br><small><?= h($other['code']) ?> · <?= h($other['duration']) ?></small></p>
      <?php endforeach; ?>
    </div>
    <div class="side-card" style="margin-top:1rem">
      <h3><i class="fas fa-location-dot"></i> Nous trouver</h3>
      <p><?= h(company_info()['address']) ?><br><?= h(company_info()['hours']) ?></p>
      <a class="btn btn-ghost small" href="<?= h(company_info()['maps']) ?>" target="_blank" rel="noopener">Ouvrir la carte</a>
    </div>
  </aside>
</div></main>
<?php public_footer(); ?>

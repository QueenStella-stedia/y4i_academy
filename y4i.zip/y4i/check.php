<?php
// Diagnostic local uniquement : http://localhost/y4i/check.php
// En production, ce fichier renvoie 404 (config debug=false).
$cfg = require __DIR__ . '/config.php';
// Double protection : mode debug ET requête locale uniquement.
$isLocal = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1', 'cli'], true)
    || in_array($_SERVER['HTTP_HOST'] ?? '', ['localhost', '127.0.0.1'], true)
    || str_starts_with($_SERVER['HTTP_HOST'] ?? '', 'localhost:')
    || str_starts_with($_SERVER['HTTP_HOST'] ?? '', '127.0.0.1:');
if (empty($cfg['debug']) || !$isLocal) { http_response_code(404); exit('Not found'); }

ini_set('display_errors', '1');
error_reporting(E_ALL);
$h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
$rows = [];
function row(string $label, bool $ok, string $hint = '', bool $warning = false): void {
    global $rows;
    $rows[] = [$label, $ok, $warning, $hint];
}

row('PHP ≥ 8.0', version_compare(PHP_VERSION, '8.0', '>='), 'Version : ' . PHP_VERSION);
row('Extension curl', extension_loaded('curl'), 'Paiements Mobile Money, recherche d\'adresses et itinéraires');
row('Extension pdo_mysql', extension_loaded('pdo_mysql'), 'Base MySQL / MariaDB (XAMPP)');
row('Extension pdo_sqlite', extension_loaded('pdo_sqlite'), 'Base de secours si MySQL est indisponible');
row('Extension mbstring', extension_loaded('mbstring'), 'Nettoyage et validation des textes accentués');
row('Extension json', extension_loaded('json'), 'API interne');
row('Extension openssl', extension_loaded('openssl'), 'HTTPS / échanges sécurisés');

$data = __DIR__ . '/data';
row('Dossier data/ inscriptible', is_dir($data) && is_writable($data), is_dir($data) ? (is_writable($data) ? 'Utilisé par le mode SQLite de secours' : 'Non inscriptible : MySQL reste utilisé, aucun impact si MySQL fonctionne') : 'Dossier absent', is_dir($data) && !is_writable($data));
row('Fichier .htaccess de sécurité', is_file(__DIR__ . '/.htaccess'), '.htaccess permet de bloquer data/, les sauvegardes et les fichiers sensibles');
row('Protection du dossier assets', is_file(__DIR__ . '/assets/.htaccess'), 'Empêche l\'exécution de code dans les images');

$driver = '—';
try {
    require_once __DIR__ . '/pay.php';
    $pdo = db();
    $driver = db_driver();
    row('Connexion base de données', true, 'Moteur : <b>' . $h($driver) . '</b> — base « ' . $h($cfg['db']['name']) . ' » (MySQL) ou fichier data/y4i.sqlite');
    foreach (['accounts', 'payments', 'tariffs', 'settings', 'formations', 'messages', 'requests', 'tracking', 'geocache', 'rate_limits', 'activity_log'] as $t) {
        try { $n = (int)$pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn(); row("Table $t", true, $n . ' ligne(s)'); }
        catch (Throwable $e) { row("Table $t", false, 'Table absente ou illisible : ' . $h($e->getMessage())); }
    }

    foreach (['formation_code', 'formation_spec', 'service_description', 'experience', 'zone', 'email'] as $c) {
        row('Colonne accounts.' . $c, in_array($c, table_cols($pdo, db_driver(), 'accounts'), true), 'Migration automatique des inscriptions');
    }

    $nFormations = (int)$pdo->query("SELECT COUNT(*) FROM formations WHERE active=1")->fetchColumn();
    row('Formations actives', $nFormations >= 5, $nFormations . ' parcours actif(s), attendu : 5');

    $minG = (int)setting('min_guarantee', 0);
    row('Fonds de garantie minimum', $minG >= 1000, 'Valeur actuelle : ' . number_format($minG, 0, ',', ' ') . ' FCFA', $minG < 1000);

    $hash = (string)setting('admin_password_hash', '');
    $default = (string)($cfg['admin_password'] ?? '') === 'ChangeMoi!2026';
    row('Mot de passe admin personnalisé', $hash !== '' || !$default, $hash !== '' ? 'Hash personnalisé enregistré en base' : ($default ? 'ATTENTION : mot de passe par défaut encore actif. Utilisez « Changer le mot de passe » dans l\'admin.' : 'Défini dans config.php'), $hash === '' && $default);

    $localCount = count(local_places());
    row('Base locale des lieux de Yaoundé', $localCount >= 100, $localCount . ' lieux (quartiers, hôpitaux, marchés, carrefours, transports)');

    $tests = ['Hôpital Central', 'Odza', 'Melen', 'Bastos', 'Biyem-Assi'];
    $found = 0;
    foreach ($tests as $q) if (local_geocode($q)) $found++;
    row('Recherche locale de lieux', $found === count($tests), $found . '/' . count($tests) . ' exemples trouvés sans Internet');

    $gw = [];
    foreach (['campay', 'mtn', 'orange'] as $g) $gw[] = $g . ' : ' . gateway_mode($g);
    $live = count(array_filter(['campay', 'mtn', 'orange'], fn($g) => gateway_ready($g)));
    row('Passerelles de paiement', $live > 0, implode(' · ', $gw) . ($live ? '' : ' — mode simulation : aucun argent réel'), $live === 0);

    $assets = ['assets/img/photos/flyer-formations.jpg', 'assets/img/photos/formation-hero.jpg', 'assets/img/photos/photo-about.jpg'];
    $missing = array_filter($assets, fn($f) => !is_file(__DIR__ . '/' . $f));
    row('Images principales', !$missing, $missing ? 'Manquantes : ' . $h(implode(', ', $missing)) : 'Affiche, héros et photo « à propos » présentes');

    row('Mode debug', true, !empty($cfg['debug']) ? 'Activé uniquement en local (127.0.0.1 / localhost)' : 'Désactivé : aucune erreur technique affichée', !empty($cfg['debug']));
} catch (Throwable $e) {
    row('Connexion base de données', false, $h($e->getMessage()));
}

$ok = count(array_filter($rows, fn($r) => $r[1]));
$warnings = count(array_filter($rows, fn($r) => $r[2]));
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Diagnostic Y4I Academy</title>
<style>
  body{font-family:system-ui,-apple-system,sans-serif;max-width:940px;margin:32px auto;padding:0 18px;color:#12233b;background:#f5f7f9}
  h1{font-size:1.5rem;margin-bottom:.2rem}h1 span{color:#C8102E}
  .sub{color:#5b6b7f;margin-top:0}
  table{border-collapse:collapse;width:100%;background:#fff;border:1px solid #dde4ec;border-radius:10px;overflow:hidden}
  td,th{padding:10px 12px;border-bottom:1px solid #eef1f5;text-align:left;font-size:.9rem;vertical-align:top}
  th{background:#0C2B4E;color:#fff;font-size:.75rem;text-transform:uppercase;letter-spacing:.06em}
  tr:last-child td{border-bottom:0}
  .st{font-weight:800;white-space:nowrap}.s-ok{color:#087443}.s-ko{color:#C8102E}.s-warn{color:#9A6700}
  .hint{color:#5b6b7f;font-size:.82rem}
  .cards{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:18px 0}
  .card{background:#fff;border:1px solid #dde4ec;border-radius:10px;padding:12px 14px}
  .card small{display:block;color:#5b6b7f;font-size:.68rem;text-transform:uppercase;letter-spacing:.08em}.card b{font-size:1.3rem}
  .btn{display:inline-block;background:#0C2B4E;color:#fff;text-decoration:none;padding:.65rem 1rem;border-radius:8px;font-weight:700;font-size:.88rem}
  .note{background:#FFF8E6;border:1px solid #F0D48A;border-radius:10px;padding:12px 14px;font-size:.86rem;color:#6b5200}
  code{background:#eef1f5;padding:1px 5px;border-radius:4px}
  @media(max-width:640px){.cards{grid-template-columns:1fr}td,th{padding:8px}}
</style>
</head>
<body>
<h1>Diagnostic <span>Y4I Academy</span></h1>
<p class="sub">Page réservée au serveur local. Supprimez ou bloquez <code>check.php</code> en production.</p>
<div class="cards">
  <div class="card"><small>Contrôles OK</small><b><?= $ok ?></b></div>
  <div class="card"><small>Points d'attention</small><b><?= $warnings ?></b></div>
  <div class="card"><small>Base utilisée</small><b><?= $h($driver) ?></b></div>
</div>
<table>
<thead><tr><th>Contrôle</th><th>Statut</th><th>Détail</th></tr></thead>
<tbody>
<?php foreach ($rows as [$label, $pass, $warn, $hint]): ?>
<tr>
  <td><b><?= $h($label) ?></b></td>
  <td class="st <?= $warn ? 's-warn' : ($pass ? 's-ok' : 's-ko') ?>"><?= $warn ? 'ATTENTION' : ($pass ? 'OK' : 'ÉCHEC') ?></td>
  <td class="hint"><?= $hint ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<?php if ($warnings): ?>
<p class="note"><b>À faire avant la mise en ligne :</b> changez le mot de passe administrateur, configurez une passerelle Mobile Money et activez HTTPS (voir <code>LISEZ-MOI.md</code>).</p>
<?php endif; ?>
<p><a class="btn" href="./">Ouvrir le site</a> <a class="btn" style="background:#0f7a5a" href="api.php?action=tariffs">Tester l'API</a></p>
</body>
</html>

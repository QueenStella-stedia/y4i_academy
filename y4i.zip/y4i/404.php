<?php
require_once __DIR__ . '/inc_public.php';
http_response_code(404);
public_head('Page introuvable', 'La page demandée n’existe pas ou a été déplacée.', '404.php');
?>
<main class="error-page"><div class="wrap">
  <b>404</b>
  <h1 style="margin:.4rem 0 1rem">Cette page n'existe pas.</h1>
  <p class="lead" style="margin:0 auto 1.6rem">Le lien est peut-être ancien, ou l'adresse contient une erreur. Revenez à l'accueil ou contactez-nous : nous vous orientons.</p>
  <div class="row" style="justify-content:center">
    <a class="btn btn-primary" href="<?= h(abs_url('index.php')) ?>">Retour à l'accueil</a>
    <a class="btn btn-ghost" href="<?= h(abs_url('index.php#contact')) ?>">Nous contacter</a>
  </div>
</div></main>
<?php public_footer(); ?>

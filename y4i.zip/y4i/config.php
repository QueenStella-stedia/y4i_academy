<?php
// ============ CONFIGURATION Y4I ACADEMY ============
// Renseignez les clés (voir LISEZ-MOI.md). Sans clés => MODE SIMULATION automatique.
$host = $_SERVER['HTTP_HOST'] ?? '';
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/y4i/index.php')), '/');
if ($base === '.' || $base === '/') $base = '';
$autoUrl = $host ? ($scheme . '://' . $host . $base) : 'http://localhost/y4i';
$isLocal = in_array($_SERVER['REMOTE_ADDR'] ?? 'cli', ['127.0.0.1', '::1', 'cli'], true)
        || in_array($host, ['localhost', '127.0.0.1'], true)
        || str_starts_with($host, 'localhost:')
        || str_starts_with($host, '127.0.0.1:');

return [
    // true uniquement en local : en ligne, aucune erreur technique n'est affichée
    'debug'          => $isLocal,
    'app_url'        => $autoUrl,   // détecté automatiquement (surchargez si besoin)


    // BASE DE DONNÉES : 'auto' = MySQL (XAMPP/phpMyAdmin) puis SQLite si MySQL indisponible
    'db' => [
        'driver' => 'auto',          // auto | mysql | sqlite
        'host'   => '127.0.0.1',
        'port'   => 3306,
        'name'   => 'y4i_academy',   // créée automatiquement
        'user'   => 'root',          // XAMPP : root
        'pass'   => '',              // XAMPP : mot de passe vide
    ],

    // ACCÈS ADMINISTRATEUR
    'admin_password'      => 'ChangeMoi!2026', // À CHANGER (ou utilisez « Changer le mot de passe » dans l'admin)
    'admin_password_hash' => '',               // optionnel : hash password_hash() ; prioritaire sur admin_password

    'whatsapp'       => '237696500949',
    'phone_secondary'=> '237622142496',
    'email'          => 'contact@y4i-academy.cm',
    'currency'       => 'XAF',
    'min_guarantee'  => 5000,

    // INFORMATIONS LÉGALES : à compléter avant la mise en ligne.
    // Ces valeurs alimentent les mentions légales, la politique de confidentialité et les reçus.
    'company' => [
        'name'         => 'Y4I Academy',
        'legal_name'   => 'Y4I Academy — dénomination légale à compléter',
        'registration' => 'RCCM : à compléter · NIU : à compléter',
        'address'      => 'Odza, face au dispensaire, Yaoundé, Cameroun',
        'manager'      => 'Responsable de publication : à compléter',
        'hours'        => '24h/24 – 7j/7',
        'maps'         => 'https://maps.google.com/?q=Odza,Yaound%C3%A9,Cameroun',
    ],

    // E-MAILS AUTOMATIQUES (confirmation, reçu, notification admin).
    // Laissez enabled=false tant que l'hébergement n'a pas de fonction mail() ou SMTP fiable.
    // Sur un hébergement cPanel, renseignez une adresse créée sur le domaine.
    'mail' => [
        'enabled'   => false,
        'from'      => 'no-reply@y4i-academy.cm',
        'from_name' => 'Y4I Academy',
        'admin'     => 'contact@y4i-academy.cm',
        'reply_to'  => 'contact@y4i-academy.cm',
    ],

    // MESURE D'AUDIENCE (facultatif). provider : '' | 'ga4' | 'matomo'
    'analytics' => [
        'provider' => '',
        'id'       => '',   // GA4 : G-XXXXXXXXXX · Matomo : identifiant de site
        'host'     => '',   // Matomo uniquement : https://stats.votre-domaine.cm
    ],

    // Passerelle utilisée par défaut : campay | mtn | orange
    'default_gateway' => 'campay',

    // Sécurité
    'security' => [
        'force_https'      => false, // true en production (nécessite un certificat SSL)
        'session_hours'    => 3,     // déconnexion admin automatique
        'max_login'        => 8,     // tentatives / 15 minutes / IP
        'max_register'     => 12,    // inscriptions / heure / IP
        'max_contact'      => 8,     // messages / heure / IP
        'max_geocode'      => 240,   // recherches / 10 minutes / IP
    ],

    // Carte : fond OpenStreetMap + recherche multi-fournisseurs + repli local
    'map' => [
        'center'  => [3.8667, 11.5167],
        'zoom'    => 13,
        'tile'    => 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        'email'   => 'contact@y4i-academy.cm', // recommandé par Nominatim
    ],

    // CAMPAY (Orange Money + MTN MoMo en une seule intégration) — https://campay.net
    // >>> C'EST ICI QUE VOUS METTEZ VOS IDENTIFIANTS CAMPAY POUR ENCAISSER RÉELLEMENT. <<<
    // 1. Connectez-vous à votre tableau de bord Campay.
    // 2. Copiez "App Username" dans username et "App Password" dans password.
    // 3. Laissez base sur la production (https://www.campay.net/api).
    //    Pour tester sans argent réel, utilisez https://demo.campay.net/api avec les identifiants de démonstration.
    // Dès que username et password sont renseignés, l'inscription prestataire déclenche un vrai paiement
    // Mobile Money : le message de validation du code secret est envoyé par l'opérateur au numéro indiqué.
    'campay' => [
        'base'        => 'https://www.campay.net/api',   // PRODUCTION. Démo : https://demo.campay.net/api
        'username'    => '',   // "App Username" du tableau de bord Campay
        'password'    => '',   // "App Password"
        'webhook_key' => '',   // clé webhook (optionnelle, affichée dans Campay)
    ],
    // MTN MoMo API (collection) — https://momodeveloper.mtn.com
    'mtn' => [
        'base'             => 'https://sandbox.momodeveloper.mtn.com', // PRODUCTION : https://proxy.momoapi.mtn.com
        'subscription_key' => '',   // Ocp-Apim-Subscription-Key (produit Collection)
        'api_user'         => '',   // UUID API user
        'api_key'          => '',
        'environment'      => 'sandbox', // PRODUCTION : mtncameroon
        'currency'         => 'EUR',     // sandbox = EUR ; PRODUCTION = XAF
    ],
    // ORANGE MONEY Web Payment Cameroun — https://developer.orange.com
    'orange' => [
        'base'        => 'https://api.orange.com/orange-money-webpay/dev/v1', // PRODUCTION : .../orange-money-webpay/cm/v1
        'auth_header' => '',   // "Basic xxxx" (base64 client_id:client_secret)
        'merchant_key'=> '',
        'currency'    => 'OUV', // sandbox = OUV ; PRODUCTION = XAF
    ],
];

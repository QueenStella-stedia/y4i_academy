<?php
require_once __DIR__ . '/lib.php';
$T = []; foreach (db()->query("SELECT * FROM tariffs") as $r) $T[$r['k']] = $r;
$wa = cfg()['whatsapp'];
function fcfa($n) { return number_format((int)$n, 0, ',', ' '); }
$services = [
  'aide'    => ['fa-heart-pulse', 'Aide à domicile', 'Un soutien adapté aux gestes du quotidien, avec une présence attentive qui respecte le rythme de chacun.', ['Auxiliaires de vie', 'Toilette & repas', 'Présence quotidienne']],
  'hopital' => ['fa-hospital', 'Accompagnement à l\'hôpital', 'Une présence rassurante lors des hospitalisations, rendez-vous, examens ou sorties d\'établissement.', ['Rendez-vous', 'Visites', 'Retour à domicile']],
  'kine'    => ['fa-user-doctor', 'Kinésithérapie & soins', 'Séances de rééducation et de bien-être à domicile, selon les besoins et l\'orientation médicale.', ['Rééducation', 'Mobilité', 'Professionnels qualifiés']],
  'courses' => ['fa-basket-shopping', 'Courses & quotidien', 'Marché, pharmacie, petites démarches : nous nous en occupons, pour que la maison reste un lieu simple à vivre.', ['Courses', 'Pharmacie', 'Petites commissions']],
];
$slides = [['photo-home', 'Aide à domicile'], ['photo-hospital', 'Accompagnement à l\'hôpital'], ['photo-care', 'Soins et rééducation'], ['photo-support', 'Une présence qui rassure']];
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Y4I Academy — Aide à domicile et accompagnement hospitalier à Yaoundé</title>
<meta name="description" content="Aide à domicile, accompagnement à l'hôpital, kinésithérapie et courses à Yaoundé (Odza). Intervenants vérifiés, garantis par un fonds bloqué, suivis en direct.">
<link rel="icon" href="assets/img/logo-mark.png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,700;1,600;1,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="infobar"><div class="wrap"><span><i class="fas fa-location-dot"></i> Y4I Academy — Odza, Yaoundé (face dispensaire) · Service 24h/24 – 7j/7</span><a href="tel:+<?= $wa ?>"><i class="fas fa-phone"></i> +237 6 96 50 09 49</a></div></div>
<header class="site"><div class="wrap bar">
  <a href="#accueil" class="brand"><span class="mark"><img src="assets/img/logo-mark.png" alt=""></span><span class="brand-t">Y4I Academy<small>Votre avenir commence ici…</small></span></a>
  <button class="burger" id="burger" aria-label="Menu"><i class="fas fa-bars"></i></button>
  <nav id="nav">
    <a class="nav-link active" href="#accueil">Accueil</a><a class="nav-link" href="#services">Services</a><a class="nav-link" href="#suivi">Carte & suivi</a>
    <a class="nav-link" href="#inscription">Créer un compte</a><a class="nav-link" href="#contact">Nous contacter</a>
    <a class="nav-link lock" href="#admin" aria-label="Administration"><i class="fas fa-lock"></i></a>
    <a class="btn btn-primary nav-cta" href="#contact">Demander de l'aide <i class="fas fa-arrow-right"></i></a>
  </nav>
</div></header>

<!-- ACCUEIL -->
<section id="accueil" class="page-section active">
  <div class="hero"><div class="wrap hero-grid">
    <div class="hero-text reveal">
      <span class="kicker"><i></i> Aide à domicile & accompagnement hospitalier · Odza</span>
      <h1>Une présence <em>fiable</em>, au bon moment.</h1>
      <p class="lead">Y4I Academy organise les aides essentielles pour que chaque journée reste plus douce, chez vous comme à l'hôpital. Des intervenants vérifiés, garantis et suivis sur la carte de Yaoundé.</p>
      <div class="cta"><a class="btn btn-primary btn-lg" href="#contact">Organiser une aide <i class="fas fa-arrow-right"></i></a><a class="link" href="#services">Voir nos services <i class="fas fa-arrow-right"></i></a></div>
    </div>
    <div class="hero-visual reveal">
      <div class="slideshow" id="slideshow">
        <?php foreach ($slides as $i => $s): ?><figure class="slide<?= $i === 0 ? ' active-slide' : '' ?>"><img src="assets/img/photos/<?= $s[0] ?>.jpg" alt="<?= $s[1] ?>"<?= $i ? ' loading="lazy"' : '' ?>><figcaption><?= $s[1] ?></figcaption></figure><?php endforeach; ?>
        <div class="dots" id="dots"></div>
      </div>
      <div class="float-badge"><i class="fas fa-shield-heart"></i><span><b>Intervenants garantis</b>fonds bloqué & suivi GPS</span></div>
    </div>
  </div></div>
  <div class="wrap stats reveal">
    <div><b>24h/24 · 7j/7</b><span>Permanence à Odza, interventions dans tout Yaoundé</span></div>
    <div><b>Fonds de garantie</b><span>Chaque prestataire bloque une somme sécurisée</span></div>
    <div><b>Suivi en direct</b><span>Itinéraire, durée et arrivée de l'intervenant</span></div>
  </div>

  <div class="band mint"><div class="wrap">
    <div class="head reveal"><span class="kicker red"><i></i> Une démarche claire</span><h2>De la première demande au <em>bon accompagnement.</em></h2><p>La bonne aide commence par une vraie écoute. Nous avançons étape par étape pour construire une réponse adaptée à votre situation.</p></div>
    <div class="steps3">
      <div class="reveal"><small>01</small><i class="dotline"></i><h3>Vous racontez votre besoin</h3><p>Une demande simple suffit : à domicile, à l'hôpital ou pour un service ponctuel.</p></div>
      <div class="reveal"><small>02</small><i class="dotline"></i><h3>Nous organisons l'aide</h3><p>Nous choisissons l'intervenant adapté, avec une estimation claire du trajet et du coût.</p></div>
      <div class="reveal"><small>03</small><i class="dotline"></i><h3>Vous êtes accompagné</h3><p>Écoute, coordination et suivi en direct sur la carte jusqu'à la fin de l'intervention.</p></div>
    </div>
    <p class="note"><i class="fas fa-stethoscope"></i> Les interventions de kinésithérapie sont organisées avec des professionnels qualifiés, selon les besoins et l'orientation médicale lorsqu'elle est nécessaire.</p>
  </div></div>

  <div class="split">
    <div class="split-img"><img src="assets/img/photos/photo-hospital.jpg" alt="Un intervenant accompagne une patiente à l'hôpital" loading="lazy"></div>
    <div class="split-txt reveal"><span class="kicker light"><i></i> L'hôpital autrement</span>
      <h2>Parce qu'un proche ne devrait jamais traverser l'hôpital <em>seul.</em></h2>
      <p>Nos intervenants vous accompagnent lors des consultations, des hospitalisations, des visites et du retour à domicile. Une présence qui aide aussi les proches à souffler.</p>
      <a class="btn btn-light" href="#contact">Parler de mon besoin <i class="fas fa-arrow-right"></i></a></div>
  </div>

  <div class="wrap pad">
    <div class="head reveal"><span class="kicker red"><i></i> Confiance & sécurité</span><h2>Des intervenants <em>engagés</em>, un cadre clair.</h2></div>
    <div class="cards3">
      <article class="reveal"><i class="fas fa-lock"></i><h3>Fonds de garantie</h3><p>Chaque prestataire dépose une garantie par Mobile Money. Elle reste bloquée pendant son activité et lui est restituée à la fin.</p></article>
      <article class="reveal"><i class="fas fa-mobile-screen"></i><h3>Paiement simple</h3><p>Orange Money et MTN MoMo : vous confirmez avec votre code secret directement sur votre téléphone.</p></article>
      <article class="reveal"><i class="fas fa-route"></i><h3>Suivi en direct</h3><p>La position de l'intervenant n'est partagée que pendant la prestation, avec itinéraire et heure d'arrivée estimée.</p></article>
    </div>
  </div>

  <div class="band mint"><div class="wrap narrow2">
    <div class="head reveal"><h2>Questions <em>fréquentes</em></h2></div>
    <details class="faq reveal"><summary>Comment fonctionne le fonds de garantie ?</summary><p>À l'inscription, le prestataire choisit un montant (minimum fixé par l'administration) et le règle par Mobile Money. La somme est bloquée et lui est remboursée à la clôture de son compte.</p></details>
    <details class="faq reveal"><summary>Comment payer avec Orange Money ou MTN MoMo ?</summary><p>Vous saisissez votre numéro, puis un message arrive sur votre téléphone. Vous tapez votre code secret sur le téléphone pour confirmer. Aucun code n'est demandé sur le site.</p></details>
    <details class="faq reveal"><summary>Dans quelles zones intervenez-vous ?</summary><p>Partout à Yaoundé, avec une permanence à Odza (face dispensaire). Le coût du déplacement est estimé sur la carte avant validation.</p></details>
    <details class="faq reveal"><summary>Puis-je suivre l'arrivée de l'intervenant ?</summary><p>Oui. Après votre demande, un code de suivi vous permet de voir sa position en direct sur la carte, uniquement pendant la prestation.</p></details>
  </div></div>

  <div class="wrap pad"><div class="ctaband reveal"><div><h2>Besoin d'une aide <em>aujourd'hui</em> ?</h2><p>Notre permanence répond 24h/24.</p></div><a class="btn btn-red btn-lg" href="#contact">Demander de l'aide <i class="fas fa-arrow-right"></i></a></div></div>
</section>

<!-- SERVICES -->
<section id="services" class="page-section"><div class="wrap pad">
  <div class="head split2 reveal"><div><span class="kicker red"><i></i> Nos services</span><h2>Un même objectif : <em>vous soulager.</em></h2></div><p>Chaque intervention s'inscrit dans une logique simple : préserver l'autonomie, faciliter l'organisation et apporter une présence humaine qui compte vraiment.</p></div>
  <div class="svc-grid">
    <?php $n = 0; foreach ($services as $k => $s): $n++; ?>
    <article class="service-card reveal" data-key="<?= $k ?>">
      <small class="num">0<?= $n ?></small>
      <div class="svc-body"><div class="svc-top"><span class="ico c<?= $n ?>"><i class="fas <?= $s[0] ?>"></i></span><h3><?= $s[1] ?></h3><button class="go" onclick="selectService('<?= $k ?>')" aria-label="Demander : <?= $s[1] ?>"><i class="fas fa-arrow-right"></i></button></div>
        <p><?= $s[2] ?></p><div class="tags"><?php foreach ($s[3] as $t) echo "<span>$t</span>"; ?></div>
        <p class="service-price"><?php if ((int)$T[$k]['price'] > 0): ?><i class="fas fa-tag"></i> Dès <span><?= fcfa($T[$k]['price']) ?></span> FCFA / <?= htmlspecialchars($T[$k]['unit']) ?><?php else: ?><i class="fas fa-circle-info"></i> Tarif sur devis · selon les heures et les tâches<?php endif; ?></p></div>
    </article>
    <?php endforeach; ?>
  </div>
  <div class="devis reveal"><i class="fas fa-file-invoice"></i><div><h3>Un tarif adapté à votre besoin</h3><p>Le prix dépend du service demandé, du nombre d'heures, des tâches à réaliser et du lieu d'intervention. Décrivez-nous votre besoin : nous vous répondons avec un devis clair, sans engagement.</p></div><a class="btn btn-red" href="#contact">Demander un devis <i class="fas fa-arrow-right"></i></a></div>
</div></section>

<!-- CARTE & SUIVI -->
<section id="suivi" class="page-section"><div class="wrap pad">
  <div class="head split2 reveal"><div><span class="kicker red"><i></i> Carte de Yaoundé</span><h2>La présence, en toute <em>confiance.</em></h2></div><p>Cherchez un lieu, choisissez l'itinéraire, obtenez la durée, l'heure d'arrivée et une estimation du coût. Le suivi n'est actif que pendant la prestation.</p></div>
  <div class="map-layout">
    <aside class="map-panel">
      <div class="field"><label for="fromInput">Départ</label><div class="ac"><input id="fromInput" placeholder="Quartier, hôpital, rue…" autocomplete="off"><ul class="ac-list" id="fromList"></ul></div></div>
      <div class="field"><label for="toInput">Destination</label><div class="ac"><input id="toInput" placeholder="Où doit aller l'intervenant ?" autocomplete="off"><ul class="ac-list" id="toList"></ul></div></div>
      <div class="row"><button class="btn btn-primary small" id="btnLocate"><i class="fas fa-crosshairs"></i> Ma position</button><button class="btn btn-ghost small" id="btnSwap"><i class="fas fa-arrow-right-arrow-left"></i> Inverser</button><button class="btn btn-ghost small" id="btnClear">Effacer</button></div>
      <div class="chips" id="chips"></div>
      <p class="hint">Astuce : cliquez sur la carte pour placer le départ, puis la destination. Glissez les repères pour les ajuster.</p>
      <div id="routeBox" hidden>
        <div id="routeTabs" class="tabs"></div>
        <div class="estimate"><div><small>Durée</small><b id="estTime">–</b></div><div><small>Distance</small><b id="estDist">–</b></div><div><small>Arrivée prévue</small><b id="estEta">–</b></div></div>
        <div class="estimate cost"><div><small>Déplacement</small><b id="estMove">–</b></div><div><small>Total estimé</small><b id="estTotal">–</b></div></div>
        <select id="reqService"></select>
        <ol id="steps" class="steps"></ol>
        <details class="req"><summary>Envoyer cette demande</summary>
          <input id="reqName" placeholder="Votre nom"><input id="reqPhone" placeholder="Téléphone / WhatsApp"><input id="reqDetails" placeholder="Précisions (facultatif)">
          <button class="btn btn-primary" id="btnRequest">Valider la demande</button><div id="reqResult"></div></details>
      </div>
      <details class="req" id="followBox"><summary>Suivre un intervenant en direct</summary>
        <input id="followCode" placeholder="Code de la demande (ex : A1B2C3)" maxlength="6"><button class="btn btn-primary small" id="btnFollow">Suivre</button>
        <p id="followState" class="hint"></p><hr>
        <p class="hint"><b>Intervenant :</b> saisissez le code et la clé reçus puis partagez votre position.</p>
        <input id="pushKey" placeholder="Clé intervenant"><button class="btn btn-ghost small" id="btnPush">Partager ma position</button></details>
    </aside>
    <div id="yaoundeRealMap" class="map"></div>
  </div>
</div></section>

<!-- INSCRIPTION -->
<section id="inscription" class="page-section"><div class="wrap pad">
  <div class="head reveal"><span class="kicker red"><i></i> Créer un compte</span><h2>Rejoignez Y4I Academy, <em>simplement.</em></h2></div>
  <div class="reg-grid">
    <aside class="dark-card reveal"><i class="fas fa-shield-halved"></i><h3>Un cadre sécurisé.</h3>
      <p>Les prestataires déposent un fonds de garantie bloqué par Mobile Money. Le code secret se saisit uniquement sur le téléphone, jamais sur le site.</p>
      <ul><li><i class="fas fa-mobile-screen"></i> Orange Money · MTN MoMo</li><li><i class="fas fa-lock"></i> Fonds bloqué et remboursable</li><li><i class="fas fa-user-check"></i> Compte actif dès le paiement confirmé</li></ul></aside>
    <div class="card-offset reveal">
      <form id="registerForm">
        <div class="field"><label>Nom complet</label><input id="regName" required></div>
        <div class="two"><div class="field"><label>Téléphone / WhatsApp</label><input id="regContact" required placeholder="+237 6XX XXX XXX"></div>
        <div class="field"><label>Quartier</label><input id="regLocation" required placeholder="Ex : Odza, Melen, Bastos…"></div></div>
        <div class="field"><label>Type de compte</label><select id="regType"><option value="client">Client (demandeur de service)</option><option value="prestataire">Prestataire (intervenant)</option></select></div>
        <div id="clientFields" class="field"><label>Mode de paiement préféré</label><select id="regPaymentMethod"><option>Orange Money</option><option>MTN Mobile Money</option><option>Espèces sur place</option></select></div>
        <div id="prestataireFields" hidden>
          <div class="field"><label>Moyen de paiement du fonds de garantie</label><select id="regGateway"><option value="campay">Campay — Orange Money & MTN MoMo</option><option value="orange">Orange Money (page sécurisée Orange)</option><option value="mtn">MTN MoMo (demande sur le téléphone)</option></select></div>
          <div class="two"><div class="field"><label>Numéro Mobile Money à débiter</label><input id="regPhone" inputmode="tel" placeholder="6XX XXX XXX"></div>
          <div class="field"><label>Fonds de garantie (FCFA)</label><input type="number" id="regAmount" min="5000" step="1"><small id="minG" class="hint"></small></div></div>
          <p class="secure"><i class="fas fa-shield-halved"></i> Vous ne saisissez jamais votre code secret ici : il se compose uniquement sur votre téléphone quand l'opérateur vous le demande.</p>
        </div>
        <button class="btn btn-primary wide" type="submit" id="regSubmit">Créer mon compte</button>
      </form>
      <div id="payBox" class="paybox" hidden><div class="phone"><i class="fas fa-mobile-screen-button"></i><div><b id="payTitle">Vérifiez votre téléphone</b><p id="payText"></p></div></div><div class="spinner" id="paySpin"></div><p id="payMeta" class="hint"></p></div>
      <div id="registrationSuccess" class="result ok" hidden><i class="fas fa-circle-check"></i><h3>Votre dossier est bien reçu.</h3><p id="successDetails"></p></div>
      <div id="registrationError" class="result ko" hidden><i class="fas fa-triangle-exclamation"></i><h3>Paiement non abouti</h3><p id="errorDetails"></p><button class="btn btn-red" id="btnRetryRegistration">Réessayer</button></div>
    </div>
  </div>
</div></section>

<!-- CONTACT -->
<section id="contact" class="page-section dark"><div class="wrap contact">
  <div class="contact-info reveal"><span class="kicker light"><i></i> Parlons de votre situation</span>
    <h2>Organisons l'aide qui vous <em class="gold">ressemble.</em></h2>
    <p>Décrivez-nous votre besoin : une aide ponctuelle, une présence régulière, un accompagnement à l'hôpital ou une organisation plus globale.</p>
    <p class="cl"><i class="fas fa-location-dot"></i> Retrouvez-nous à Odza, en face du dispensaire.</p>
    <p class="cl"><i class="fab fa-whatsapp"></i> WhatsApp & urgences : +237 6 96 50 09 49</p>
    <p class="cl"><i class="fas fa-clock"></i> Disponibles 24h/24 · 7j/7</p></div>
  <form id="contactForm" class="card-offset reveal">
    <div class="two"><div class="field"><label>Votre nom</label><input id="cName" required placeholder="Votre nom"></div><div class="field"><label>Téléphone / WhatsApp</label><input id="cPhone" required placeholder="+237 6 XX XX XX XX"></div></div>
    <div class="field"><label>Votre besoin</label><select id="cNeed"><?php foreach ($services as $k => $s) echo "<option value=\"$k\">{$s[1]}</option>"; ?></select></div>
    <div class="field"><label>Quartier & précisions</label><textarea id="cMsg" rows="4" placeholder="Expliquez-nous simplement ce dont vous avez besoin…"></textarea></div>
    <button class="btn btn-red wide" type="submit"><i class="fab fa-whatsapp"></i> Envoyer via WhatsApp</button>
    <p class="hint">En envoyant ce formulaire, vous acceptez d'être recontacté au sujet de votre demande.</p>
  </form>
</div></section>

<!-- ADMIN -->
<section id="admin" class="page-section"><div class="wrap pad">
  <div id="adminLogin" class="card-offset narrow2 center"><i class="fas fa-lock big"></i><h3>Accès administrateur</h3>
    <div class="field"><input type="password" id="adminPasswordInput" placeholder="Mot de passe" autocomplete="current-password"></div>
    <button class="btn btn-primary wide" id="btnAdminLogin">Se connecter</button><p id="adminLoginError" class="err" hidden>Mot de passe incorrect.</p></div>
  <div id="adminDashboard" hidden>
    <div class="row between"><h2>Tableau de <em>bord</em></h2><button class="btn btn-ghost" id="btnLockAdmin"><i class="fas fa-lock"></i> Verrouiller</button></div>
    <div class="card"><h3><i class="fas fa-tags"></i> Tarifs et barème</h3><p class="hint">Les prix sont facultatifs : laissez <b>0</b> pour afficher « Tarif sur devis » sur le site. Dès qu'un prix est saisi, il apparaît sur la page Services.</p><div class="grid4" id="tariffInputs"></div>
      <div class="grid4"><div class="field"><label>Garantie min. (FCFA)</label><input type="number" id="adminMinGuarantee"></div><div class="field"><label>Frais fixes de déplacement</label><input type="number" id="adminBaseFee"></div><div class="field"><label>Prix par km</label><input type="number" id="adminKmPrice"></div></div>
      <button class="btn btn-primary" id="btnSaveTariffs"><i class="fas fa-save"></i> Enregistrer</button><span id="tariffSaveStatus" class="okmsg" hidden>Tarifs mis à jour sur tout le site.</span></div>
    <div class="card"><h3><i class="fas fa-users"></i> Comptes et fonds bloqués</h3><div class="scroll"><table><thead><tr><th>Nom</th><th>Contact</th><th>Quartier</th><th>Type</th><th>Garantie</th><th>Statut</th><th>Actions</th></tr></thead><tbody id="accountsTableBody"></tbody></table></div></div>
    <div class="card"><h3><i class="fas fa-receipt"></i> Transactions</h3><p class="hint">Chaque paiement effectué sur le site est enregistré et conservé, même si le compte est ensuite supprimé. « simulation » = aucun opérateur branché ; une passerelle en mode test ne débite aucun argent réel.</p>
      <div class="scroll"><table><thead><tr><th>Date</th><th>Compte</th><th>Montant</th><th>Passerelle</th><th>Téléphone</th><th>Référence</th><th>Statut</th></tr></thead><tbody id="paymentsBody"></tbody></table></div></div>
    <div class="card"><div class="row between" style="margin:0 0 .6rem"><h3 style="margin:0"><i class="fas fa-clipboard-list"></i> Journal d'activité</h3><a class="btn btn-ghost small" href="api.php?action=admin_export"><i class="fas fa-file-csv"></i> Exporter (CSV)</a></div>
      <p class="hint">Historique permanent et non modifiable depuis le site : créations, suppressions et blocages de comptes, paiements, remboursements, changements de tarifs, connexions admin (avec adresse IP). Les 300 derniers événements sont affichés ; l'export contient tout.</p>
      <div class="scroll"><table><thead><tr><th>Date</th><th>Événement</th><th>Compte</th><th>Montant</th><th>Passerelle · Réf.</th><th>Statut</th><th>IP</th><th>Détails</th></tr></thead><tbody id="logBody"></tbody></table></div></div>
    <div class="card"><h3><i class="fas fa-route"></i> Dernières demandes</h3><div class="scroll"><table><thead><tr><th>Code</th><th>Client</th><th>Service</th><th>Trajet</th><th>Estimation</th><th>Date</th></tr></thead><tbody id="requestsBody"></tbody></table></div></div>
  </div>
</div></section>

<footer><div class="wrap foot">
  <div class="brand"><span class="mark"><img src="assets/img/logo-mark.png" alt=""></span><span class="brand-t">Y4I Academy<small>Une présence fiable pour les gestes qui comptent.</small></span></div>
  <div class="avail"><small>DISPONIBLES</small><b>24h/24 · 7j/7</b><span>Odza, Yaoundé · Cameroun</span></div>
  <a href="#accueil" class="totop">Haut de page <i class="fas fa-arrow-up"></i></a>
</div></footer>
<a class="whatsapp-float" href="https://wa.me/<?= $wa ?>?text=Bonjour,%20je%20souhaite%20des%20informations%20sur%20vos%20services." target="_blank" rel="noopener" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>window.Y4I = { whatsapp: "<?= $wa ?>" };</script>
<script src="assets/js/app.js"></script>
</body>
</html>

<?php
$CFG = require __DIR__ . '/config.php';
if (!empty($CFG['debug'])) { ini_set('display_errors', '1'); error_reporting(E_ALL); } else { ini_set('display_errors', '0'); }

/* ---------- Erreurs lisibles (fini la page blanche) ---------- */
set_exception_handler(function (Throwable $e) {
    $msg = !empty(cfg()['debug']) ? $e->getMessage() : 'Erreur serveur';
    if (str_contains($_SERVER['SCRIPT_NAME'] ?? '', 'api.php')) {
        http_response_code(500); header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => $msg], JSON_UNESCAPED_UNICODE); return;
    }
    http_response_code(500);
    echo '<!DOCTYPE html><meta charset="utf-8"><body style="font-family:sans-serif;max-width:640px;margin:60px auto;padding:0 20px">'
       . '<h2 style="color:#C8102E">Le site ne peut pas démarrer</h2><p><b>' . htmlspecialchars($msg) . '</b></p>'
       . (!empty(cfg()['debug']) ? '<p>Ouvrez la page de diagnostic : <a href="check.php">check.php</a></p>' : '') . '</body>';
});

if (session_status() === PHP_SESSION_NONE) @session_start();

function cfg(): array { global $CFG; return $CFG; }

/** Connexion : MySQL (XAMPP) en priorité, SQLite en secours. Tables créées automatiquement. */
function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $c = cfg()['db']; $errors = []; $driver = null;
    $opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC];

    if (in_array($c['driver'], ['auto', 'mysql'], true)) {
        if (!extension_loaded('pdo_mysql')) $errors[] = 'extension pdo_mysql absente';
        else try {
            $p = new PDO("mysql:host={$c['host']};port={$c['port']};charset=utf8mb4", $c['user'], $c['pass'], $opt);
            $p->exec("CREATE DATABASE IF NOT EXISTS `{$c['name']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $p->exec("USE `{$c['name']}`");
            $pdo = $p; $driver = 'mysql';
        } catch (Throwable $e) { $errors[] = 'MySQL : ' . $e->getMessage(); }
    }
    if (!$pdo && in_array($c['driver'], ['auto', 'sqlite'], true)) {
        if (!extension_loaded('pdo_sqlite')) $errors[] = 'extension pdo_sqlite absente';
        else try {
            $dir = __DIR__ . '/data';
            if (!is_dir($dir)) @mkdir($dir, 0777, true);
            if (!is_writable($dir)) throw new Exception("dossier data/ non inscriptible (faites : sudo chmod -R 777 $dir)");
            $pdo = new PDO('sqlite:' . $dir . '/y4i.sqlite', null, null, $opt); $driver = 'sqlite';
        } catch (Throwable $e) { $errors[] = 'SQLite : ' . $e->getMessage(); }
    }
    if (!$pdo) throw new Exception('Aucune base disponible. ' . implode(' | ', $errors));
    $GLOBALS['DB_DRIVER'] = $driver;
    init_schema($pdo, $driver);
    return $pdo;
}
function db_driver(): string { db(); return $GLOBALS['DB_DRIVER']; }

function table_cols(PDO $pdo, string $d, string $t): array {
    if ($d === 'mysql') return array_map(fn($r) => $r['Field'], $pdo->query("SHOW COLUMNS FROM `$t`")->fetchAll());
    return array_map(fn($r) => $r['name'], $pdo->query("PRAGMA table_info($t)")->fetchAll());
}

function init_schema(PDO $pdo, string $d): void {
    $pk = $d === 'mysql' ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY';
    $ig = $d === 'mysql' ? 'INSERT IGNORE' : 'INSERT OR IGNORE';
    $eng = $d === 'mysql' ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4' : '';
    $tables = [
      'accounts' => ["id $pk, name VARCHAR(120), contact VARCHAR(60), location VARCHAR(120), type VARCHAR(20),
         payment_method VARCHAR(60), status VARCHAR(40) DEFAULT 'Actif', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
         ['id','name','contact','location','type','payment_method','status','created_at']],
      'payments' => ["id $pk, account_id INT, gateway VARCHAR(20), reference VARCHAR(120), external_ref VARCHAR(120),
         amount INT, phone VARCHAR(20), status VARCHAR(20) DEFAULT 'PENDING', ussd_code VARCHAR(40), pay_url VARCHAR(500), extra VARCHAR(200),
         created_ts INT DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
         ['id','account_id','gateway','reference','external_ref','amount','phone','status','ussd_code','pay_url','extra','created_ts','created_at','updated_at']],
      'tariffs' => ["k VARCHAR(40) PRIMARY KEY, label VARCHAR(120), price INT, unit VARCHAR(40)", ['k','label','price','unit']],
      'settings' => ["k VARCHAR(40) PRIMARY KEY, v VARCHAR(100)", ['k','v']],
      'requests' => ["id $pk, code VARCHAR(12), pkey VARCHAR(40), name VARCHAR(120), phone VARCHAR(40), service VARCHAR(80),
         details VARCHAR(300), from_lat DOUBLE, from_lng DOUBLE, to_lat DOUBLE, to_lng DOUBLE, distance_m INT, duration_s INT, estimate INT,
         status VARCHAR(30) DEFAULT 'Nouvelle', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
         ['id','code','pkey','name','phone','service','details','from_lat','from_lng','to_lat','to_lng','distance_m','duration_s','estimate','status','created_at']],
      'tracking' => ["code VARCHAR(12), lat DOUBLE, lng DOUBLE, ts INT", ['code','lat','lng','ts']],
      'activity_log' => ["id $pk, ts INT, event VARCHAR(40), account_id INT, account_name VARCHAR(120), amount INT, gateway VARCHAR(20),
         reference VARCHAR(120), status VARCHAR(30), phone VARCHAR(30), ip VARCHAR(45), details VARCHAR(300)",
         ['id','ts','event','account_id','account_name','amount','gateway','reference','status','phone','ip','details']],
    ];
    foreach ($tables as $name => [$def, $need]) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS $name($def)$eng");
        // Table déjà existante mais d'une ancienne version (colonnes différentes) : on la met de côté et on la recrée
        if (array_diff($need, table_cols($pdo, $d, $name))) {
            $pdo->exec("ALTER TABLE $name RENAME TO {$name}_old_" . date('YmdHis'));
            $pdo->exec("CREATE TABLE $name($def)$eng");
        }
    }
    if ($d === 'sqlite') $pdo->exec("CREATE INDEX IF NOT EXISTS idx_track ON tracking(code, ts)");

    // Données de base : insertion idempotente (répare une initialisation interrompue)
    $nT = (int)$pdo->query("SELECT COUNT(*) FROM tariffs")->fetchColumn();
    $nS = (int)$pdo->query("SELECT COUNT(*) FROM settings")->fetchColumn();
    if ($nT < 4 || $nS < 3) {
        $t = $pdo->prepare("$ig INTO tariffs(k,label,price,unit) VALUES(?,?,?,?)");
        foreach ([['aide', 'Aide à domicile', 0, 'intervention'], ['hopital', 'Accompagnement hôpital & soins', 0, 'visite'],
                  ['kine', 'Kinésithérapie', 0, 'séance'], ['courses', 'Courses & quotidien', 0, 'commission']] as $r) $t->execute($r);
        $s = $pdo->prepare("$ig INTO settings(k,v) VALUES(?,?)");
        foreach ([['min_guarantee', cfg()['min_guarantee']], ['km_price', 300], ['base_fee', 1000]] as $r) $s->execute($r);
    }
    // Les prix sont saisis plus tard par le client (admin) : on efface une seule fois les anciens prix de démonstration
    if (!$pdo->query("SELECT 1 FROM settings WHERE k='prices_reset'")->fetch()) {
        $pdo->exec("UPDATE tariffs SET price=0");
        $pdo->prepare("$ig INTO settings(k,v) VALUES('prices_reset','1')")->execute();
    }
    if ((int)$pdo->query("SELECT COUNT(*) FROM accounts")->fetchColumn() === 0) {
        $a = $pdo->prepare("INSERT INTO accounts(name,contact,location,type,payment_method,status) VALUES(?,?,?,?,?,?)");
        $a->execute(['Pauline Manga', '+237 690000001', 'Odza', 'Client', 'Orange Money', 'Actif']);
        $a->execute(['Dr. Armand Tamo', '+237 670000002', 'Bastos', 'Prestataire', 'MTN MoMo', 'Actif']);
        $pdo->prepare("INSERT INTO payments(account_id,gateway,reference,amount,phone,status,created_ts) VALUES(2,'sim','seed',40000,'237670000002','SUCCESS',?)")->execute([time()]);
    }
}

/** Journal d'activité permanent (jamais modifié ni effacé par le site) */
function mask_phone(?string $p): ?string {
    if (!$p) return null; $p = preg_replace('/\D/', '', $p);
    return strlen($p) > 7 ? substr($p, 0, 4) . str_repeat('*', strlen($p) - 7) . substr($p, -3) : $p;
}
function account_name(int $id): ?string {
    $s = db()->prepare("SELECT name FROM accounts WHERE id=?"); $s->execute([$id]);
    $n = $s->fetchColumn(); return $n === false ? null : $n;
}
function log_event(string $event, array $d = []): void {
    try {
        db()->prepare("INSERT INTO activity_log(ts,event,account_id,account_name,amount,gateway,reference,status,phone,ip,details) VALUES(?,?,?,?,?,?,?,?,?,?,?)")
          ->execute([time(), $event, $d['account_id'] ?? null, $d['account_name'] ?? null, $d['amount'] ?? null, $d['gateway'] ?? null,
                     $d['reference'] ?? null, $d['status'] ?? null, mask_phone($d['phone'] ?? null), $_SERVER['REMOTE_ADDR'] ?? 'cli', substr((string)($d['details'] ?? ''), 0, 300)]);
    } catch (Throwable $e) { /* le journal ne doit jamais bloquer le site */ }
}

function out($data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
function body(): array {
    $j = json_decode(file_get_contents('php://input'), true);
    return is_array($j) ? $j : $_POST;
}
function setting(string $k, $def = null) {
    $r = db()->prepare("SELECT v FROM settings WHERE k=?"); $r->execute([$k]);
    $v = $r->fetchColumn(); return $v === false ? $def : $v;
}
function set_setting(string $k, $v): void {
    db()->prepare("DELETE FROM settings WHERE k=?")->execute([$k]);
    db()->prepare("INSERT INTO settings(k,v) VALUES(?,?)")->execute([$k, (string)$v]);
}
function is_admin(): bool { return !empty($_SESSION['admin']); }
function require_admin(): void { if (!is_admin()) out(['error' => 'Accès refusé'], 401); }

/** Normalise un numéro camerounais -> 2376XXXXXXXX */
function norm_phone(string $p): string {
    $p = preg_replace('/\D/', '', $p);
    if (strlen($p) === 9) $p = '237' . $p;
    return $p;
}

/* Y4I Academy — front dynamique */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const fcfa = n => Math.round(n).toLocaleString('fr-FR').replace(/\u202f/g, ' ') + ' FCFA';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(action, data, query = '') {
  const opt = data ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) } : {};
  const r = await fetch(`api.php?action=${action}${query}`, opt);
  const j = await r.json().catch(() => ({ error: 'Réponse invalide' }));
  if (!r.ok && !j.error) j.error = 'Erreur ' + r.status;
  return j;
}
let CONF = { tariffs: [], min_guarantee: 5000, km_price: 300, base_fee: 1000 };

/* ---------- Navigation ---------- */
function navigateToSection(id) {
  if (id !== '#admin') lockAdminUI();
  $$('.page-section').forEach(s => s.classList.remove('active'));
  ($(id) || $('#accueil')).classList.add('active');
  $$('.nav-link').forEach(l => l.classList.toggle('active', l.getAttribute('href') === id));
  $('#nav').classList.remove('open');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (id === '#suivi') setTimeout(initMap, 200);
  if (id === '#contact') setTimeout(() => $('#cName') && $('#cName').focus({ preventScroll: true }), 300);
}
function selectService(key) {
  navigateToSection('#contact');
  $('#cNeed').value = key;
  $('#cMsg').focus();
}

/* ---------- Diaporama ---------- */
function initSlideshow() {
  const slides = $$('.slide'), dots = $('#dots'); let i = 0, timer;
  slides.forEach((_, n) => { const b = document.createElement('button'); b.setAttribute('aria-label', 'Image ' + (n + 1)); b.onclick = () => { go(n); restart(); }; dots.appendChild(b); });
  const go = n => { slides[i].classList.remove('active-slide'); i = n; slides[i].classList.add('active-slide'); $$('button', dots).forEach((d, k) => d.classList.toggle('on', k === i)); };
  const restart = () => { clearInterval(timer); timer = setInterval(() => go((i + 1) % slides.length), 4500); };
  go(0); restart();
}

/* ---------- Tarifs dynamiques ---------- */
async function loadTariffs() {
  CONF = await api('tariffs');
  CONF.tariffs.forEach(t => { const el = $(`.service-card[data-key="${t.k}"] .service-price`); if (el) el.innerHTML = +t.price > 0 ? `<i class="fas fa-tag"></i> Dès <span>${Number(t.price).toLocaleString('fr-FR')}</span> FCFA / ${esc(t.unit)}` : '<i class="fas fa-circle-info"></i> Tarif sur devis · selon les heures et les tâches'; });
  const g = $('#regAmount'); if (g) { g.min = CONF.min_guarantee; g.placeholder = 'Ex : ' + (CONF.min_guarantee * 3); }
  $('#minG').textContent = 'Minimum : ' + fcfa(CONF.min_guarantee);
  $('#reqService').innerHTML = CONF.tariffs.map(t => `<option value="${t.k}">${esc(t.label)}${+t.price > 0 ? ' — dès ' + fcfa(t.price) : ''}</option>`).join('');
  const live = Object.entries(CONF.gateways).filter(([, v]) => v).map(([k]) => k);
  if (!live.length) { const n = document.createElement('p'); n.className = 'hint'; n.textContent = 'Mode démonstration : aucune passerelle de paiement n\'est encore configurée, le paiement est simulé.'; $('#prestataireFields').appendChild(n); }
}

/* ---------- Carte type Google Maps (Yaoundé) ---------- */
const BOUNDS = [[3.70, 11.35], [4.05, 11.70]];
let map, A = null, B = null, mA, mB, routeLayers = [], routes = [], active = 0, followMarker, followTimer, pushTimer;
const mkIcon = c => L.divIcon({ className: '', html: `<div class="${c}"></div>`, iconSize: [26, 26], iconAnchor: [13, 26] });
function initMap() {
  if (map) { map.invalidateSize(); return; }
  map = L.map('yaoundeRealMap', { maxBounds: BOUNDS, maxBoundsViscosity: .9, minZoom: 11 }).setView([3.8667, 11.5167], 13);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(map);
  L.control.scale({ imperial: false }).addTo(map);
  map.on('click', e => { if (!A) setPoint('A', e.latlng.lat, e.latlng.lng); else if (!B) setPoint('B', e.latlng.lat, e.latlng.lng); });
  ['Hôpital Central', 'Hôpital Général', 'CHU Yaoundé', 'Gare routière Mvan', 'Bastos', 'Odza', 'Mendong', 'Biyem-Assi', 'Mvog-Mbi', 'Melen'].forEach(n => {
    const b = document.createElement('button'); b.textContent = n; b.onclick = () => quickPlace(n); $('#chips').appendChild(b);
  });
  setupAC('from', 'A'); setupAC('to', 'B');
}
async function quickPlace(name) {
  const r = await api('geocode', null, '&q=' + encodeURIComponent(name));
  if (!r.length) return alert('Lieu introuvable à Yaoundé.');
  setPoint(A ? 'B' : 'A', r[0].lat, r[0].lng, name);
}
function setPoint(which, lat, lng, label) {
  if (which === 'A') { A = [lat, lng]; if (mA) mA.setLatLng(A); else { mA = L.marker(A, { icon: mkIcon('dot-a'), draggable: true }).addTo(map); mA.on('dragend', () => { A = [mA.getLatLng().lat, mA.getLatLng().lng]; $('#fromInput').value = 'Position choisie'; route(); }); } $('#fromInput').value = label || 'Position choisie'; }
  else { B = [lat, lng]; if (mB) mB.setLatLng(B); else { mB = L.marker(B, { icon: mkIcon('dot-b'), draggable: true }).addTo(map); mB.on('dragend', () => { B = [mB.getLatLng().lat, mB.getLatLng().lng]; $('#toInput').value = 'Position choisie'; route(); }); } $('#toInput').value = label || 'Position choisie'; }
  if (A && B) route(); else map.setView([lat, lng], 15);
}
function setupAC(id, which) {
  const inp = $('#' + id + 'Input'), list = $('#' + id + 'List'); let t;
  inp.addEventListener('input', () => {
    clearTimeout(t); const q = inp.value.trim(); if (q.length < 3) { list.innerHTML = ''; return; }
    t = setTimeout(async () => {
      const r = await api('geocode', null, '&q=' + encodeURIComponent(q));
      list.innerHTML = r.map((x, i) => `<li data-i="${i}">${esc(x.label.split(',').slice(0, 3).join(','))}</li>`).join('') || '<li>Aucun résultat à Yaoundé</li>';
      $$('li[data-i]', list).forEach(li => li.onclick = () => { const x = r[li.dataset.i]; list.innerHTML = ''; setPoint(which, x.lat, x.lng, x.label.split(',')[0]); });
    }, 350);
  });
  document.addEventListener('click', e => { if (!e.target.closest('.ac')) list.innerHTML = ''; });
}
const FR_MOD = { left: 'à gauche', right: 'à droite', 'slight left': 'légèrement à gauche', 'slight right': 'légèrement à droite', 'sharp left': 'franchement à gauche', 'sharp right': 'franchement à droite', straight: 'tout droit', uturn: 'faites demi-tour' };
function frStep(s) {
  const m = s.maneuver, n = s.name ? ' sur ' + s.name : '', d = FR_MOD[m.modifier] || '';
  switch (m.type) {
    case 'depart': return 'Partez' + n;
    case 'arrive': return 'Vous êtes arrivé' + (d ? ' (destination ' + d + ')' : '');
    case 'turn': case 'end of road': return 'Tournez ' + d + n;
    case 'roundabout': case 'rotary': return 'Au rond-point, prenez la sortie ' + (m.exit || '') + n;
    case 'fork': return 'Au embranchement, gardez votre ' + (m.modifier?.includes('left') ? 'gauche' : 'droite') + n;
    case 'merge': return 'Insérez-vous ' + d + n;
    default: return 'Continuez ' + (d || 'tout droit') + n;
  }
}
const fmtDist = m => m < 1000 ? Math.round(m) + ' m' : (m / 1000).toFixed(1).replace('.', ',') + ' km';
const fmtTime = s => { const m = Math.max(1, Math.round(s / 60)); return m < 60 ? m + ' min' : Math.floor(m / 60) + ' h ' + String(m % 60).padStart(2, '0'); };
async function route() {
  if (!A || !B) return;
  const url = `https://router.project-osrm.org/route/v1/driving/${A[1]},${A[0]};${B[1]},${B[0]}?alternatives=true&steps=true&overview=full&geometries=geojson`;
  try {
    const j = await (await fetch(url)).json();
    if (j.code !== 'Ok') throw 0;
    routes = j.routes.slice(0, 3); active = 0; drawRoutes(); $('#routeBox').hidden = false;
  } catch { alert('Itinéraire indisponible pour le moment. Réessayez.'); }
}
function drawRoutes() {
  routeLayers.forEach(l => map.removeLayer(l)); routeLayers = [];
  routes.forEach((r, i) => { if (i === active) return; const l = L.geoJSON(r.geometry, { style: { color: '#94A3B8', weight: 6, opacity: .8 } }).addTo(map); l.on('click', () => { active = i; drawRoutes(); }); routeLayers.push(l); });
  const cur = L.geoJSON(routes[active].geometry, { style: { color: '#1A73E8', weight: 7, opacity: .95 } }).addTo(map); routeLayers.push(cur);
  map.fitBounds(cur.getBounds(), { padding: [50, 50] });
  $('#routeTabs').innerHTML = routes.map((r, i) => `<button class="${i === active ? 'on' : ''}" data-i="${i}">${i === 0 ? 'Rapide' : 'Option ' + (i + 1)}<br>${fmtTime(r.duration)}</button>`).join('');
  $$('#routeTabs button').forEach(b => b.onclick = () => { active = +b.dataset.i; drawRoutes(); });
  const r = routes[active], eta = new Date(Date.now() + r.duration * 1000);
  $('#estTime').textContent = fmtTime(r.duration); $('#estDist').textContent = fmtDist(r.distance);
  $('#estEta').textContent = eta.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  updateCost();
  $('#steps').innerHTML = r.legs[0].steps.map(s => `<li>${esc(frStep(s))} <span>(${fmtDist(s.distance)})</span></li>`).join('');
}
function updateCost() {
  if (!routes.length) return;
  const move = CONF.base_fee + routes[active].distance / 1000 * CONF.km_price;
  const t = CONF.tariffs.find(x => x.k === $('#reqService').value);
  $('#estMove').textContent = fmtDist(routes[active].distance) + ' → ' + fcfa(move);
  $('#estTotal').textContent = t && +t.price > 0 ? fcfa(move + +t.price) : fcfa(move) + ' + service sur devis';
}
function bindMap() {
  $('#reqService').addEventListener('change', updateCost);
  $('#btnLocate').onclick = () => navigator.geolocation ? navigator.geolocation.getCurrentPosition(p => setPoint('A', p.coords.latitude, p.coords.longitude, 'Ma position'), () => alert('Position refusée : autorisez la localisation dans votre navigateur.'), { enableHighAccuracy: true }) : alert('Géolocalisation non supportée.');
  $('#btnSwap').onclick = () => { if (!A || !B) return; const a = A, b = B, fa = $('#fromInput').value, fb = $('#toInput').value; A = null; B = null; setPoint('A', b[0], b[1], fb); setPoint('B', a[0], a[1], fa); };
  $('#btnClear').onclick = () => { A = B = null; [mA, mB].forEach(m => m && map.removeLayer(m)); mA = mB = null; routeLayers.forEach(l => map.removeLayer(l)); routeLayers = []; $('#routeBox').hidden = true; $('#fromInput').value = $('#toInput').value = ''; };
  $('#btnRequest').onclick = async () => {
    const r = routes[active]; const out = $('#reqResult');
    const res = await api('request_create', { name: $('#reqName').value, phone: $('#reqPhone').value, service: $('#reqService').selectedOptions[0].text, details: $('#reqDetails').value,
      from_lat: A[0], from_lng: A[1], to_lat: B[0], to_lng: B[1], distance_m: Math.round(r.distance), duration_s: Math.round(r.duration) });
    out.innerHTML = res.error ? `<p class="err">${esc(res.error)}</p>` : `<p class="okmsg">Demande envoyée. Code de suivi : <b>${res.code}</b><br>Clé intervenant : <b>${res.pkey}</b></p><p class="hint">Conservez ce code pour suivre l'intervenant en direct.</p>`;
    if (res.code) { $('#followCode').value = res.code; $('#pushKey').value = res.pkey; }
  };
  $('#btnFollow').onclick = () => {
    clearInterval(followTimer); const code = $('#followCode').value.trim().toUpperCase(); if (!code) return;
    const tick = async () => {
      const r = await api('track_get', null, '&code=' + code);
      if (r.error) { $('#followState').textContent = r.error; clearInterval(followTimer); return; }
      if (!r.position) { $('#followState').textContent = 'En attente de la position de l\'intervenant…'; return; }
      const p = [r.position.lat, r.position.lng], age = Math.round(Date.now() / 1000 - r.position.ts);
      $('#followState').textContent = `Intervenant localisé (mise à jour il y a ${age} s).`;
      if (followMarker) followMarker.setLatLng(p); else followMarker = L.marker(p, { icon: mkIcon('dot-p') }).addTo(map);
      map.panTo(p);
    };
    tick(); followTimer = setInterval(tick, 5000);
  };
  $('#btnPush').onclick = () => {
    const btn = $('#btnPush'); if (pushTimer) { navigator.geolocation.clearWatch(pushTimer); pushTimer = null; btn.textContent = 'Partager ma position'; return; }
    const code = $('#followCode').value.trim().toUpperCase(), pkey = $('#pushKey').value.trim();
    if (!code || !pkey) return alert('Saisissez le code et la clé.');
    let last = 0;
    pushTimer = navigator.geolocation.watchPosition(p => { if (Date.now() - last < 4000) return; last = Date.now(); api('track_push', { code, pkey, lat: p.coords.latitude, lng: p.coords.longitude }); $('#followState').textContent = 'Position partagée en direct.'; },
      () => alert('Impossible d\'obtenir la position.'), { enableHighAccuracy: true });
    btn.textContent = 'Arrêter le partage';
  };
}

/* ---------- Inscription + paiement du fonds de garantie ---------- */
let payTimer, payMode = 'live';
function bindRegister() {
  const f = $('#registerForm');
  $('#regType').onchange = e => { const p = e.target.value === 'prestataire'; $('#prestataireFields').hidden = !p; $('#clientFields').hidden = p; $('#regSubmit').textContent = p ? 'Payer le fonds de garantie' : 'Créer mon compte'; };
  f.onsubmit = async e => {
    e.preventDefault(); const p = $('#regType').value === 'prestataire'; $('#regSubmit').disabled = true;
    const res = await api('register', { name: $('#regName').value, contact: $('#regContact').value, location: $('#regLocation').value, type: $('#regType').value,
      payment_method: $('#regPaymentMethod').value, gateway: $('#regGateway').value, phone: $('#regPhone').value, amount: $('#regAmount').value });
    $('#regSubmit').disabled = false;
    if (res.error) return showError(res.error, false);
    f.hidden = true;
    if (!p) return showSuccess('Compte client créé avec succès.');
    if (res.pay_url) { $('#payBox').hidden = false; $('#payTitle').textContent = 'Redirection vers Orange Money…'; $('#payText').textContent = 'Vous allez saisir votre code secret sur la page sécurisée d\'Orange.'; setTimeout(() => location.href = res.pay_url, 1200); return; }
    $('#payBox').hidden = false;
    payMode = res.mode;
    const test = res.mode !== 'live';
    $('#payTitle').textContent = res.mode === 'sim' ? 'Simulation de paiement' : test ? 'Paiement en mode test' : 'Vérifiez votre téléphone';
    $('#payText').innerHTML = res.mode === 'sim' ? 'Aucune passerelle configurée : le paiement est simulé et validé automatiquement.'
      : test ? 'Environnement de <b>test</b> de l\'opérateur : <b>aucun message n\'est envoyé sur votre téléphone et aucun argent réel n\'est débité</b>. La validation est simulée.'
      : `Un message de ${esc(res.operator || 'votre opérateur')} vient d'arriver sur le <b>${esc($('#regPhone').value)}</b>. Saisissez votre <b>code secret</b> sur le téléphone pour confirmer.` + (res.ussd_code ? `<br>Rien reçu ? Composez <b>${esc(res.ussd_code)}</b>.` : '');
    pollPayment(res.payment_id);
  };
  $('#btnRetryRegistration').onclick = () => { $('#registrationError').hidden = true; f.hidden = false; };
}
function pollPayment(id) {
  let n = 0; clearInterval(payTimer);
  payTimer = setInterval(async () => {
    const r = await api('pay_status', null, '&id=' + id);
    $('#payMeta').textContent = 'Vérification en cours… ' + (++n * 3) + ' s';
    if (r.status === 'SUCCESS') { clearInterval(payTimer); $('#payBox').hidden = true; showSuccess('Paiement confirmé. Votre fonds de garantie est bloqué en sécurité et votre compte est actif.' + (payMode !== 'live' ? ' (Mode test : aucun argent réel n\'a été débité.)' : '')); }
    else if (r.status === 'FAILED') { clearInterval(payTimer); $('#payBox').hidden = true; showError('Le paiement a été refusé ou annulé (solde insuffisant, code erroné ou délai dépassé).', true); }
    else if (n > 60) { clearInterval(payTimer); $('#payBox').hidden = true; showError('Délai dépassé : aucune confirmation reçue.', true); }
  }, 3000);
}
const showSuccess = t => { $('#successDetails').textContent = t; $('#registrationSuccess').hidden = false; };
function showError(t, retry) { $('#errorDetails').textContent = t; $('#registrationError').hidden = false; $('#btnRetryRegistration').hidden = !retry; if (!retry) setTimeout(() => $('#registrationError').hidden = true, 5000); }

/* ---------- Contact WhatsApp ---------- */
function bindContact() {
  $('#contactForm').onsubmit = e => {
    e.preventDefault();
    const msg = `Bonjour Y4I Academy, je suis ${$('#cName').value} (${$('#cPhone').value}). Besoin : ${$('#cNeed').selectedOptions[0].text}. ${$('#cMsg').value}`;
    window.open(`https://wa.me/${Y4I.whatsapp}?text=${encodeURIComponent(msg)}`, '_blank');
  };
}

/* ---------- Administration ---------- */
function lockAdminUI() { $('#adminDashboard').hidden = true; $('#adminLogin').hidden = false; $('#adminPasswordInput').value = ''; }
async function loadAdmin() {
  const d = await api('admin_data'); if (d.error) return lockAdminUI();
  $('#tariffInputs').innerHTML = d.tariffs.map(t => `<div class="field"><label>${esc(t.label)} (FCFA)</label><input type="number" min="0" step="1" data-k="${t.k}" value="${t.price}"></div>`).join('');
  $('#adminMinGuarantee').value = d.min_guarantee; $('#adminBaseFee').value = d.base_fee; $('#adminKmPrice').value = d.km_price;
  const cls = s => s === 'Actif' ? 't-ok' : s === 'Bloqué' || s === 'Paiement échoué' ? 't-ko' : 't-wait';
  $('#accountsTableBody').innerHTML = d.accounts.map(a => `<tr><td><b>${esc(a.name)}</b></td><td>${esc(a.contact)}</td><td>${esc(a.location)}</td><td>${esc(a.type)}</td>
    <td>${a.type === 'Prestataire' && a.amount ? fcfa(a.amount) + ' · ' + ({ SUCCESS: 'bloqué', REFUNDED: 'remboursé', PENDING: 'en attente', FAILED: 'échoué' }[a.pay_status] || '') : '—'}</td>
    <td><span class="tag ${cls(a.status)}">${esc(a.status)}</span></td>
    <td><button class="mini" style="background:${a.status === 'Actif' ? '#C8102E' : '#10B981'}" data-t="${a.id}">${a.status === 'Actif' ? 'Bloquer' : 'Activer'}</button>${a.pay_status === 'SUCCESS' ? `<button class="mini" style="background:#0033A0" data-r="${a.id}">Rembourser</button>` : ''}<button class="mini" style="background:#64748B" data-d="${a.id}" data-n="${esc(a.name)}">Supprimer</button></td></tr>`).join('');
  $$('[data-t]').forEach(b => b.onclick = async () => { await api('admin_toggle', { id: b.dataset.t }); loadAdmin(); });
  $$('[data-r]').forEach(b => b.onclick = async () => { if (!confirm('Rembourser ce fonds de garantie ?')) return; const r = await api('admin_refund', { id: b.dataset.r }); alert(r.error || r.note); loadAdmin(); });
  $$('[data-d]').forEach(b => b.onclick = async () => {
    if (!confirm(`Supprimer définitivement le compte « ${b.dataset.n} » ?\nL'historique des transactions et du journal est conservé.`)) return;
    const r = await api('admin_delete', { id: b.dataset.d }); if (r.error) alert(r.error); loadAdmin();
  });
  const dt = ts => ts ? new Date(ts * 1000).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'medium' }) : '—';
  const PST = { SUCCESS: ['t-ok', 'Confirmé · bloqué'], PENDING: ['t-wait', 'En attente'], FAILED: ['t-ko', 'Échoué'], REFUNDED: ['t-wait', 'Remboursé'], REFUSE: ['t-ko', 'Refusé'] };
  const pill = s => s ? `<span class="tag ${(PST[s] || ['t-wait'])[0]}">${esc((PST[s] || [0, s])[1])}</span>` : '';
  $('#paymentsBody').innerHTML = d.payments.map(p => `<tr><td>${dt(p.ts)}</td><td><b>${esc(p.name)}</b></td><td>${fcfa(p.amount)}</td><td>${esc(p.gateway === 'sim' ? 'simulation' : p.gateway)}</td><td>${esc(p.phone || '')}</td><td>${esc(p.reference)}</td><td>${pill(p.status)}</td></tr>`).join('') || '<tr><td colspan="7">Aucune transaction.</td></tr>';
  const EV = { compte_cree: 'Compte créé', compte_supprime: 'Compte SUPPRIMÉ', compte_bloque: 'Compte bloqué', compte_active: 'Compte activé', paiement_initie: 'Paiement initié', paiement_confirme: 'Paiement confirmé', paiement_echoue: 'Paiement échoué', remboursement: 'Remboursement', tarifs_modifies: 'Tarifs modifiés', demande_creee: 'Demande de service', admin_connexion: 'Connexion admin', admin_echec_connexion: 'Échec connexion admin', journal_exporte: 'Journal exporté' };
  $('#logBody').innerHTML = d.log.map(r => `<tr><td>${dt(+r.ts)}</td><td><b>${esc(EV[r.event] || r.event)}</b></td><td>${esc(r.account_name || '')}</td><td>${r.amount ? fcfa(r.amount) : ''}</td><td>${esc([r.gateway === 'sim' ? 'simulation' : r.gateway, r.reference].filter(Boolean).join(' · '))}</td><td>${pill(r.status)}</td><td>${esc(r.ip || '')}</td><td style="white-space:normal;max-width:320px">${esc(r.details || '')}</td></tr>`).join('') || '<tr><td colspan="8">Aucun événement.</td></tr>';
  $('#requestsBody').innerHTML = d.requests.map(r => `<tr><td><b>${esc(r.code)}</b></td><td>${esc(r.name)}<br><small>${esc(r.phone)}</small></td><td>${esc(r.service)}</td><td>${r.distance_m ? fmtDist(r.distance_m) + ' · ' + fmtTime(r.duration_s) : '—'}</td><td>${fcfa(r.estimate)}</td><td>${esc(r.created_at)}</td></tr>`).join('') || '<tr><td colspan="6">Aucune demande pour l\'instant.</td></tr>';
}
function bindAdmin() {
  $('#btnAdminLogin').onclick = async () => {
    const r = await api('admin_login', { password: $('#adminPasswordInput').value });
    $('#adminLoginError').hidden = !r.error; if (r.error) return;
    $('#adminLogin').hidden = true; $('#adminDashboard').hidden = false; loadAdmin();
  };
  $('#adminPasswordInput').addEventListener('keydown', e => e.key === 'Enter' && $('#btnAdminLogin').click());
  $('#btnLockAdmin').onclick = async () => { await api('admin_logout', {}); navigateToSection('#accueil'); };
  $('#btnSaveTariffs').onclick = async () => {
    const tariffs = {}; $$('#tariffInputs input').forEach(i => tariffs[i.dataset.k] = i.value);
    const r = await api('admin_tariffs', { tariffs, min_guarantee: $('#adminMinGuarantee').value, base_fee: $('#adminBaseFee').value, km_price: $('#adminKmPrice').value });
    if (r.error) return alert(r.error);
    await loadTariffs(); const s = $('#tariffSaveStatus'); s.hidden = false; setTimeout(() => s.hidden = true, 3000);
  };
}

/* ---------- Démarrage ---------- */
document.addEventListener('DOMContentLoaded', () => {
  document.documentElement.classList.add('js');
  if ('IntersectionObserver' in window) { const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12 }); $$('.reveal').forEach(el => io.observe(el)); }
  else $$('.reveal').forEach(el => el.classList.add('in'));
  initSlideshow(); loadTariffs(); bindMap(); bindRegister(); bindContact(); bindAdmin();
  $('#burger').onclick = () => $('#nav').classList.toggle('open');
  $$('a[href^="#"]').forEach(a => a.addEventListener('click', e => { const id = a.getAttribute('href'); if (id.length > 1) { e.preventDefault(); history.replaceState(null, '', id); navigateToSection(id); } }));
  if (location.hash.length > 1 && $(location.hash)) navigateToSection(location.hash);
  const q = new URLSearchParams(location.search).get('paiement');
  if (q) { navigateToSection('#inscription'); if (q === 'ok') showSuccess('Retour d\'Orange Money : votre paiement est en cours de confirmation. Votre compte sera activé dès réception de la validation.'); else showError('Paiement annulé.', true); $('#registerForm').hidden = true; }
});

<?php
// ============ CONFIGURATION Y4I ACADEMY ============
// Renseignez les clés (voir LISEZ-MOI.md). Sans clés => MODE SIMULATION automatique.
return [
    'debug'          => true,   // true en local (affiche les erreurs) ; METTRE false en production
    'app_url'        => 'http://localhost/y4i',   // en ligne : https://votre-domaine.com (sans slash final)

    // BASE DE DONNÉES : 'auto' = MySQL (XAMPP/phpMyAdmin) puis SQLite si MySQL indisponible
    'db' => [
        'driver' => 'auto',          // auto | mysql | sqlite
        'host'   => '127.0.0.1',
        'port'   => 3306,
        'name'   => 'y4i_academy',   // créée automatiquement
        'user'   => 'root',          // XAMPP : root
        'pass'   => '',              // XAMPP : mot de passe vide
    ],
    'admin_password' => 'ChangeMoi!2026',              // À CHANGER avant mise en ligne
    'whatsapp'       => '237696500949',
    'currency'       => 'XAF',
    'min_guarantee'  => 5000,

    // Passerelle utilisée par défaut : campay | mtn | orange
    'default_gateway' => 'campay',

    // CAMPAY (Orange Money + MTN MoMo en une seule intégration) — https://campay.net
    'campay' => [
        'base'        => 'https://demo.campay.net/api',   // PRODUCTION : https://www.campay.net/api
        'username'    => '',   // "App Username" du tableau de bord Campay
        'password'    => '',   // "App Password"
        'webhook_key' => '',   // clé webhook (optionnelle, affichée dans Campay)
    ],
    // MTN MoMo API (collection) — https://momodeveloper.mtn.com
    'mtn' => [
        'base'             => 'https://sandbox.momodeveloper.mtn.com', // PRODUCTION : https://proxy.momoapi.mtn.com
        'subscription_key' => '',   // Ocp-Apim-Subscription-Key (produit Collection)
        'api_user'         => '',   // UUID API user
        'api_key'          => '',
        'environment'      => 'sandbox', // PRODUCTION : mtncameroon
        'currency'         => 'EUR',     // sandbox = EUR ; PRODUCTION = XAF
    ],
    // ORANGE MONEY Web Payment Cameroun — https://developer.orange.com
    'orange' => [
        'base'        => 'https://api.orange.com/orange-money-webpay/dev/v1', // PRODUCTION : .../orange-money-webpay/cm/v1
        'auth_header' => '',   // "Basic xxxx" (base64 client_id:client_secret)
        'merchant_key'=> '',
        'currency'    => 'OUV', // sandbox = OUV ; PRODUCTION = XAF
    ],
];

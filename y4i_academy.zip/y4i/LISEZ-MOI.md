# Y4I Academy — Site PHP (Yaoundé)

## Contenu
- `index.php` : site (accueil + diaporama, services, carte, inscription, contact, admin)
- `api.php` : API (tarifs, inscription, paiement, webhooks, carte, suivi, admin)
- `pay.php` : passerelles Campay / MTN MoMo / Orange Money
- `config.php` : **toutes vos clés et réglages**
- `lib.php` : base de données MySQL ou SQLite (tables créées automatiquement)
- `check.php` : page de diagnostic (supprimer en production)
- `assets/` : logo, images, CSS, JS

## Photos (à remplacer par vos propres images)
Les photos du site sont dans `assets/img/photos/` : `photo-home.jpg` (accueil), `photo-hospital.jpg` (hôpital), `photo-care.jpg` (soins), `photo-support.jpg` (présence). Elles viennent de vos captures d'écran, donc en résolution limitée. Pour un rendu net, remplacez-les par des photos haute définition **en gardant les mêmes noms de fichiers** (idéalement 1600 px de large, format JPG). Pour ajouter une photo au diaporama, ajoutez-la dans la liste `$slides` en haut de `index.php`.
Le logo utilisé en en-tête est `assets/img/logo-mark.png` (icône extraite de `logo.jpg`).

## Test local avec XAMPP (Linux)
```
sudo /opt/lampp/lampp start
sudo rm -rf /opt/lampp/htdocs/y4i
sudo cp -r y4i /opt/lampp/htdocs/
sudo chmod -R 777 /opt/lampp/htdocs/y4i/data
```
Puis ouvrez `http://localhost/y4i/check.php` (diagnostic) et `http://localhost/y4i/` (site).
- Base de données : **MySQL de XAMPP**, créée automatiquement (`y4i_academy`, visible dans phpMyAdmin : http://localhost/phpmyadmin). Si MySQL est indisponible, le site bascule seul sur SQLite (`data/y4i.sqlite`).
- Réglages dans `config.php` → `db` (utilisateur `root`, mot de passe vide par défaut dans XAMPP).
- En ligne : `debug` => false, supprimez `check.php`, mettez l'identifiant MySQL de votre hébergeur.

## Installation (hébergeur cPanel ou VPS)
1. PHP 8.0+ avec extensions `curl` et `pdo_mysql` (ou `pdo_sqlite`). HTTPS obligatoire.
2. Envoyez le dossier dans `public_html/` (le dossier `data/` doit être inscriptible, chmod 755/775).
3. Ouvrez `config.php` : changez `app_url` et `admin_password`.
4. Ouvrez le site : sans clés, le paiement est en **mode simulation** (validé après 8 s) pour tester.
5. Test local : `php -S localhost:8000` dans le dossier.

## Faire fonctionner le paiement RÉEL

### Option A — Campay (recommandée : Orange + MTN avec un seul compte)
1. Créez un compte marchand sur campay.net et faites valider l'entreprise (documents demandés).
2. Créez une application : copiez *App Username* et *App Password* dans `config.php` → `campay`.
3. Essayez d'abord avec `https://demo.campay.net/api` (numéros de test fournis par Campay).
4. En production : `base` = `https://www.campay.net/api`.
5. Dans Campay, mettez l'URL webhook : `https://votre-domaine.com/api.php?action=webhook_campay`.
6. Fonctionnement : le site demande le paiement → Campay envoie la demande USSD sur le téléphone du prestataire → il saisit son **code secret sur son téléphone** → le site détecte le succès et active le compte.
7. Remboursement : le bouton « Rembourser » de l'admin utilise l'API de retrait Campay (activez-la sur votre compte).

### Option B — MTN MoMo direct
1. Compte sur momodeveloper.mtn.com, abonnement au produit *Collection*, clé `subscription_key`.
2. Créez l'API user/key (sandbox : `POST /v1_0/apiuser` puis `/apikey`), renseignez `config.php` → `mtn`.
3. Production : `base` = `https://proxy.momoapi.mtn.com`, `environment` = `mtncameroon`, `currency` = `XAF` (contrat commercial avec MTN Cameroun requis).

### Option C — Orange Money direct
1. Compte sur developer.orange.com, API *Orange Money WebPay Cameroun*, puis contrat marchand avec Orange Money Cameroun.
2. Renseignez `auth_header` (« Basic » + base64 de client_id:client_secret) et `merchant_key`.
3. Production : `base` = `https://api.orange.com/orange-money-webpay/cm/v1`, `currency` = `XAF`.
4. Le prestataire est redirigé vers la page Orange, où il valide avec son code secret.

> Le code secret ne passe JAMAIS par votre site (interdit par les opérateurs). Il est saisi sur le téléphone ou sur la page de l'opérateur.
> « Fonds bloqué » = argent encaissé sur votre compte marchand et enregistré comme garantie en base ; il n'est restitué que par l'admin (bouton Rembourser).

## Carte « type Google Maps » pour Yaoundé
- Fond OpenStreetMap, limité à Yaoundé, recherche d'adresses/quartiers/hôpitaux (Nominatim), repères déplaçables A/B, itinéraires alternatifs, étapes en français, durée, distance, heure d'arrivée, estimation du coût, suivi GPS en direct de l'intervenant.
- Gratuit mais le serveur OSRM public est limité : pour un trafic réel, utilisez OpenRouteService, Mapbox ou votre propre OSRM.
- Pour de vrais Google Maps : clé Google Maps Platform (facturation activée) et remplacement de `initMap()`/`route()` par Maps JavaScript + Directions API.

## Sécurité à faire avant la mise en ligne
- Changer `admin_password`; activer HTTPS; sauvegarder la base (export phpMyAdmin ou `data/y4i.sqlite`).
- Les APIs `request_create`/`register` méritent un anti-spam (reCAPTCHA / limitation) en production.

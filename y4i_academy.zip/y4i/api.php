<?php
require_once __DIR__ . '/pay.php';
$a = $_GET['action'] ?? '';
$db = db();

try {
switch ($a) {

case 'tariffs':
    out(['tariffs' => $db->query("SELECT * FROM tariffs")->fetchAll(),
         'min_guarantee' => (int)setting('min_guarantee', 5000),
         'km_price' => (int)setting('km_price', 300), 'base_fee' => (int)setting('base_fee', 1000),
         'gateways' => ['campay' => gateway_ready('campay'), 'mtn' => gateway_ready('mtn'), 'orange' => gateway_ready('orange')],
         'modes' => ['campay' => gateway_mode('campay'), 'mtn' => gateway_mode('mtn'), 'orange' => gateway_mode('orange')]]);

case 'register': {
    $b = body();
    $name = trim($b['name'] ?? ''); $contact = trim($b['contact'] ?? ''); $loc = trim($b['location'] ?? '');
    $type = ($b['type'] ?? '') === 'prestataire' ? 'Prestataire' : 'Client';
    if ($name === '' || $contact === '' || $loc === '') out(['error' => 'Nom, contact et quartier sont obligatoires.'], 422);
    if ($type === 'Client') {
        $db->prepare("INSERT INTO accounts(name,contact,location,type,payment_method,status) VALUES(?,?,?,?,?,'Actif')")
           ->execute([$name, $contact, $loc, 'Client', substr($b['payment_method'] ?? '', 0, 40)]);
        log_event('compte_cree', ['account_id' => (int)$db->lastInsertId(), 'account_name' => $name, 'details' => 'Client · ' . $loc]);
        out(['ok' => true, 'type' => 'Client']);
    }
    $gw = in_array($b['gateway'] ?? '', ['campay', 'mtn', 'orange'], true) ? $b['gateway'] : cfg()['default_gateway'];
    $amount = (int)($b['amount'] ?? 0);
    $min = (int)setting('min_guarantee', 5000);
    $phone = norm_phone($b['phone'] ?? '');
    if ($amount < $min) out(['error' => "Le fonds de garantie minimum est de " . number_format($min, 0, ',', ' ') . " FCFA."], 422);
    if (!preg_match('/^2376\d{8}$/', $phone)) out(['error' => 'Numéro Mobile Money invalide (ex : 6XXXXXXXX).'], 422);
    $db->prepare("INSERT INTO accounts(name,contact,location,type,payment_method,status) VALUES(?,?,?,?,?,'En attente de paiement')")
       ->execute([$name, $contact, $loc, 'Prestataire', $gw]);
    $accId = (int)$db->lastInsertId();
    log_event('compte_cree', ['account_id' => $accId, 'account_name' => $name, 'details' => 'Prestataire · ' . $loc]);
    try { $p = start_payment($accId, $gw, $phone, $amount); }
    catch (Throwable $e) {
        $db->prepare("UPDATE accounts SET status='Paiement échoué' WHERE id=?")->execute([$accId]);
        out(['error' => $e->getMessage()], 502);
    }
    out(['ok' => true, 'type' => 'Prestataire'] + $p);
}

case 'pay_status':
    out(refresh_payment((int)($_GET['id'] ?? 0)));

case 'webhook_campay': {   // URL à saisir dans Campay : /api.php?action=webhook_campay
    $ref = $_GET['reference'] ?? '';
    $s = $db->prepare("SELECT id FROM payments WHERE reference=?"); $s->execute([$ref]);
    if ($id = $s->fetchColumn()) refresh_payment((int)$id);
    out(['ok' => true]);
}
case 'webhook_orange': {   // notif_url envoyée à Orange
    $b = body(); $tok = $b['notif_token'] ?? '';
    $s = $db->prepare("SELECT id FROM payments WHERE gateway='orange' AND extra=? AND extra<>''"); $s->execute([$tok]);
    if ($id = $s->fetchColumn()) refresh_payment((int)$id);
    out(['ok' => true]);
}

/* ---------- Géocodage limité à Yaoundé (proxy Nominatim) ---------- */
case 'geocode': {
    $q = trim(substr($_GET['q'] ?? '', 0, 100));
    if (strlen($q) < 3) out([]);
    $url = 'https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&countrycodes=cm&bounded=1&viewbox=11.40,3.98,11.65,3.76&q=' . urlencode($q . ' Yaoundé');
    $r = http('GET', $url, ['User-Agent: Y4I-Academy/1.0 (' . cfg()['app_url'] . ')', 'Accept-Language: fr']);
    $res = [];
    foreach (($r['json'] ?? []) as $x) $res[] = ['label' => $x['display_name'], 'lat' => (float)$x['lat'], 'lng' => (float)$x['lon']];
    out($res);
}

/* ---------- Demandes de service + estimation ---------- */
case 'request_create': {
    $b = body();
    $name = trim($b['name'] ?? ''); $phone = trim($b['phone'] ?? '');
    if ($name === '' || $phone === '') out(['error' => 'Nom et téléphone requis.'], 422);
    $code = strtoupper(substr(bin2hex(random_bytes(3)), 0, 6)); $pkey = bin2hex(random_bytes(8));
    $dist = max(0, (int)($b['distance_m'] ?? 0));
    $est = (int)setting('base_fee', 1000) + (int)round($dist / 1000 * (int)setting('km_price', 300));
    log_event('demande_creee', ['amount' => $est, 'phone' => $phone, 'account_name' => $name, 'reference' => $code, 'details' => substr($b['service'] ?? '', 0, 60)]);
    $db->prepare("INSERT INTO requests(code,pkey,name,phone,service,details,from_lat,from_lng,to_lat,to_lng,distance_m,duration_s,estimate) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)")
       ->execute([$code, $pkey, $name, $phone, substr($b['service'] ?? '', 0, 60), substr($b['details'] ?? '', 0, 300),
           $b['from_lat'] ?? null, $b['from_lng'] ?? null, $b['to_lat'] ?? null, $b['to_lng'] ?? null, $dist, (int)($b['duration_s'] ?? 0), $est]);
    out(['ok' => true, 'code' => $code, 'pkey' => $pkey, 'estimate' => $est]);
}

/* ---------- Suivi GPS en direct ---------- */
case 'track_push': {  // appelé par le téléphone du prestataire
    $b = body();
    $s = $db->prepare("SELECT code FROM requests WHERE code=? AND pkey=?"); $s->execute([$b['code'] ?? '', $b['pkey'] ?? '']);
    if (!$s->fetchColumn()) out(['error' => 'Code invalide'], 403);
    $db->prepare("INSERT INTO tracking(code,lat,lng,ts) VALUES(?,?,?,?)")->execute([$b['code'], (float)$b['lat'], (float)$b['lng'], time()]);
    $db->prepare("DELETE FROM tracking WHERE code=? AND ts < ?")->execute([$b['code'], time() - 7200]);
    out(['ok' => true]);
}
case 'track_get': {
    $s = $db->prepare("SELECT r.status, r.from_lat, r.from_lng, r.to_lat, r.to_lng FROM requests r WHERE r.code=?");
    $s->execute([strtoupper($_GET['code'] ?? '')]);
    $r = $s->fetch();
    if (!$r) out(['error' => 'Code introuvable'], 404);
    $t = $db->prepare("SELECT lat,lng,ts FROM tracking WHERE code=? ORDER BY ts DESC LIMIT 1");
    $t->execute([strtoupper($_GET['code'])]);
    out(['request' => $r, 'position' => $t->fetch() ?: null]);
}

/* ---------- Administration (session + mot de passe serveur) ---------- */
case 'admin_login': {
    $b = body();
    usleep(400000); // freine la force brute
    if (hash_equals(cfg()['admin_password'], (string)($b['password'] ?? ''))) { session_regenerate_id(true); $_SESSION['admin'] = true; log_event('admin_connexion'); out(['ok' => true]); }
    log_event('admin_echec_connexion', ['status' => 'REFUSE']);
    out(['error' => 'Mot de passe incorrect'], 401);
}
case 'admin_logout': $_SESSION = []; session_destroy(); out(['ok' => true]);
case 'admin_data':
    require_admin();
    out(['accounts' => $db->query("SELECT a.*, (SELECT p.amount FROM payments p WHERE p.account_id=a.id ORDER BY p.id DESC LIMIT 1) amount,
            (SELECT p.status FROM payments p WHERE p.account_id=a.id ORDER BY p.id DESC LIMIT 1) pay_status,
            (SELECT p.gateway FROM payments p WHERE p.account_id=a.id ORDER BY p.id DESC LIMIT 1) gateway
            FROM accounts a ORDER BY a.id DESC")->fetchAll(),
         'requests' => $db->query("SELECT * FROM requests ORDER BY id DESC LIMIT 50")->fetchAll(),
         'payments' => array_map(fn($r) => ['id' => $r['id'], 'ts' => (int)$r['created_ts'], 'gateway' => $r['gateway'], 'reference' => $r['reference'], 'amount' => (int)$r['amount'],
              'status' => $r['status'], 'phone' => mask_phone($r['phone']), 'name' => $r['name'] ?? ('(compte supprimé #' . $r['account_id'] . ')')],
              $db->query("SELECT p.*, a.name FROM payments p LEFT JOIN accounts a ON a.id=p.account_id ORDER BY p.id DESC LIMIT 200")->fetchAll()),
         'log' => $db->query("SELECT * FROM activity_log ORDER BY id DESC LIMIT 300")->fetchAll(),
         'tariffs' => $db->query("SELECT * FROM tariffs")->fetchAll(),
         'min_guarantee' => (int)setting('min_guarantee'), 'km_price' => (int)setting('km_price'), 'base_fee' => (int)setting('base_fee')]);
case 'admin_toggle': {
    require_admin(); $b = body();
    $id = (int)$b['id'];
    $db->prepare("UPDATE accounts SET status = CASE WHEN status='Actif' THEN 'Bloqué' ELSE 'Actif' END WHERE id=?")->execute([$id]);
    $s = $db->prepare("SELECT name,status FROM accounts WHERE id=?"); $s->execute([$id]); $r = $s->fetch();
    if ($r) log_event($r['status'] === 'Actif' ? 'compte_active' : 'compte_bloque', ['account_id' => $id, 'account_name' => $r['name'], 'status' => $r['status']]);
    out(['ok' => true]);
}
case 'admin_tariffs': {
    require_admin(); $b = body();
    $u = $db->prepare("UPDATE tariffs SET price=? WHERE k=?");
    foreach (($b['tariffs'] ?? []) as $k => $v) $u->execute([max(0, (int)$v), $k]);
    foreach (['min_guarantee', 'km_price', 'base_fee'] as $k) if (isset($b[$k])) set_setting($k, max(0, (int)$b[$k]));
    log_event('tarifs_modifies', ['details' => json_encode(['tarifs' => $b['tariffs'] ?? [], 'garantie_min' => $b['min_guarantee'] ?? null, 'frais_fixes' => $b['base_fee'] ?? null, 'prix_km' => $b['km_price'] ?? null])]);
    out(['ok' => true]);
}
case 'admin_refund': {   // libère/rembourse le fonds de garantie d'un prestataire
    require_admin(); $b = body();
    $s = $db->prepare("SELECT * FROM payments WHERE account_id=? AND status='SUCCESS' ORDER BY id DESC LIMIT 1"); $s->execute([(int)$b['id']]);
    $p = $s->fetch();
    if (!$p) out(['error' => 'Aucun fonds bloqué pour ce compte.'], 404);
    $auto = false;
    if ($p['gateway'] === 'campay' && $p['reference'] !== 'seed' && gateway_ready('campay')) {
        if (!campay_withdraw($p['phone'], (int)$p['amount'], 'RF-' . $p['external_ref'])) out(['error' => 'Remboursement Campay refusé.'], 502);
        $auto = true;
    }
    $db->prepare("UPDATE payments SET status='REFUNDED', updated_at=CURRENT_TIMESTAMP WHERE id=?")->execute([$p['id']]);
    log_event('remboursement', ['account_id' => (int)$p['account_id'], 'account_name' => account_name((int)$p['account_id']), 'amount' => (int)$p['amount'], 'gateway' => $p['gateway'],
        'reference' => $p['reference'], 'status' => 'REFUNDED', 'phone' => $p['phone'], 'details' => $auto ? 'remboursement automatique' : 'à effectuer manuellement']);
    out(['ok' => true, 'auto' => $auto, 'note' => $auto ? 'Remboursé sur Mobile Money.' : 'Marqué remboursé : effectuez le virement manuellement depuis votre compte opérateur.']);
}

case 'admin_delete': {   // supprime le compte ; l'historique des transactions est CONSERVÉ
    require_admin(); $b = body(); $id = (int)($b['id'] ?? 0);
    $s = $db->prepare("SELECT * FROM accounts WHERE id=?"); $s->execute([$id]); $acc = $s->fetch();
    if (!$acc) out(['error' => 'Compte introuvable.'], 404);
    $f = $db->prepare("SELECT COUNT(*) FROM payments WHERE account_id=? AND status='SUCCESS'"); $f->execute([$id]);
    if ((int)$f->fetchColumn() > 0) out(['error' => 'Ce prestataire a un fonds de garantie bloqué : remboursez-le d\'abord (bouton Rembourser), puis supprimez le compte.'], 409);
    $db->prepare("DELETE FROM accounts WHERE id=?")->execute([$id]);
    log_event('compte_supprime', ['account_id' => $id, 'account_name' => $acc['name'], 'details' => $acc['type'] . ' · ' . $acc['location'] . ' · ' . $acc['contact']]);
    out(['ok' => true]);
}
case 'admin_export': {   // export CSV du journal complet (ouvrable dans Excel / LibreOffice)
    require_admin(); log_event('journal_exporte');
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="journal-y4i-' . date('Ymd-His') . '.csv"');
    $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF");
    fputcsv($o, ['Date', 'Evenement', 'Compte', 'Montant FCFA', 'Passerelle', 'Reference', 'Statut', 'Telephone', 'IP', 'Details'], ';');
    foreach ($db->query("SELECT * FROM activity_log ORDER BY id ASC") as $r)
        fputcsv($o, [date('Y-m-d H:i:s', (int)$r['ts']), $r['event'], $r['account_name'], $r['amount'], $r['gateway'], $r['reference'], $r['status'], $r['phone'], $r['ip'], $r['details']], ';');
    exit;
}

default: out(['error' => 'Action inconnue'], 404);
}
} catch (Throwable $e) { out(['error' => !empty(cfg()['debug']) ? $e->getMessage() : 'Erreur serveur'], 500); }

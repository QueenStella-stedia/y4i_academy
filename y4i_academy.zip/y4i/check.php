<?php
// Page de diagnostic : http://localhost/y4i/check.php  (supprimez ce fichier en production)
$cfg = require __DIR__ . '/config.php';
if (empty($cfg['debug'])) { http_response_code(404); exit('Not found'); }
ini_set('display_errors', '1'); error_reporting(E_ALL);
function row($label, $ok, $hint = '') { echo '<tr><td>' . $label . '</td><td style="color:' . ($ok ? '#0a7a3d' : '#C8102E') . ';font-weight:700">' . ($ok ? 'OK' : 'ÉCHEC') . '</td><td>' . $hint . '</td></tr>'; }
echo '<!DOCTYPE html><meta charset="utf-8"><title>Diagnostic Y4I</title><body style="font-family:sans-serif;max-width:860px;margin:30px auto;padding:0 16px"><h2>Diagnostic Y4I Academy</h2><table cellpadding="8" border="1" style="border-collapse:collapse;width:100%">';
row('PHP ≥ 8.0', version_compare(PHP_VERSION, '8.0', '>='), 'Version : ' . PHP_VERSION);
row('Extension curl (paiements)', extension_loaded('curl'), 'Obligatoire pour Campay/MTN/Orange et la recherche d\'adresses');
row('Extension pdo_mysql', extension_loaded('pdo_mysql'), 'Base MySQL (XAMPP)');
row('Extension pdo_sqlite', extension_loaded('pdo_sqlite'), 'Base de secours');
$d = __DIR__ . '/data';
row('Dossier data/ inscriptible', is_dir($d) && is_writable($d), is_writable($d) ? '' : 'Tapez : <code>sudo chmod -R 777 ' . htmlspecialchars($d) . '</code>');
try {
    require_once __DIR__ . '/lib.php';
    $pdo = db();
    row('Connexion base de données', true, 'Moteur utilisé : <b>' . db_driver() . '</b>' . (db_driver() === 'mysql' ? ' — base « ' . htmlspecialchars($cfg['db']['name']) . ' » visible dans phpMyAdmin' : ' — fichier data/y4i.sqlite'));
    foreach (['accounts', 'payments', 'tariffs', 'settings', 'requests', 'tracking'] as $t) row("Table $t", true, (int)$pdo->query("SELECT COUNT(*) FROM $t")->fetchColumn() . ' ligne(s)');
} catch (Throwable $e) { row('Connexion base de données', false, htmlspecialchars($e->getMessage())); }
echo '</table><p><a href="./">Ouvrir le site</a></p></body>';
